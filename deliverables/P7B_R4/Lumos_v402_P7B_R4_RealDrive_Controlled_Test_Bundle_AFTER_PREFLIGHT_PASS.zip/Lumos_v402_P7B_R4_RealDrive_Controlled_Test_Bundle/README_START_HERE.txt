Lumos v402 P7-B R4 — REAL GOOGLE DRIVE CONTROLLED LIVE MIGRATION (operator bundle)

!! Use this bundle ONLY after the Architect has issued "P7-B R4 PREFLIGHT PASS". !!

What this is
- Lumos_v402_P7B_Manual_Sync_V7_R4_Candidate.html : the exact R4 Candidate (check SHA256SUMS.txt).
- P7B_R4_Controlled_Live_Migration_Console.js      : the one chosen controlled test (provider secret sync DISABLED,
                                                      the same choice as the R3 attempt).
- POST_VERIFY.txt                                   : what to check and what to send back.

Steps
1. Open Lumos_v402_P7B_Manual_Sync_V7_R4_Candidate.html directly by double-clicking it (file://). No local web server.
   Use the same browser profile as your normal Lumos (your data lives in that browser).
2. Make sure the sidebar badge shows "v402 R4". Do NOT press the Manual Sync button.
3. Open DevTools (F12) -> Console. Paste the whole content of P7B_R4_Controlled_Live_Migration_Console.js, press Enter.
4. It prints "P7-B R4 TRANSPORT" and "P7-B LIVE PRECHECK" (read-only). If it prints "P7-B R4 STOP", stop and send the log.
5. A confirm dialog shows mode / upload count. Press OK once to run ONE Manual Sync v7. (Cancel = nothing is written.)
6. Wait for "P7-B LIVE RESULT" and "P7-B POST VERIFY". Do not close the tab while it runs.
7. Follow POST_VERIFY.txt.

You do NOT need to delete anything on Google Drive. Folders/objects left by the failed R3 attempt are reused automatically.
Do not retry by yourself if the result is not "success" — send the log to the Architect.
