// Lumos v402 P7-B R4 — controlled live migration (provider secret sync DISABLED)
// Paste into DevTools Console of the R4 Candidate HTML opened directly as a local file (file://).
// One run = read-only precheck -> explicit confirm -> ONE Manual Sync v7 -> post-verify. Nothing runs without the confirm.
(async () => {
  const S = window.lumosDriveSyncV136, EXPECT = 'v402 R4';
  const stop = (why, extra) => { console.error('P7-B R4 STOP:', why, extra || ''); return { stopped: why }; };
  if (window.LUMOS_PATCH_VERSION !== EXPECT) return stop(`wrong build ${window.LUMOS_PATCH_VERSION} (expected ${EXPECT})`);
  if (location.protocol !== 'file:') return stop('open the Candidate HTML directly as a local file (file://) for this gate');
  const transport = S.p7TransportV402D();
  console.log('P7-B R4 TRANSPORT', transport);
  if (transport.write !== 'relay' || !transport.ready) return stop('Universal Relay write transport unavailable', transport);

  const plan = await S.p7PreviewSyncV402B({ interactive: true });   // READ-ONLY
  console.log('P7-B LIVE PRECHECK', { version: window.LUMOS_PATCH_VERSION, mode: plan.mode, planId: plan.planId, remoteHead: plan.remoteHead,
    uploadCount: plan.uploadCount, uploadBytes: plan.uploadBytes, invalidManifests: plan.invalidManifests, legacyFiles: plan.legacyFiles,
    unclassified: plan.unclassified, secret: plan.secret, transport: plan.transport });
  if (plan.unclassified.length) return stop('unclassified paths present — send this log to the Architect', plan.unclassified);
  if (!['migrate', 'join'].includes(plan.mode)) return stop(`unexpected mode ${plan.mode}`);

  if (!confirm(`P7-B R4 controlled live migration\n\nmode: ${plan.mode}\nobjects to upload: ${plan.uploadCount}\nprovider secret sync: DISABLED\nwrite transport: Universal Relay\n\nRun ONE Manual Sync v7 now?`))
    return stop('operator cancelled (nothing written)');

  const live = await S.p7ManualSyncV402B({ interactive: true, acceptPlanId: plan.planId, acceptUnclassified: false, disableSecretSync: true });
  console.log('P7-B LIVE RESULT', live);

  const status = S.p7StatusV402B();
  const verify = await S.p7PreviewSyncV402B({ interactive: true });   // READ-ONLY
  const post = { live: { ok: live.ok, status: live.status, result: live.result, core: live.core, extension: live.extension },
    status: { active: status.active, migrated: status.migrated, base: status.base, secret: status.secret, transport: status.transport },
    verify: { version: window.LUMOS_PATCH_VERSION, mode: verify.mode, remoteHead: verify.remoteHead, counts: verify.counts, uploadCount: verify.uploadCount,
      unclassified: verify.unclassified, localRootEqualsHead: !!verify.remoteHead && verify.localRoot === verify.remoteHead.root } };
  console.log('P7-B POST VERIFY', post);
  return post;
})();
