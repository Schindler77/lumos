// Lumos P7 R0 — deterministic synthetic Lumos-shaped profiles (field names from exact v400 source).
export function rng(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const SYL='가나다라마바사아자차카타파하고노도로모보소오조초코토포호그느드르므브스으즈츠크트프흐는을를이가에서로와과도만의'.split('');
function words(r,n){let s='';while(s.length<n){const w=1+Math.floor(r()*4);for(let i=0;i<w;i++)s+=SYL[Math.floor(r()*SYL.length)];s+=r()<0.12?'. ':' ';}return s.slice(0,n);}
const PNG1x1='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

export function makeProfile({seed=7,novels=5,turns=20,chars=300,noise=false,noiseScale=1,withImages=true}={}){
  const r=rng(seed),rn=rng(seed^0x5bd1e995),T0=1_790_000_000_000; // noise uses its own stream so canonical content is identical with/without noise
  const chats=[];
  for(let i=0;i<novels;i++){
    const history=[];
    for(let t=0;t<turns;t++){
      const role=t%2?'model':'user';const text=words(r,role==='model'?chars:Math.max(20,chars/6|0));
      const m={role,text,turnNumberV216:t+1};
      if(role==='model'){m.textOriginal=text;m.translationState='original';if(t%17===5)m.bookmarked=true;if(t%13===3)m.rating=1;}
      if(noise){
        m.rawResponse=JSON.stringify({id:`resp_${i}_${t}`,choices:[{message:{content:text}}],usage:{prompt_tokens:1000+t,completion_tokens:200},debug:'x'.repeat(2400*noiseScale)});
        m.translationDiagnostics={residual:0,stages:['a','b'],blob:'d'.repeat(300*noiseScale)};
        m.requestTraceV261={at:T0+t,dialect:'claude-native',effectiveTokenValue:8192};
        m.outputRangePreviousTextV185=text.slice(0,Math.min(text.length,400));
        m.replayCache=[text,text];
      }
      history.push(m);
    }
    const chat={id:`chat-${i}`,novelId:`nov-${String(i).padStart(3,'0')}`,title:`이야기 ${i}`,worldId:`world-${i%3}`,characterIds:[`char-${i%4}`,`char-${(i+1)%4}`],
      history,memory:words(r,120),authorsNote:words(r,60),isNovelMode:i%2===0,writingMode:i%3===0?'nai':'novel',naiContent:i%3===0?words(r,chars):'',
      chapters:[{title:'1장',startTurn:1}],bookmarks:[],localLorebook:[{key:'장소',content:words(r,80)}],
      updatedAt:T0+i*1000,createdAt:T0-i*1000,_lumosProgressUpdatedAt:T0+i,
      novelSyncV136:{novelId:`nov-${String(i).padStart(3,'0')}`,revision:3,updatedAt:T0+i*1000,contentHash:'abcd',baseHash:'abcd',ancestors:[],updatedBy:'dev-A',lastSyncedAt:T0},
      lastInteractionTraceV264:{at:T0+i},geminiExplicitCacheV107:{name:`cachedContents/${i}`,expire:T0+3600e3},cacheId:`c${i}`,cacheExpireTime:T0+3600e3,cacheContextHash:`h${i}`};
    if(withImages&&i===0)chat.representativeImageDataUrl=PNG1x1;
    if(noise){
      chat.replayCache=Array.from({length:6},(_,k)=>words(rn,chars*2));
      chat.rerollScratch={candidates:Array.from({length:4},()=>words(rn,chars))};
      chat.previewObjectUrl=`blob:file:///preview-${i}`;
      chat.imagePreviewCache={thumb:'data:image/png;base64,'+'A'.repeat(20000*noiseScale)};
      chat.novelContextStatsV125={tokens:12345,at:T0};chat.longMemoryLastRecallV110={items:[1,2,3],at:T0};
    }
    chats.push(chat);
  }
  const worlds=[0,1,2].map(w=>({id:`world-${w}`,name:`세계 ${w}`,characters:[0,1,2,3].map(c=>({id:`char-${c}`,name:`인물 ${c}`,description:words(r,200)})),lorebook:[{key:'도시',content:words(r,150)}]}));
  const DB={chats,worlds,chatGroups:[{id:'g1',name:'연재',chatIds:['chat-0','chat-1']}],chatSidebarOrder:chats.map(c=>c.id),
    entityLifecycleV265:[{type:'chat',id:'nov-deleted',state:'DELETED',at:T0}],novelUserTrashV265:[],novelBranchTombstonesV229:[]};
  if(noise){
    DB.novelSyncConflictsV228=chats.slice(0,Math.min(20,chats.length)).map(c=>({novelId:c.novelId,copy:JSON.parse(JSON.stringify({...c,history:c.history.map(h=>({role:h.role,text:h.text}))}))}));
    DB.novelCleanupTrashV154=chats.slice(0,Math.min(10,chats.length)).map(c=>({novelId:c.novelId,quarantinedAt:T0,chat:{id:c.id,title:c.title,history:c.history.map(h=>({role:h.role,text:h.text}))}}));
    DB.novelSyncConflictVaultV390S2A={count:20,fingerprint:'x',ready:true};
  }
  const SETTINGS={
    apiKey:'AIzaSy-SYNTHETIC-GEMINI-KEY-000001',openaiApiKey:'sk-SYNTHETIC-OPENAI-000002',ollamaApiKey:'ollama-SYNTHETIC-000003',naiToken:'pst-SYNTHETIC-NAI-000004',
    currentModel:'claude-sonnet',temperature:0.9,fontSize:16,darkMode:true,fontFamily:'Noto Serif KR',promptStyle:'novel',outputLength:2,
    toggle_길이:2,toggle_전개:1,novelStyle:'literary',naiMaxTokens:250,rightStudioActiveTab:'memo',
    customModels:[
      {id:'cm-claude',name:'Claude',modelId:'claude-sonnet-4-5',url:'https://api.anthropic.com/v1/messages',apiKey:'sk-ant-SYNTHETIC-000005',format:'claude',useStreaming:true},
      {id:'cm-proxy',name:'Proxy',modelId:'gpt-4o',url:'https://api.openai.com/v1/chat/completions',proxyUrl:'https://proxy.example.invalid',proxyApiKey:'SYNTHETIC-PROXY-TOKEN-000006',format:'openai'},
      {id:'cm-bridge',name:'Risu bridge',risuPluginIdV190:'plugin-x',modelId:'x'}],
    customPromptModes:[{id:'pm-1',title:'비망록',prompt:'시스템 프롬프트 '+words(r,400)}],
    globalLorebook:[{id:'lb-1',key:'왕국',content:words(r,200)}],coreRules:[],dicRules:[],
    risuModulesV226:[{id:'mod-1',name:'비망록 모듈',enabled:true}],manualEnabledModuleIdsV226:['mod-1','mod-0','mod-1'],
    naiCharacterRefImage:PNG1x1,providerCoreV134:{routing:'auto'},modelProfiles:{default:{temperature:0.9}}
  };
  if(noise){
    SETTINGS.claudeCacheAuditV68=Array.from({length:200*noiseScale},(_,k)=>({at:T0+k,hit:k%2,detail:'z'.repeat(400)}));
    SETTINGS.universalRelayLastRuntimeV106={at:T0,headers:{a:1}};SETTINGS.claudeNativeCacheMigratedCountV68=3;
    SETTINGS.__lumosRuntimeScratch={big:'q'.repeat(50000*noiseScale)};SETTINGS.lastErrorV300={message:'boom'};
  }
  const risuPlugins={format:'lumos-risu-plugins-v213',plugins:[{id:'plugin-x',name:'X',enabled:true,settings:{a:1}}]};
  const runtime={telemetry:{frames:Array.from({length:noise?5000*noiseScale:10},(_,k)=>({k,ms:k%17}))},
    driveAuth:{access_token:'ya29.SYNTHETIC-DRIVE-ACCESS-000007',refresh_token:'1//SYNTHETIC-DRIVE-REFRESH-000008'},relayToken:'SYNTHETIC-RELAY-TOKEN-000009'};
  return{DB,SETTINGS,risuPlugins,runtime};
}
export const SECRET_STRINGS=['AIzaSy-SYNTHETIC-GEMINI-KEY-000001','sk-SYNTHETIC-OPENAI-000002','ollama-SYNTHETIC-000003','pst-SYNTHETIC-NAI-000004','sk-ant-SYNTHETIC-000005','SYNTHETIC-PROXY-TOKEN-000006','ya29.SYNTHETIC-DRIVE-ACCESS-000007','1//SYNTHETIC-DRIVE-REFRESH-000008','SYNTHETIC-RELAY-TOKEN-000009'];
