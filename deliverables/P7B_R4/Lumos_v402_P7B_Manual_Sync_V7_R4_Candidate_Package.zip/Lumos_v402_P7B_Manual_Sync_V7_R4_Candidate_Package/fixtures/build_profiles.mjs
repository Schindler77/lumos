// Deterministic synthetic Lumos profiles for the P7-B harness (from the accepted R0 generator).
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {makeProfile,SECRET_STRINGS} from './p7_fixtures.mjs';
const DIR=path.dirname(fileURLToPath(import.meta.url));
const strip=p=>({DB:p.DB,SETTINGS:p.SETTINGS});
const base=strip(makeProfile({seed:77,novels:100,turns:4,chars:120}));
base.SETTINGS.agentPhase1Prompt='기본 에이전트 프롬프트\n'+'문장 '.repeat(40);
base.DB.chatCount=100;base.DB.worldCount=3;base.DB.localSlot=true;
const small=strip(makeProfile({seed:78,novels:6,turns:4,chars:100}));
const out={base,small,secretStrings:SECRET_STRINGS};
const text=JSON.stringify(out);
if(process.argv.includes('--check')){const ok=fs.readFileSync(path.join(DIR,'profiles.json'),'utf8')===text;console.log(JSON.stringify({profilesMatch:ok}));process.exitCode=ok?0:1}
else{fs.writeFileSync(path.join(DIR,'profiles.json'),text);console.log('written',text.length)}
