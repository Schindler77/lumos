#!/usr/bin/env python3
"""Deterministic P7-B R4 builder: exact P7-A R5 OFFICIAL ->
  (1) lumos-v136-drive-sync-script body := R5 v136 + P7-B v7 block (R3/R2 semantics + R4 file-origin write transport),
  (2) lumos-v379-version-authority: global release identity v390 R12 -> v402 R4 (one constant line),
  (3) document <title> and <meta name="lumos-build"> -> v402 R4.
Nothing else changes (P7-A module stays the exact R5 body).

    python3 build_p7b_candidate.py <R5 OFFICIAL html> <p7b_v7_block.js> <out html>
"""
import hashlib, sys
from pathlib import Path
PARENT_SHA='48bc0e57d6256aef189086548d3061add6c8a9cee5683f401dbf4b291f77d17d'
V136_SHA='ca59900f2dcbfed271b937a4c42a4586130045b2ea2ca3910527162589d11537'
V136_R4_SHA='f93bbfbbacf00b97a4caf18c82b92154bfbda8ec6b9ae20a63a1bc612cebf9e1'  # reviewed R4 v136 body
OLD_ID=("const VERSION='v390 R12', BUILD='v390-r12-eil-h9-safe-proof-strict-batch-integration', TITLE='Lumos 3.0 · v390 R12 EIL H9 Safe Proof & Strict Batch · Manual Sync';")
NEW_ID=("const VERSION='v402 R4', BUILD='v402-p7b-manual-sync-v7-r4', TITLE='Lumos 3.0 · v402 R4 P7-B Manual Sync v7';")
DOC=[('<title>Lumos 3.0 · v390 R12 EIL H9 Safe Proof &amp; Strict Batch · Manual Sync</title>','<title>Lumos 3.0 · v402 R4 P7-B Manual Sync v7</title>'),
     ('<title>Lumos 3.0 · v390 R12 EIL H9 Safe Proof & Strict Batch · Manual Sync</title>','<title>Lumos 3.0 · v402 R4 P7-B Manual Sync v7</title>'),
     ('<meta name="lumos-build" content="v390-r12-eil-h9-safe-proof-strict-batch-integration">','<meta name="lumos-build" content="v402-p7b-manual-sync-v7-r4">')]
def span(src, sid):
    op=f'<script id="{sid}">'.encode(); a=src.index(op)+len(op); b=src.index(b'</script>',a)
    if src.count(op)!=1: raise SystemExit('TAG_COUNT '+sid)
    return a,b
def once(t,a,b):
    if t.count(a)!=1: raise SystemExit(f'ANCHOR_COUNT_{t.count(a)}: {a[:70]!r}')
    return t.replace(a,b)
def v136_r4(v136, block):
    t=v136.decode('utf-8'); blk=Path(block).read_text('utf-8')
    if '</script' in blk.lower(): raise SystemExit('BLOCK_HAS_SCRIPT_CLOSE')
    t=once(t,'window.lumosDriveSyncV136={version:389,',blk.rstrip('\n')+'\n\n  window.lumosDriveSyncV136={version:389,'
        +'p7PreviewSyncV402B:(o)=>p7PreviewSyncV402B(o||{}),p7SyncV402B:(o)=>p7SyncV402B(o||{}),p7ManualSyncV402B:(o)=>p7ManualSyncV402B(o||{}),p7StatusV402B,p7SetEnabledV402B,p7SetSecretSyncV402B,p7ResetLocalBaseV402B,'
        +'p7TransportV402D,'
        +'_legacySyncV246:(o)=>syncUnifiedV246(o||{interactive:true}),_p7TestV402B:{bodyCache:p7BodyCacheV402B,manifestCache:p7ManifestCacheV402B,secretPathCount:()=>Object.keys(p7CollectSecretsV402B(SETTINGS)).length,objectName:e=>p7ObjectNameV402B(e),multipart:(m,x)=>p7MultipartV402D(m,x)},')
    t=once(t,'        const ok=await syncUnifiedV246({interactive:true,force:!!force});',
        "        const ok=p7ActiveV402B()?((await p7ManualSyncV402B({interactive:true,source:'manual'})).ok===true):await syncUnifiedV246({interactive:true,force:!!force});")
    return t.encode('utf-8')
def build(parent, block, out):
    src=Path(parent).read_bytes()
    if hashlib.sha256(src).hexdigest()!=PARENT_SHA: raise SystemExit('PARENT_SHA_MISMATCH')
    a,b=span(src,'lumos-v136-drive-sync-script')
    if hashlib.sha256(src[a:b]).hexdigest()!=V136_SHA: raise SystemExit('V136_SHA_MISMATCH')
    nv=v136_r4(src[a:b],block)
    if V136_R4_SHA and hashlib.sha256(nv).hexdigest()!=V136_R4_SHA: raise SystemExit('V136_NOT_REVIEWED_R4')
    src=src[:a]+nv+src[b:]
    a,b=span(src,'lumos-v379-version-authority')
    src=src[:a]+once(src[a:b].decode('utf-8'),OLD_ID,NEW_ID).encode('utf-8')+src[b:]
    t=src.decode('utf-8'); n=0
    for old,new in DOC:
        if t.count(old)==1: t=t.replace(old,new); n+=1
    if n!=2: raise SystemExit('DOC_IDENTITY_ANCHORS')
    outb=t.encode('utf-8'); Path(out).write_bytes(outb); return hashlib.sha256(outb).hexdigest()
if __name__=='__main__': print(build(sys.argv[1],sys.argv[2],sys.argv[3]))
