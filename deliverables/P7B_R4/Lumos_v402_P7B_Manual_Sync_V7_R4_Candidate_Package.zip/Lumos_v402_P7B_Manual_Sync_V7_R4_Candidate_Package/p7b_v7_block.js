
  // ======================================================================================
  // P7-B v402b — Manual Sync v7 (manifest-first, changed-object transfer, revision fence)
  // Canonical/fingerprint authority: window.LumosP7CanonicalV401A (P7-A R4, consumed as-is).
  // Nothing here runs at load. Startup sync stays OFF. Legacy v6 files are only read, never
  // written or deleted by v7. No GC/delete of any Drive file.
  // R4 (v402d): every P7 Drive WRITE goes through p7DriveWriteV402D. On a standalone file:// page
  // (origin "null") it uses the existing Lumos Universal Relay (window.LumosUniversalRelay106) from the
  // start with an explicit multipart/related string body — never a direct Google upload first, never
  // FormData through the relay, never a direct fallback after a relay failure. http(s) pages keep the
  // R3 direct path. READ/LIST/download stay direct (driveFetch).
  // ======================================================================================
  const P7_FOLDERS_V402B=Object.freeze({manifests:'lumos-p7-manifests',objects:'lumos-p7-objects',secrets:'lumos-p7-secrets'});
  const P7_MAX_ATTEMPTS_V402B=4;
  const P7_CONFLICT_FIELD_V402B='p7ConflictRecordsV402B';
  const P7_ORDER_FIELD_V402B='$collectionOrder';
  const P7_ITEM_DOMAINS_V402B=new Set(['settings.customPromptModes','settings.globalLorebook','settings.inputTemplates','settings.customModels','extension.risuPlugin']);
  const P7_SECRET_EXCLUDE_RE_V402B=/oauth|googledrive|driveauth|universalrelay|relaytoken/i;
  const p7BodyCacheV402B=new Map();          // disposable acceleration only; every use is re-verified
  const p7ManifestCacheV402B=new Map();      // manifest files are immutable (append-only names)
  let p7PlanV402B=null;                      // in-memory dry-run plan (never persisted)
  let p7LastReportV402B=null;
  let p7LastManualV402B=null;

  function p7ApiV402B(){const A=window.LumosP7CanonicalV401A;if(!A||A.canonicalSchema!=='lumos.canonical.v1'||typeof A.buildFingerprintBundle!=='function')throw new Error('P7-A canonical module(LumosP7CanonicalV401A)을 찾을 수 없습니다.');return A}
  const p7Utf8V402B=text=>new TextEncoder().encode(String(text));

  // ---- R4 write transport (P7 writes only; legacy v6 writes and all reads are untouched) ----------------
  function p7FileOriginV402D(){try{return String(location.protocol||'')==='file:'}catch(_){return false}}
  function p7RelayV402D(){try{const r=window.LumosUniversalRelay106;return r&&typeof r.fetch==='function'?r:null}catch(_){return null}}
  function p7TransportV402D(){const file=p7FileOriginV402D(),relay=!!p7RelayV402D();return{origin:file?'file':'http',write:file?'relay':'direct',relayAvailable:relay,ready:!file||relay}}
  // The relay entry point is the Provider Core (v134) monitored fetch. Its first call normalizes SETTINGS.providerCoreV134 — a
  // canonical settings field — so it is normalized once (public, idempotent v134 API) before the sync reads local state;
  // otherwise the first relay write would move the local canonical root mid-sync and the apply guard would abort.
  function p7PrimeRelayV402D(){try{const pc=window.LumosProviderCore134;if(pc&&typeof pc.settings==='function')pc.settings()}catch(_){}}
  function p7TransportErrorV402D(message){const err=new Error(message);err.p7TransportV402D=true;return err}
  function p7SafeTextV402D(text,token){let s=String(text||'');if(token)s=s.split(token).join('[REDACTED]');return s.replace(/bearer\s+[A-Za-z0-9._~+\/=-]+/gi,'Bearer [REDACTED]').slice(0,300)}
  function p7BoundaryV402D(...parts){
    for(;;){const a=new Uint8Array(18);crypto.getRandomValues(a);const b='lumos_p7_'+[...a].map(x=>x.toString(16).padStart(2,'0')).join('');if(!parts.some(p=>String(p).includes(b)))return b}
  }
  // Drive multipart/related upload body as a plain string (UTF-8 on the wire): part 1 = metadata JSON, part 2 = content JSON.
  function p7MultipartV402D(meta,text){
    const metaText=JSON.stringify(meta),boundary=p7BoundaryV402D(metaText,text);
    const body=`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metaText}\r\n--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${String(text)}\r\n--${boundary}--`;
    return{body,contentType:`multipart/related; boundary=${boundary}`};
  }
  async function p7DriveWriteV402D(url,options={},interactive=true,retry=true){
    if(!p7FileOriginV402D())return driveFetch(url,options,interactive);                       // http(s): R3 direct path
    const relay=p7RelayV402D();
    if(!relay)throw p7TransportErrorV402D('P7_RELAY_UNAVAILABLE: file:// 쓰기 전송(Universal Relay)을 찾을 수 없습니다.');
    const method=String(options.method||'POST').toUpperCase(),body=options.body;
    if(method!=='POST'||typeof body!=='string')throw p7TransportErrorV402D('P7_RELAY_BODY: Relay 쓰기는 문자열 본문 POST만 허용됩니다.');
    const token=await requestToken(interactive);
    const headers={};new Headers(options.headers||{}).forEach((v,k)=>{if(k!=='authorization')headers[k]=v});
    headers.Authorization=`Bearer ${token}`;                                                  // transient upstream header only
    const req={method:'POST',headers,body,cache:'no-store'};
    const signal=options.signal||state.startupPreflightControllerV247?.signal;if(signal)req.signal=signal;
    let res;
    try{res=await relay.fetch(url,req,{requestKind:'drive-sync-p7',label:'P7 Drive write'})}
    catch(e){if(e?.name==='AbortError')throw e;throw p7TransportErrorV402D(`P7 Relay 전송 실패: ${p7SafeTextV402D(e?.message||e,token)}`)}
    const upstream=Number(res.headers?.get?.('X-Lumos-Upstream-Status'))||Number(res.status)||0;
    if(upstream===401&&retry){try{await res.body?.cancel?.()}catch(_){}state.accessToken='';state.tokenExpiresAt=0;state.connected=false;return p7DriveWriteV402D(url,options,interactive,false)}
    if(!res.ok||upstream<200||upstream>=300){const t=await res.text().catch(()=>'');throw p7TransportErrorV402D(`Google Drive ${upstream||res.status} (relay): ${p7SafeTextV402D(t,token)||res.statusText||'error'}`)}
    return res;
  }
  async function p7CreateFolderV402D(name,parents,appProperties,fields,interactive){
    const res=await p7DriveWriteV402D(`${API_ROOT}/files?fields=${fields}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,mimeType:FOLDER_MIME,parents,appProperties})},interactive);
    return await res.json();
  }
  // Rumos root for P7: same lookup + same folder metadata as legacy ensureFolder(), but the create (only if absent) is a P7 write.
  async function p7EnsureRootV402D(interactive){
    let folder=await findFolder(interactive);
    if(!folder)folder=await p7CreateFolderV402D(FOLDER_NAME,['root'],{lumos:'drive-sync-v136'},'id,name,modifiedTime',interactive);
    if(folder){config.folderId=folder.id;saveConfig()}
    return folder;
  }
  function p7CfgV402B(){
    if(!config.p7V402B||typeof config.p7V402B!=='object')config.p7V402B={};
    const c=config.p7V402B;
    if(typeof c.enabled!=='boolean')c.enabled=false;
    if(typeof c.migrated!=='boolean')c.migrated=false;
    if(!('base' in c))c.base=null;
    if(!Number.isFinite(Number(c.nonceSeq)))c.nonceSeq=0;
    if(!Number.isFinite(Number(c.secretSeq)))c.secretSeq=0;
    if(!c.secretClocks||typeof c.secretClocks!=='object')c.secretClocks={};
    if(!c.pendingAssets||typeof c.pendingAssets!=='object')c.pendingAssets={};
    return c;
  }
  function p7LegacyUsedV402B(){return !!(config.everConnected||Number(config.lastSyncAt)||config.folderId||config.fileId||config.novelFileId||config.lastCloudChecksum)}
  function p7SecretPolicyV402B(){
    const c=p7CfgV402B();
    if(!c.secret||typeof c.secret!=='object'){const existing=p7LegacyUsedV402B();c.secret={enabled:existing,disclosed:false,source:existing?'existing-install':'new-install'}}
    return c.secret;
  }
  function p7WriterV402B(){return 'w'+p7ApiV402B().sha256HexSync(String(deviceId())).slice(0,16)}
  function p7NonceV402B(){const c=p7CfgV402B();c.nonceSeq=Number(c.nonceSeq||0)+1;return now().toString(36).padStart(10,'0')+Number(c.nonceSeq).toString(36).padStart(4,'0')}
  const p7KeyV402B=(domain,id)=>`${domain}\u0000${id}`;
  function p7ObjectNameV402B(e){return `o-${p7ApiV402B().sha256HexSync(e.domain+'\u0000'+e.id).slice(0,32)}-${e.hash}.json`}
  function p7ManifestNameV402B(rev,writer,nonce){return `${String(rev).padStart(10,'0')}-${writer}-${nonce}.json`}
  function p7ParseManifestNameV402B(name){const m=/^(\d{10})-([a-z0-9]+)-([a-z0-9]+)\.json$/.exec(String(name||''));return m?{rev:Number(m[1]),writer:m[2],nonce:m[3]}:null}
  function p7OrderDescV402B(a,b){return b.rev-a.rev||(a.writer<b.writer?1:a.writer>b.writer?-1:0)||(a.nonce<b.nonce?1:a.nonce>b.nonce?-1:0)}

  // ---- run context: metrics + status trail --------------------------------------------------
  function p7NewRunV402B(label){return{label,trail:['idle'],metrics:{bodyUploads:0,bodyUploadBytes:0,bodyDownloads:0,bodyDownloadBytes:0,manifestWrites:0,manifestUploadBytes:0,manifestReads:0,manifestDownloadBytes:0,secretWrites:0,secretReads:0,listCalls:0,folderCreates:0},
    planned:{uploadCount:0,uploadBytes:0,downloadCount:0,downloadBytes:0},cacheHits:0,cacheRejects:0}}
  function p7PhaseV402B(run,phase,message){
    if(run.trail[run.trail.length-1]!==phase)run.trail.push(phase);
    try{patchManualSyncActivityV391({p7PhaseV402B:phase,p7TrailV402B:run.trail.slice()})}catch(_){}
    if(message)setOperation(message);
  }

  // ---- Drive helpers (paginated; P7 namespace only) -------------------------------------------
  async function p7ListAllV402B(run,q,interactive){
    const out=[];let pageToken='',pages=0;
    do{
      const p=new URLSearchParams({q,spaces:'drive',pageSize:'1000',fields:'nextPageToken,files(id,name,size,createdTime)'});
      if(pageToken)p.set('pageToken',pageToken);
      const res=await driveFetch(`${API_ROOT}/files?${p}`,{},interactive);const data=await res.json();run.metrics.listCalls++;
      for(const f of Array.isArray(data.files)?data.files:[])out.push(f);
      pageToken=String(data.nextPageToken||'');if(++pages>100000)throw new Error('P7 Drive listing did not terminate');
    }while(pageToken);
    return out;
  }
  async function p7FoldersV402B(run,rootId,kind,interactive,create){
    const name=P7_FOLDERS_V402B[kind];
    let list=await p7ListAllV402B(run,`name='${escapeQ(name)}' and mimeType='${FOLDER_MIME}' and '${escapeQ(rootId)}' in parents and trashed=false`,interactive);
    if(!list.length&&create){
      list=[await p7CreateFolderV402D(name,[rootId],{lumos:'p7-v402b',kind},'id,name,createdTime',interactive)];run.metrics.folderCreates++;
    }
    return list.slice().sort((a,b)=>String(a.createdTime||'').localeCompare(String(b.createdTime||''))||String(a.id).localeCompare(String(b.id)));
  }
  async function p7ListChildrenV402B(run,folders,interactive){
    if(!folders.length)return[];
    const parents=folders.map(f=>`'${escapeQ(f.id)}' in parents`).join(' or ');
    return p7ListAllV402B(run,`(${parents}) and trashed=false`,interactive);
  }
  async function p7ReadTextV402B(fileId,interactive){const res=await driveFetch(`${API_ROOT}/files/${encodeURIComponent(fileId)}?alt=media`,{},interactive);return await res.text()}
  async function p7CreateTextV402B(folderId,name,text,props,interactive){
    const meta={name,mimeType:'application/json',parents:[folderId],appProperties:props},url=`${UPLOAD_ROOT}/files?uploadType=multipart&fields=id,name,size,createdTime`;
    if(p7FileOriginV402D()){const mp=p7MultipartV402D(meta,text);return await (await p7DriveWriteV402D(url,{method:'POST',headers:{'Content-Type':mp.contentType},body:mp.body},interactive)).json()}
    const form=new FormData();form.append('metadata',new Blob([JSON.stringify(meta)],{type:'application/json'}));form.append('file',new Blob([text],{type:'application/json'}));
    const res=await driveFetch(url,{method:'POST',body:form},interactive);return await res.json();
  }

  // ---- remote snapshot: folders, listings, authoritative head ------------------------------------
  async function p7RemoteV402B(run,interactive,create){
    const root=create?await p7EnsureRootV402D(interactive):await findFolder(interactive);
    if(!root)return{root:null,folders:{manifests:[],objects:[],secrets:[]},manifests:[],objects:new Map()};
    const folders={};for(const kind of Object.keys(P7_FOLDERS_V402B))folders[kind]=await p7FoldersV402B(run,root.id,kind,interactive,create);
    return{root,folders,...await p7ListingsV402B(run,folders,interactive)};
  }
  async function p7ListingsV402B(run,folders,interactive){
    const manifests=(await p7ListChildrenV402B(run,folders.manifests,interactive)).map(f=>({...f,...(p7ParseManifestNameV402B(f.name)||{})})).filter(f=>Number.isFinite(f.rev));
    const objects=new Map();for(const f of await p7ListChildrenV402B(run,folders.objects,interactive))if(!objects.has(f.name))objects.set(f.name,f);
    return{manifests,objects};
  }
  async function p7LoadManifestV402B(run,file,interactive){
    if(p7ManifestCacheV402B.has(file.name))return p7ManifestCacheV402B.get(file.name);
    const text=await p7ReadTextV402B(file.id,interactive);run.metrics.manifestReads++;run.metrics.manifestDownloadBytes+=p7Utf8V402B(text).length;
    let m=null;try{m=JSON.parse(text)}catch(_){m={__invalid:'parse'}}
    p7ManifestCacheV402B.set(file.name,m);return m;
  }
  function p7ManifestProblemV402B(m,file,objects){
    const A=p7ApiV402B();
    if(!m||m.__invalid)return 'parse';
    const v=A.validateManifestPreview(m);if(!v.valid)return 'shape:'+v.issues.join(',');
    if(m.revision!==file.rev||m.writer!==file.writer)return 'name-mismatch';
    for(const e of m.objects)if(!objects.has(p7ObjectNameV402B(e)))return 'missing-body';
    return null;
  }
  async function p7ResolveHeadV402B(run,remote,interactive){
    const sorted=remote.manifests.slice().sort(p7OrderDescV402B),invalid=[];
    for(const f of sorted){
      const m=await p7LoadManifestV402B(run,f,interactive),problem=p7ManifestProblemV402B(m,f,remote.objects);
      if(problem){invalid.push({name:f.name,why:problem});continue}
      return{head:{name:f.name,rev:f.rev,writer:f.writer,nonce:f.nonce,manifest:m},invalid,siblings:sorted.filter(x=>x.rev===f.rev&&x.name!==f.name).map(x=>x.name)};
    }
    return{head:null,invalid,siblings:[]};
  }

  // ---- base lineage: recorded base must lie on the head's ancestry; otherwise use the common ancestor ----
  async function p7LineageV402B(run,remote,start,interactive,depth=64){
    const byName=new Map(remote.manifests.map(f=>[f.name,f])),chain=[];let cur=start;
    while(cur&&chain.length<depth){
      const f=byName.get(cur);if(!f)break;const m=await p7LoadManifestV402B(run,f,interactive);if(p7ManifestProblemV402B(m,f,remote.objects))break;
      chain.push({name:cur,manifest:m});cur=m.parentNameV402B||null;
    }
    return chain;
  }
  async function p7BaseEntriesV402B(run,remote,head,baseName,interactive){
    if(!baseName||!head)return{entries:null,kind:'none'};
    const headChain=await p7LineageV402B(run,remote,head.name,interactive);
    const hit=headChain.find(x=>x.name===baseName);
    if(hit)return{entries:p7EntriesV402B(hit.manifest),kind:hit.name===head.name?'head':'ancestor'};
    const headNames=new Set(headChain.map(x=>x.name));
    for(const x of await p7LineageV402B(run,remote,baseName,interactive))if(headNames.has(x.name))return{entries:p7EntriesV402B(x.manifest),kind:'common-ancestor',name:x.name};
    return{entries:null,kind:'unrelated'};
  }

  // ---- bodies: download + verify (cache never authority) ------------------------------------------
  async function p7FetchBodyV402B(run,remote,e,interactive){
    const A=p7ApiV402B(),key=p7KeyV402B(e.domain,e.id)+'\u0000'+e.hash;
    const verify=text=>{const bytes=p7Utf8V402B(text);return bytes.length===e.size&&A.sha256HexSync(bytes)===e.hash};
    if(p7BodyCacheV402B.has(key)){const text=p7BodyCacheV402B.get(key);if(verify(text)){run.cacheHits++;return JSON.parse(text)}p7BodyCacheV402B.delete(key);run.cacheRejects++}
    const f=remote.objects.get(p7ObjectNameV402B(e));
    if(!f){const err=new Error(`INVALID_REMOTE: 객체 본문 누락 (${e.domain})`);err.p7InvalidRemote=true;throw err}
    const text=await p7ReadTextV402B(f.id,interactive),bytes=p7Utf8V402B(text);
    run.metrics.bodyDownloads++;run.metrics.bodyDownloadBytes+=bytes.length;run.planned.downloadCount++;run.planned.downloadBytes+=e.size;
    if(!verify(text)){const err=new Error(`INVALID_REMOTE: 객체 본문 해시/크기 불일치 (${e.domain})`);err.p7InvalidRemote=true;throw err}
    p7BodyCacheV402B.set(key,text);return JSON.parse(text);
  }

  // ---- canonical object access (lumos.canonical.v1 layout) ------------------------------------------
  function p7GetObjV402B(c,domain,id){
    if(domain==='novel')return c.novels[id];if(domain==='world')return c.worlds[id];if(domain==='settings.field')return c.settings.fields[id];
    if(domain.startsWith('settings.'))return (c.settings.collections[domain.slice(9)]||{})[id];
    if(domain==='library')return c.library;if(domain==='lifecycle')return c.lifecycle;
    if(domain==='extension.setting')return c.extensions[id];if(domain==='extension.risuPlugin')return (c.extensions.risuPlugins||{})[id];
  }
  function p7SetObjV402B(c,domain,id,body){
    const put=(o,k)=>{if(body===undefined)delete o[k];else o[k]=clone(body)};
    if(domain==='novel')return put(c.novels,id);if(domain==='world')return put(c.worlds,id);if(domain==='settings.field')return put(c.settings.fields,id);
    if(domain.startsWith('settings.')){const n=domain.slice(9);c.settings.collections[n]=c.settings.collections[n]||{};return put(c.settings.collections[n],id)}
    if(domain==='library'){c.library=clone(body||{});return}if(domain==='lifecycle'){c.lifecycle=clone(body||{});return}
    if(domain==='extension.setting')return put(c.extensions,id);
    if(domain==='extension.risuPlugin'){c.extensions.risuPlugins=c.extensions.risuPlugins||{};return put(c.extensions.risuPlugins,id)}
    throw new Error('P7 unknown domain '+domain);
  }
  const p7IsAssetV402B=v=>!!(v&&typeof v==='object'&&!Array.isArray(v)&&typeof v.$asset==='string');
  function p7StripAssetsV402B(v){if(Array.isArray(v))return v.map(p7StripAssetsV402B);if(v&&typeof v==='object'){const o={};for(const [k,x] of Object.entries(v))if(!p7IsAssetV402B(x))o[k]=p7StripAssetsV402B(x);return o}return v}
  function p7UnionV402B(r,l){
    const A=p7ApiV402B();
    if(Array.isArray(r)&&Array.isArray(l)){const out=[...r];const seen=new Set(r.map(x=>A.canonicalJSON(x)));for(const x of l){const c=A.canonicalJSON(x);if(!seen.has(c)){seen.add(c);out.push(x)}}return out}
    if(r&&l&&typeof r==='object'&&typeof l==='object'&&!Array.isArray(r)&&!Array.isArray(l)){const out={};for(const k of [...new Set([...Object.keys(r),...Object.keys(l)])].sort())out[k]=(k in r&&k in l)?p7UnionV402B(r[k],l[k]):(k in r?r[k]:l[k]);return out}
    return r!==undefined?r:l;
  }

  // ---- local canonical (P7-A as-is) + pending-asset equivalence -------------------------------------
  function p7LocalV402B(){
    const A=p7ApiV402B(),ex=A.extractCanonical({DB,SETTINGS});
    const objects=A.buildObjectFingerprints(ex.canonical),pend=p7CfgV402B().pendingAssets,map=new Map();
    for(const e of objects){const k=p7KeyV402B(e.domain,e.id),p=pend[k];map.set(k,p&&p.localHash===e.hash?{...e,hash:p.remoteHash,size:p.remoteSize,pendingAsset:true}:e)}
    for(const [k,p] of Object.entries(pend))if(p&&p.localHash===null&&!map.has(k)){const [domain,id]=k.split('\u0000');map.set(k,{domain,id,hash:p.remoteHash,size:p.remoteSize,pendingAsset:true})}
    return{canonical:ex.canonical,report:ex.report,entries:map};
  }
  function p7EntriesV402B(manifest){return new Map((manifest?.objects||[]).map(e=>[p7KeyV402B(e.domain,e.id),e]))}
  function p7DecideV402B(L,R,B){
    const keys=[...new Set([...L.keys(),...(R?R.keys():[]),...(B?B.keys():[])])].sort(),out=[];
    for(const k of keys){
      const [domain,id]=k.split('\u0000'),lh=L.get(k)?.hash||null,rh=R?(R.get(k)?.hash||null):null,bh=B?(B.get(k)?.hash||null):null;
      let outcome;
      if(!R)outcome=lh?'FAST_FORWARD_REMOTE':'SAME';
      else if(lh===rh)outcome='SAME';
      else if(lh===bh)outcome='FAST_FORWARD_LOCAL';
      else if(rh===bh)outcome='FAST_FORWARD_REMOTE';
      else outcome='DIVERGED_FORK_REQUIRED';
      out.push({key:k,domain,id,outcome,local:lh,remote:rh,base:bh});
    }
    return out;
  }
  function p7PolicyV402B(domain,id){
    if(domain==='novel'||domain==='world')return 'fork';
    if(domain==='library'||domain==='lifecycle')return 'union';
    if(domain==='settings.field'&&(id===P7_CONFLICT_FIELD_V402B||id===P7_ORDER_FIELD_V402B))return 'union';
    if(domain==='settings.field'||domain==='extension.setting')return 'field';
    return 'item-fork';
  }
  const p7ScalarV402B=v=>v===null||typeof v==='number'||typeof v==='boolean'||(typeof v==='string'&&v.length<120&&!v.includes('\n'));
  function p7ClockV402B(meta,domain,id){const c=meta&&meta[`${domain}:${id}`];return{t:Number(c?.t)||0,w:String(c?.w||'')}}
  function p7LocalClockV402B(domain,id,writer){
    const f=config.settingsSyncMetaV389?.fields?.[id];return{t:Number(f?.updatedAt)||0,w:writer};
  }
  function p7ResolveV402B(o,lb,rb,ctx){
    const A=p7ApiV402B(),policy=p7PolicyV402B(o.domain,o.id);
    if(policy==='union')return{kind:'union',keep:[{domain:o.domain,id:o.id,body:p7UnionV402B(rb,lb)}]};
    if(lb===undefined)return{kind:'restore-remote-edit',keep:[{domain:o.domain,id:o.id,body:rb}]};
    if(rb===undefined)return{kind:'restore-local-edit',keep:[{domain:o.domain,id:o.id,body:lb}]};
    if(policy==='fork'){
      const fid='fork-'+A.sha256HexSync(`${o.id}|${o.local}`).slice(0,24),fb=clone(lb);
      if(fb&&typeof fb==='object'){
        if(o.domain==='novel'){fb.title=`${String(lb.title||'제목 없음')} (기기 분기본)`;fb.id=`chat-${fid}`}
        else{fb.name=`${String(lb.name||'세계관')} (기기 분기본)`;fb.id=fid}
        fb.forkOfV7=o.id;
      }
      return{kind:'fork',keep:[{domain:o.domain,id:o.id,body:rb},{domain:o.domain,id:fid,body:fb}],forkId:fid};
    }
    if(policy==='item-fork'){
      const localFirst=o.local<o.remote,keep=localFirst?lb:rb,other=clone(localFirst?rb:lb),otherHash=localFirst?o.remote:o.local,nid=`${o.id}__conflict_${otherHash.slice(0,12)}`;
      if(other&&typeof other==='object'&&!Array.isArray(other))other.id=nid;
      return{kind:'item-fork',keep:[{domain:o.domain,id:o.id,body:keep},{domain:o.domain,id:nid,body:other}],forkId:nid};
    }
    // field: ordinary scalar -> field-clock LWW (writer tie-break); long/authored/complex -> LWW + durable conflict record
    const lc=p7LocalClockV402B(o.domain,o.id,ctx.writer),rc=p7ClockV402B(ctx.remoteClocks,o.domain,o.id);
    const localWins=lc.t>rc.t||(lc.t===rc.t&&lc.w>rc.w);
    const win=localWins?{v:lb,h:o.local,w:lc.w,t:lc.t}:{v:rb,h:o.remote,w:rc.w,t:rc.t},lose=localWins?{v:rb,h:o.remote,w:rc.w,t:rc.t}:{v:lb,h:o.local,w:lc.w,t:lc.t};
    const res={kind:'field-lww',winner:localWins?'local':'remote',keep:[{domain:o.domain,id:o.id,body:win.v}]};
    if(!(p7ScalarV402B(lb)&&p7ScalarV402B(rb))){
      const conflictId=A.sha256HexSync(`p7cf|${o.domain}|${o.id}|${[win.h,lose.h].sort().join('|')}`).slice(0,24);
      res.kind='field-conflict-record';
      res.record={conflictId,domain:o.domain,field:o.id,winner:{hash:win.h,value:clone(win.v),writer:win.w,updatedAt:win.t},loser:{hash:lose.h,value:clone(lose.v),writer:lose.w,updatedAt:lose.t}};
    }
    return res;
  }
  function p7NormalizeOrderV402B(next){
    const f=next.settings.fields,order=f[P7_ORDER_FIELD_V402B]&&typeof f[P7_ORDER_FIELD_V402B]==='object'?clone(f[P7_ORDER_FIELD_V402B]):null;
    if(!order)return;
    for(const [col,items] of Object.entries(next.settings.collections)){const cur=Array.isArray(order[col])?order[col]:[];const ids=Object.keys(items);order[col]=[...cur.filter((id,i)=>ids.includes(id)&&cur.indexOf(id)===i),...ids.filter(id=>!cur.includes(id)).sort()]}
    f[P7_ORDER_FIELD_V402B]=order;
  }
  function p7MergeConflictRecordsV402B(next,records){
    if(!records.length)return;
    const cur=Array.isArray(next.settings.fields[P7_CONFLICT_FIELD_V402B])?next.settings.fields[P7_CONFLICT_FIELD_V402B]:[];
    const map=new Map(cur.map(r=>[r.conflictId,r]));for(const r of records)if(!map.has(r.conflictId))map.set(r.conflictId,r);
    next.settings.fields[P7_CONFLICT_FIELD_V402B]=[...map.values()].sort((a,b)=>a.conflictId<b.conflictId?-1:1);
  }

  // ---- manifest build (entries-level, P7-A fingerprints) ----------------------------------------------
  function p7BuildManifestV402B(next,overrides,meta){
    const A=p7ApiV402B();
    const objects=A.buildObjectFingerprints(next).map(e=>{const o=overrides.get(p7KeyV402B(e.domain,e.id));return o&&o.localHash===e.hash?{domain:e.domain,id:e.id,hash:o.remoteHash,size:o.remoteSize}:{domain:e.domain,id:e.id,hash:e.hash,size:e.size}});
    const have=new Set(objects.map(e=>p7KeyV402B(e.domain,e.id)));
    for(const [k,o] of overrides)if(o.localHash===null&&!have.has(k)){const [domain,id]=k.split('\u0000');objects.push({domain,id,hash:o.remoteHash,size:o.remoteSize})}
    objects.sort((a,b)=>a.domain<b.domain?-1:a.domain>b.domain?1:a.id<b.id?-1:a.id>b.id?1:0);
    const m={format:'lumos-sync-manifest',schemaVersion:1,canonicalSchema:'lumos.canonical.v1',createdAt:new Date(now()).toISOString(),revision:meta.revision,parentRevision:meta.parentRevision,parentNameV402B:meta.parentName||null,writer:meta.writer,
      canonicalRootHash:A.buildRootFingerprint(objects),domains:A.buildDomainFingerprints(objects),objects,clocksV402B:meta.clocks,generatorV402B:'lumos-v136-p7b-v402b'};
    const v=A.validateManifestPreview(m);if(!v.valid)throw new Error('P7 manifest self-validation failed: '+v.issues.join(','));
    return m;
  }

  // ---- canonical -> live DB/SETTINGS (staged on clones, verified, then swapped) --------------------------
  function p7ChatNovelIdV402B(chat){return String(chat?.novelId||chat?.novelSyncV136?.novelId||`legacy-chat:${chat?.id}`)}
  function p7OverlayV402B(localObj,localCanon,remoteBody){
    // keep every local key P7-A excluded (runtime/sync/secret/device-local), overlay canonical durable keys
    const out={},lc=localCanon&&typeof localCanon==='object'?localCanon:{};
    if(localObj&&typeof localObj==='object')for(const [k,v] of Object.entries(localObj))if(!(k in lc)||(typeof v==='string'&&v.startsWith('data:')))out[k]=v;
    for(const [k,v] of Object.entries(remoteBody||{})){
      if(p7IsAssetV402B(v))continue;                       // bytes never travel in live sync (D13); local data URL stays
      if(k==='history'&&Array.isArray(v)&&Array.isArray(localObj?.history)&&Array.isArray(lc.history)){
        const A=p7ApiV402B();out.history=v.map((m,i)=>lc.history[i]!==undefined&&A.canonicalJSON(lc.history[i])===A.canonicalJSON(m)&&localObj.history[i]?localObj.history[i]:clone(m));continue;
      }
      out[k]=clone(v);
    }
    return out;
  }
  function p7ApplyToCloneV402B(db,settings,localCanon,next,changed){
    const A=p7ApiV402B();
    if(!Array.isArray(db.chats))db.chats=[];if(!Array.isArray(db.worlds))db.worlds=[];
    const touchedCollections=new Set();
    for(const o of changed){
      const body=p7GetObjV402B(next,o.domain,o.id),lcb=p7GetObjV402B(localCanon,o.domain,o.id);
      if(o.domain==='novel'){
        const idx=db.chats.findIndex(c=>p7ChatNovelIdV402B(c)===o.id);
        if(body===undefined){if(idx>=0)db.chats.splice(idx,1);continue}
        const merged=p7OverlayV402B(idx>=0?db.chats[idx]:null,lcb,body);merged.novelId=o.id;if(idx<0&&!merged.updatedAt)merged.updatedAt=now();
        if(idx>=0)db.chats[idx]=merged;else db.chats.push(merged);continue;
      }
      if(o.domain==='world'){
        const idx=db.worlds.findIndex(w=>String(w?.id)===o.id);
        if(body===undefined){if(idx>=0)db.worlds.splice(idx,1);continue}
        const merged=p7OverlayV402B(idx>=0?db.worlds[idx]:null,lcb,body);if(idx>=0)db.worlds[idx]=merged;else db.worlds.push(merged);continue;
      }
      if(o.domain==='library'){const b=body||{};db.chatGroups=clone(b.chatGroups||[]);db.chatSidebarOrder=clone(b.chatSidebarOrder||[]);for(const [k,v] of Object.entries(b.unclassifiedDbRootsV401A||{}))db[k]=clone(v);continue}
      if(o.domain==='lifecycle'){for(const [k,v] of Object.entries(body||{}))db[k]=clone(v);continue}
      if(o.domain==='settings.field'){
        if(o.id===P7_ORDER_FIELD_V402B){for(const col of Object.keys(body||{}))touchedCollections.add(col);continue}
        if(body===undefined){if(!(typeof settings[o.id]==='string'&&settings[o.id].startsWith('data:')))delete settings[o.id];continue}
        if(p7IsAssetV402B(body))continue;
        settings[o.id]=clone(body);continue;
      }
      if(o.domain==='extension.setting'){if(body===undefined)delete settings[o.id];else settings[o.id]=clone(body);continue}
      if(o.domain.startsWith('settings.')){touchedCollections.add(o.domain.slice(9));continue}
      // extension.risuPlugin is not part of the v7 input (plugins stay with their own owner)
    }
    for(const col of touchedCollections){
      const localArr=Array.isArray(settings[col])?settings[col]:[],items=next.settings.collections[col]||{},localCanonItems=localCanon.settings.collections[col]||{};
      const order=(next.settings.fields[P7_ORDER_FIELD_V402B]||{})[col]||[],ids=[...order.filter(id=>id in items),...Object.keys(items).filter(id=>!order.includes(id)).sort()];
      const byId=new Map();for(const it of localArr)if(it&&typeof it==='object')byId.set(String(it.id??it.name??''),it);
      const out=ids.map(id=>p7OverlayV402B(byId.get(id)||null,localCanonItems[id],items[id]));
      localArr.forEach((it,i)=>{if(col==='customModels'&&it&&(it.risuPluginIdV190||it.providerBridgeV190||it.providerBridgeV189))out.splice(Math.min(i,out.length),0,it)});
      settings[col]=out;
    }
  }
  function p7VerifyCloneV402B(db,settings,nextEntries){
    const A=p7ApiV402B(),ex=A.extractCanonical({DB:db,SETTINGS:settings}),got=new Map(A.buildObjectFingerprints(ex.canonical).map(e=>[p7KeyV402B(e.domain,e.id),e])),pending={},bad=[];
    for(const [k,e] of nextEntries){
      const g=got.get(k);if(g&&g.hash===e.hash)continue;
      const [domain,id]=k.split('\u0000');const raw=p7GetObjV402B(e.__canon,domain,id),want=p7StripAssetsV402B(raw),have=g?p7StripAssetsV402B(p7GetObjV402B(ex.canonical,domain,id)):undefined;
      if(g&&A.canonicalJSON(want)===A.canonicalJSON(have)){pending[k]={remoteHash:e.hash,remoteSize:e.size,localHash:g.hash};continue}
      if(!g&&(p7IsAssetV402B(raw)||e.__pendingNull)){pending[k]={remoteHash:e.hash,remoteSize:e.size,localHash:null};continue}
      bad.push(`${domain}:${id}`);
    }
    for(const k of got.keys())if(!nextEntries.has(k))bad.push(k.replace('\u0000',':'));
    return{ok:bad.length===0,bad,pending};
  }
  function p7PrepareLocalV402B(next,nextEntries){
    const cur=p7LocalV402B(),changed=[];
    for(const [k,e] of nextEntries){const le=cur.entries.get(k);if(!le||le.hash!==e.hash){const [domain,id]=k.split('\u0000');changed.push({domain,id})}}
    for(const k of cur.entries.keys())if(!nextEntries.has(k)){const [domain,id]=k.split('\u0000');changed.push({domain,id})}
    const db=clone(DB),settings=clone(SETTINGS);
    p7ApplyToCloneV402B(db,settings,cur.canonical,next,changed);
    for(const e of nextEntries.values())Object.defineProperty(e,'__canon',{value:next,enumerable:false,configurable:true});
    const v=p7VerifyCloneV402B(db,settings,nextEntries);
    if(!v.ok){const err=new Error('P7 로컬 적용 사전 검증 실패: '+[...new Set(v.bad)].slice(0,12).join(','));err.p7LocalVerify=true;throw err}
    return{db,settings,pending:v.pending,changedCount:changed.length,liveRoot:p7ApiV402B().buildRootFingerprint([...cur.entries.values()])};
  }
  async function p7CommitLocalV402B(prep){
    if(p7ApiV402B().buildRootFingerprint([...p7LocalV402B().entries.values()])!==prep.liveRoot)throw new Error('P7 로컬 상태가 동기화 중 변경되어 적용을 중단했습니다.');
    const {db,settings}=prep;
    const swap=(live,fresh)=>{for(const k of Object.keys(live))if(!(k in fresh))delete live[k];Object.assign(live,fresh)};
    swap(DB,db);swap(SETTINGS,settings);
    const saveFn=window.saveData||((typeof saveData==='function')?saveData:null);
    if(typeof saveFn==='function')await saveFn();
    try{refreshAfterNovelDownload()}catch(_){}try{applySettingsUiV122?.()}catch(_){}
    return prep.pending;
  }

  // ---- legacy v6 (read-only) for migration / join base ---------------------------------------------------
  async function p7ReadLegacyV402B(root,interactive){
    const out={settingsFile:null,novelFile:null,settingsPayload:null,novelPayload:null};
    if(!root)return out;
    out.settingsFile=await findSettingsFile(root.id,interactive);out.novelFile=await findNovelFile(root.id,interactive);
    if(out.settingsFile)out.settingsPayload=await readCloudFile(out.settingsFile.id,interactive);
    if(out.novelFile)out.novelPayload=await readNovelFile(out.novelFile.id,interactive);
    return out;
  }
  async function p7LegacyMergedStateV402B(legacy){
    // existing validated v6 merge semantics on clones; restores the in-memory v389 meta afterwards (no local writes)
    const savedMeta=clone(config.settingsSyncMetaV389);
    try{
      let db=clone(DB),settings=clone(SETTINGS);
      if(legacy.novelPayload){
        const p=legacy.novelPayload,merge=mergeNovelData(await localNovelsWithSyncConflictsV390S2A(),p.novels,localTombstones(),p.tombstones||[],localEntityTombstones(),p.entityTombstones||[],localLifecycleV265(),p.lifecycle||[]);
        db=clone(merge.novels);for(const k of ['chatCount','worldCount','localSlot'])if(k in DB&&!(k in db))db[k]=DB[k];
      }
      if(legacy.settingsPayload){
        const merged=mergeSettingsPayloadsV389(buildLocalSettingsPayloadV389(),legacy.settingsPayload);
        const s=clone(merged.settings||{});for(const k of SETTINGS_EXTERNAL_AUTHORITY_ROOTS_V389)if(k in SETTINGS)s[k]=clone(SETTINGS[k]);
        for(const [k,v] of Object.entries(SETTINGS))if(!(k in s)&&(isSecretKey(k)||localOnlyRoot.has(k)||isRuntimeRoot(k)))s[k]=clone(v);
        settings=restoreLegacySecrets(clone(SETTINGS),s);
        if(Array.isArray(SETTINGS.customModels)){const ext=SETTINGS.customModels.filter(extensionOwnedCustomModelV389);if(ext.length)settings.customModels=[...(settings.customModels||[]).filter(m=>!extensionOwnedCustomModelV389(m)),...clone(ext)]}
      }
      return{db,settings};
    }finally{config.settingsSyncMetaV389=savedMeta}
  }
  function p7LegacyCanonicalV402B(legacy){
    if(!legacy.novelPayload&&!legacy.settingsPayload)return null;
    const A=p7ApiV402B(),ex=A.extractCanonical({DB:legacy.novelPayload?.novels||{},SETTINGS:legacy.settingsPayload?.settings||{}});
    return new Map(A.buildObjectFingerprints(ex.canonical).map(e=>[p7KeyV402B(e.domain,e.id),e]));
  }

  // ---- secrets channel (never canonical) ---------------------------------------------------------------
  function p7CollectSecretsV402B(settings){
    const out={};
    const walk=(v,segs,key,depth)=>{
      if(depth>30||v==null)return;
      if(segs.some(s=>P7_SECRET_EXCLUDE_RE_V402B.test(typeof s==='string'?s:String(s?.id||''))))return;
      if((typeof v==='string'||typeof v==='number')&&isSecretKey(key)&&String(v).trim()){out[JSON.stringify(segs)]={segs,value:String(v)};return}
      if(Array.isArray(v)){v.forEach((x,i)=>{const id=x&&typeof x==='object'&&(x.id!=null||x.name!=null)?{id:String(x.id??x.name)}:i;walk(x,[...segs,id],'',depth+1)});return}
      if(typeof v==='object')for(const [k,x] of Object.entries(v))walk(x,[...segs,k],k,depth+1);
    };
    for(const [k,v] of Object.entries(settings||{})){if(localOnlyRoot.has(k)||isRuntimeRoot(k)||k.startsWith('__lumos'))continue;walk(v,[k],k,0)}
    return out;
  }
  function p7SetSecretV402B(settings,segs,value){
    let cur=settings;
    for(let i=0;i<segs.length-1;i++){
      const s=segs[i];
      if(s&&typeof s==='object'){if(!Array.isArray(cur))return false;cur=cur.find(x=>x&&String(x.id??x.name)===s.id);if(!cur)return false;continue}
      if(cur[s]==null||typeof cur[s]!=='object')return false;cur=cur[s];
    }
    const last=segs[segs.length-1];if(typeof last==='object'||cur==null)return false;cur[last]=value;return true;
  }
  function p7SecretSaltV402B(){const c=p7CfgV402B();if(!c.secretSalt||typeof c.secretSalt!=='string'){const a=new Uint8Array(16);crypto.getRandomValues(a);c.secretSalt=[...a].map(x=>x.toString(16).padStart(2,'0')).join('')}return c.secretSalt}
  function p7SecretHashV402B(value){return p7ApiV402B().sha256HexSync(p7SecretSaltV402B()+'\u0000'+String(value)).slice(0,16)}
  function p7NormSecretEventV402B(e){
    // R1 {segs,value,t,w} | R2 live {segs,value,deleted:false,t,w} | R2 tombstone {segs,deleted:true,t,w}
    if(!e||!Array.isArray(e.segs))return null;
    const t=Number(e.t)||0,w=String(e.w||'');
    if(e.deleted===true)return{segs:e.segs,deleted:true,t,w};
    if(e.value==null||!String(e.value).trim())return null;
    return{segs:e.segs,value:String(e.value),deleted:false,t,w};
  }
  const p7SecretWinsV402B=(a,b)=>!b||a.t>b.t||(a.t===b.t&&a.w>b.w);
  async function p7SecretSyncV402B(run,remote,interactive,create){
    const policy=p7SecretPolicyV402B(),c=p7CfgV402B(),A=p7ApiV402B(),writer=p7WriterV402B();
    const result={enabled:!!policy.enabled,disclosed:!!policy.disclosed,status:'off',paths:0,live:0,deleted:0,applied:0,cleared:0,tombstonesCreated:0,written:false};
    if(!policy.enabled)return result;
    if(!policy.disclosed){result.status='disclosure-required';return result}
    // local state -> clocked events (clock metadata holds path + salted hash only, never a value)
    const local=p7CollectSecretsV402B(SETTINGS),t=now(),clocks=c.secretClocks;
    for(const [k,e] of Object.entries(local)){const h=p7SecretHashV402B(e.value),prev=clocks[k];if(!prev||prev.d===true||prev.h!==h)clocks[k]={s:e.segs,h,t,w:writer,d:false}}
    for(const [k,prev] of Object.entries(clocks)){
      if(local[k]||!prev||prev.d===true)continue;
      if(!Array.isArray(prev.s)){delete clocks[k];continue}          // legacy clock without path: unknown, never a deletion
      clocks[k]={s:prev.s,h:null,t,w:writer,d:true};result.tombstonesCreated++;   // known-live path cleared here -> tombstone
    }
    const merged={};
    for(const [k,ck] of Object.entries(clocks)){
      if(ck.d===true)merged[k]={segs:ck.s,deleted:true,t:ck.t,w:ck.w};
      else if(local[k])merged[k]={segs:local[k].segs,value:local[k].value,deleted:false,t:ck.t,w:ck.w};
    }
    const files=(await p7ListChildrenV402B(run,remote.folders.secrets,interactive)).map(f=>{const m=/^s-([a-z0-9]+)-(\d{10})\.json$/.exec(f.name);return m?{...f,writer:m[1],seq:Number(m[2])}:null}).filter(Boolean);
    const latest=new Map();for(const f of files){const p=latest.get(f.writer);if(!p||f.seq>p.seq)latest.set(f.writer,f)}
    let ownLatest=null;
    for(const f of [...latest.values()].sort((a,b)=>a.writer<b.writer?-1:1)){
      let snap=null;try{snap=JSON.parse(await p7ReadTextV402B(f.id,interactive))}catch(_){}run.metrics.secretReads++;
      if(!snap||snap.format!=='lumos-p7-secret-snapshot')continue;if(f.writer===writer)ownLatest=snap;
      for(const [k,raw] of Object.entries(snap.entries||{})){const e=p7NormSecretEventV402B(raw);if(e&&p7SecretWinsV402B(e,merged[k]))merged[k]=e}
    }
    // apply winners: live -> value, tombstone -> clear (a newer tombstone prevents any older live snapshot from resurrecting it)
    for(const [k,e] of Object.entries(merged)){
      if(e.deleted){
        if(local[k]&&p7SetSecretV402B(SETTINGS,e.segs,''))result.cleared++;
        clocks[k]={s:e.segs,h:null,t:e.t,w:e.w,d:true};
      }else{
        if(local[k]?.value!==e.value&&p7SetSecretV402B(SETTINGS,e.segs,e.value))result.applied++;
        clocks[k]={s:e.segs,h:p7SecretHashV402B(e.value),t:e.t,w:e.w,d:false};
      }
    }
    if(result.applied||result.cleared){const saveFn=window.saveData||((typeof saveData==='function')?saveData:null);if(typeof saveFn==='function')await saveFn()}
    const entries=Object.fromEntries(Object.entries(merged).sort().map(([k,e])=>[k,e.deleted?{segs:e.segs,deleted:true,t:e.t,w:e.w}:{segs:e.segs,value:e.value,deleted:false,t:e.t,w:e.w}]));
    const ownNorm=ownLatest?Object.fromEntries(Object.entries(ownLatest.entries||{}).map(([k,e])=>[k,p7NormSecretEventV402B(e)]).filter(([,e])=>e).sort().map(([k,e])=>[k,e.deleted?{segs:e.segs,deleted:true,t:e.t,w:e.w}:{segs:e.segs,value:e.value,deleted:false,t:e.t,w:e.w}])):null;
    const same=ownNorm&&A.canonicalJSON(ownNorm)===A.canonicalJSON(entries);
    if(!same&&Object.keys(entries).length&&create&&remote.folders.secrets[0]){
      c.secretSeq=Number(c.secretSeq||0)+1;
      const text=JSON.stringify({format:'lumos-p7-secret-snapshot',schemaVersion:2,writer,createdAt:new Date(now()).toISOString(),entries});
      await p7CreateTextV402B(remote.folders.secrets[0].id,`s-${writer}-${String(c.secretSeq).padStart(10,'0')}.json`,text,{lumos:'p7-v402b-secrets'},interactive);run.metrics.secretWrites++;result.written=true;
    }
    const vals=Object.values(entries);result.paths=vals.length;result.deleted=vals.filter(e=>e.deleted).length;result.live=result.paths-result.deleted;result.status='synced';saveConfig();return result;
  }

  // ---- dry-run plan (read-only) -----------------------------------------------------------------------
  async function p7PreviewSyncV402B(options={}){
    const interactive=options.interactive!==false,run=p7NewRunV402B('preview'),A=p7ApiV402B(),c=p7CfgV402B();
    p7PhaseV402B(run,'inspecting','P7 v7 · 읽기 전용 점검');
    const remote=await p7RemoteV402B(run,interactive,false),{head,invalid}=await p7ResolveHeadV402B(run,remote,interactive);
    const local=p7LocalV402B(),legacy=c.migrated?{}:await p7ReadLegacyV402B(remote.root,interactive);
    const mode=c.base?'sync':(head?'join':'migrate');
    let target,decision=[],unclassified=[...local.report.unclassified];
    if(mode==='migrate'){
      const merged=await p7LegacyMergedStateV402B(legacy),ex=A.extractCanonical({DB:merged.db,SETTINGS:merged.settings});target=ex.canonical;unclassified=[...new Set([...unclassified,...ex.report.unclassified])].sort();
      decision=p7DecideV402B(new Map(A.buildObjectFingerprints(target).map(e=>[p7KeyV402B(e.domain,e.id),e])),null,null);
    }else{
      const R=p7EntriesV402B(head?.manifest),B=mode==='join'?p7LegacyCanonicalV402B(legacy):null;
      decision=p7DecideV402B(local.entries,R,B);
    }
    const counts={};for(const o of decision)counts[o.outcome]=(counts[o.outcome]||0)+1;
    const uploadEntries=mode==='migrate'?A.buildObjectFingerprints(target).filter(e=>!remote.objects.has(p7ObjectNameV402B(e))):[];
    const policy=p7SecretPolicyV402B();
    const plan={mode,localRoot:A.buildRootFingerprint([...local.entries.values()]),proposedRoot:mode==='migrate'?A.buildRootFingerprint(target):null,
      remoteHead:head?{name:head.name,revision:head.rev,root:head.manifest.canonicalRootHash}:null,invalidManifests:invalid.length,
      counts,uploadCount:uploadEntries.length,uploadBytes:uploadEntries.reduce((a,e)=>a+e.size,0),forkCount:counts.DIVERGED_FORK_REQUIRED||0,
      legacyFiles:{settings:!!legacy.settingsFile,novels:!!legacy.novelFile},unclassified,unclassifiedCount:unclassified.length,
      secret:{count:Object.keys(p7CollectSecretsV402B(SETTINGS)).length,enabled:!!policy.enabled,disclosed:!!policy.disclosed,source:policy.source,disclosureRequired:!!policy.enabled&&!policy.disclosed},
      requires:{acceptance:!c.base,acceptUnclassified:unclassified.length>0,secretDisclosure:!!policy.enabled&&!policy.disclosed},transport:p7TransportV402D(),metrics:run.metrics};
    plan.planId=A.sha256HexSync(A.canonicalJSON({mode,l:plan.localRoot,p:plan.proposedRoot,h:plan.remoteHead,u:unclassified})).slice(0,24);
    p7PlanV402B=plan;p7PhaseV402B(run,'success','P7 v7 · 점검 완료 (쓰기 0)');
    return clone(plan);
  }

  // ---- main v7 sync ----------------------------------------------------------------------------------
  async function p7SyncV402B(options={}){
    const interactive=options.interactive!==false,A=p7ApiV402B(),c=p7CfgV402B(),writer=p7WriterV402B(),run=p7NewRunV402B('sync');
    const report={ok:false,result:'',attempts:0,trail:run.trail,metrics:run.metrics,planned:run.planned,decision:null,uploads:[],downloads:[],forks:[],conflicts:[],secret:null,revision:null,siblingsLost:0,transport:p7TransportV402D()};
    const finish=(ok,result,extra={})=>{Object.assign(report,{ok,result},extra);report.cacheHits=run.cacheHits;report.cacheRejects=run.cacheRejects;p7LastReportV402B=clone(report);return report};
    try{assertSyncStartAllowedV269()}catch(e){return finish(false,'BLOCKED',{error:e.message})}
    if(!report.transport.ready){p7PhaseV402B(run,'failed','P7 v7 · 쓰기 전송(Relay) 없음 · 시작 안 함');return finish(false,'TRANSPORT_UNAVAILABLE',{error:'P7_RELAY_UNAVAILABLE: file:// 페이지의 P7 쓰기는 Universal Relay가 필요합니다. 동기화를 시작하지 않았습니다.'})}
    if(!c.base){
      const plan=p7PlanV402B;
      if(!plan||!options.acceptPlanId||options.acceptPlanId!==plan.planId)return finish(false,'ACCEPTANCE_REQUIRED',{plan:plan?clone(plan):null,error:'첫 v7 동기화는 읽기 전용 점검(p7PreviewSyncV402B) 후 명시적 승인이 필요합니다.'});
      if(plan.requires.acceptUnclassified&&options.acceptUnclassified!==true)return finish(false,'ACCEPTANCE_REQUIRED',{plan:clone(plan),error:'미분류 경로 승인이 필요합니다.'});
      const policy=p7SecretPolicyV402B();
      if(policy.enabled&&!policy.disclosed){
        if(options.disableSecretSync===true){policy.enabled=false}
        else if(options.acknowledgeSecretDisclosure===true){policy.disclosed=true}
        else return finish(false,'ACCEPTANCE_REQUIRED',{plan:clone(plan),error:'API 키/토큰 동기화 고지 확인이 필요합니다.'});
      }
    }
    if(report.transport.write==='relay')p7PrimeRelayV402D();
    state.busy=true;notifyMutationLockV269();
    try{
      await flushLocalNovelBeforeSyncV243('p7-v402b');
      for(let attempt=1;attempt<=P7_MAX_ATTEMPTS_V402B;attempt++){
        report.attempts=attempt;if(!run.settledV402B){report.uploads=[];report.downloads=[];report.forks=[];report.conflicts=[]}
        p7PhaseV402B(run,'inspecting','P7 v7 · 원격 manifest 확인');
        const remote=await p7RemoteV402B(run,interactive,true),{head,invalid}=await p7ResolveHeadV402B(run,remote,interactive);
        if(c.base&&head&&head.rev<Number(c.base.revision)){p7PhaseV402B(run,'failed','P7 v7 · 원격 head가 기준보다 오래됨');return finish(false,'INVALID_REMOTE',{error:'remote head older than local base'})}
        if(c.base&&!head&&(invalid.length||remote.manifests.length)){p7PhaseV402B(run,'failed','P7 v7 · 유효한 원격 manifest 없음');return finish(false,'INVALID_REMOTE',{invalid})}
        const local=p7LocalV402B();let localCanon=local.canonical,L=local.entries;
        let B=null,mode='sync';
        if(c.base){const be=await p7BaseEntriesV402B(run,remote,head,c.base.name,interactive);B=be.entries;report.baseKind=be.kind}
        else if(head){mode='join';const legacy=await p7ReadLegacyV402B(remote.root,interactive);B=p7LegacyCanonicalV402B(legacy)}
        else{
          mode='migrate';const legacy=await p7ReadLegacyV402B(remote.root,interactive),merged=await p7LegacyMergedStateV402B(legacy);
          localCanon=A.extractCanonical({DB:merged.db,SETTINGS:merged.settings}).canonical;L=new Map(A.buildObjectFingerprints(localCanon).map(e=>[p7KeyV402B(e.domain,e.id),e]));
        }
        const R=head?p7EntriesV402B(head.manifest):null,decision=p7DecideV402B(L,R,B);
        const counts={};for(const o of decision)counts[o.outcome]=(counts[o.outcome]||0)+1;report.decision={mode,counts,head:head?.name||null,invalidManifests:invalid.length};
        const changedVsRemote=decision.some(o=>o.outcome!=='SAME');
        if(!changedVsRemote&&head){
          p7PhaseV402B(run,'same','P7 v7 · 변경 없음');
          c.base={name:head.name,revision:head.rev,root:head.manifest.canonicalRootHash};c.enabled=true;c.migrated=true;config.lastSyncAt=now();saveConfig();
          report.secret=await p7SecretSyncV402B(run,remote,interactive,true);
          p7PhaseV402B(run,'success','P7 v7 · 최신 상태');return finish(true,report.firstResult||'SAME',{revision:head.rev});
        }
        // ---- stage (memory only) ----
        const next=clone(localCanon),records=[],overrides=new Map(),remoteClocks=head?.manifest?.clocksV402B||{};
        for(const [k,e] of L)if(e.pendingAsset){const p=c.pendingAssets[k];if(p&&(R?.get(k)?.hash===p.remoteHash||!R))overrides.set(k,p)}
        if(decision.some(o=>o.outcome==='DIVERGED_FORK_REQUIRED'))p7PhaseV402B(run,'fork-required','P7 v7 · 양쪽 변경 보존');
        const needRemote=decision.filter(o=>o.outcome==='FAST_FORWARD_LOCAL'||o.outcome==='DIVERGED_FORK_REQUIRED');
        if(needRemote.length)p7PhaseV402B(run,'downloading',`P7 v7 · 변경 객체 ${needRemote.length}개 확인`);
        try{
          for(const o of needRemote){
            const re=R.get(o.key),rb=re?await p7FetchBodyV402B(run,remote,re,interactive):undefined;
            if(re)report.downloads.push({domain:o.domain,id:o.id,bytes:re.size});
            if(o.outcome==='FAST_FORWARD_LOCAL'){p7SetObjV402B(next,o.domain,o.id,rb);continue}
            const lb=p7GetObjV402B(localCanon,o.domain,o.id),res=p7ResolveV402B(o,lb,rb,{writer,remoteClocks});
            for(const kp of res.keep)p7SetObjV402B(next,kp.domain,kp.id,kp.body);
            if(res.record){records.push(res.record);report.conflicts.push({domain:o.domain,field:o.id,conflictId:res.record.conflictId,winner:res.kind==='field-conflict-record'?res.winner:res.winner})}
            report.forks.push({domain:o.domain,id:o.id,kind:res.kind,forkId:res.forkId||null,winner:res.winner||null});
          }
        }catch(e){if(e.p7InvalidRemote){p7PhaseV402B(run,'failed','P7 v7 · 원격 무결성 오류');return finish(false,'INVALID_REMOTE',{error:e.message})}throw e}
        p7MergeConflictRecordsV402B(next,records);p7NormalizeOrderV402B(next);
        // ---- prospective manifest ----
        const clocks={};
        for(const e of A.buildObjectFingerprints(next)){if(e.domain!=='settings.field'&&e.domain!=='extension.setting')continue;const k=`${e.domain}:${e.id}`,re=R?.get(p7KeyV402B(e.domain,e.id));
          clocks[k]=re&&re.hash===e.hash&&remoteClocks[k]?remoteClocks[k]:{t:p7LocalClockV402B(e.domain,e.id,writer).t,w:writer}}
        const rev=(head?.rev||0)+1,nonce=p7NonceV402B(),mname=p7ManifestNameV402B(rev,writer,nonce);
        const manifest=p7BuildManifestV402B(next,overrides,{revision:rev,parentRevision:head?.rev||0,parentName:head?.name||null,writer,clocks});
        const nextEntries=p7EntriesV402B(manifest);
        for(const [k,o] of overrides)if(o.localHash===null&&nextEntries.has(k))Object.defineProperty(nextEntries.get(k),'__pendingNull',{value:true,enumerable:false});
        const needCommit=!head||manifest.canonicalRootHash!==head.manifest.canonicalRootHash;
        let committed=head;
        let prep;try{prep=p7PrepareLocalV402B(next,nextEntries)}catch(e){if(e.p7LocalVerify){p7PhaseV402B(run,'failed','P7 v7 · 로컬 적용 사전 검증 실패 (원격 쓰기 0)');return finish(false,'FAILED',{error:e.message})}throw e}
        if(needCommit){
          p7PhaseV402B(run,'uploading','P7 v7 · 변경 객체 업로드');
          const remoteHas=new Set((head?.manifest?.objects||[]).map(e=>p7KeyV402B(e.domain,e.id)+'\u0000'+e.hash));
          for(const e of manifest.objects){
            if(remoteHas.has(p7KeyV402B(e.domain,e.id)+'\u0000'+e.hash))continue;
            const name=p7ObjectNameV402B(e);if(remote.objects.has(name))continue;
            const text=A.canonicalJSON(p7GetObjV402B(next,e.domain,e.id)),bytes=p7Utf8V402B(text);
            if(bytes.length!==e.size||A.sha256HexSync(bytes)!==e.hash)throw new Error('P7 upload body self-check failed');
            const f=await p7CreateTextV402B(remote.folders.objects[0].id,name,text,{lumos:'p7-v402b-object'},interactive);
            remote.objects.set(name,{id:f.id,name});run.metrics.bodyUploads++;run.metrics.bodyUploadBytes+=bytes.length;run.planned.uploadCount++;run.planned.uploadBytes+=e.size;report.uploads.push({domain:e.domain,id:e.id,bytes:e.size});
          }
          // ---- compare-at-commit fence (metadata listing; any new manifest at/above the inspected head = stale) ----
          const seen=new Set(remote.manifests.map(f=>f.name)),hr=head?head.rev:0;
          const fence=(await p7ListingsV402B(run,remote.folders,interactive)).manifests;
          const moved=fence.some(f=>!seen.has(f.name)&&f.rev>=hr);
          if(moved){p7PhaseV402B(run,'retryable','P7 v7 · 원격이 변경됨 · 재평가');continue}
          const mtext=JSON.stringify(manifest);
          await p7CreateTextV402B(remote.folders.manifests[0].id,mname,mtext,{lumos:'p7-v402b-manifest',revision:String(rev)},interactive);
          run.metrics.manifestWrites++;run.metrics.manifestUploadBytes+=p7Utf8V402B(mtext).length;p7ManifestCacheV402B.set(mname,JSON.parse(mtext));
          // ---- post-commit re-inspection: our manifest must be the authoritative head ----
          const after=await p7ListingsV402B(run,remote.folders,interactive),verify=await p7ResolveHeadV402B(run,{...remote,...after},interactive);
          if(verify.head?.name!==mname){report.siblingsLost++;p7PhaseV402B(run,'retryable','P7 v7 · 동시 커밋 경합 · 재평가');continue}
          committed={name:mname,rev,manifest};
        }
        // ---- apply staged local state only now ----
        p7PhaseV402B(run,'validating','P7 v7 · 로컬 적용');
        const pending=await p7CommitLocalV402B(prep);
        c.pendingAssets=Object.assign({},...Object.entries(c.pendingAssets).filter(([k])=>nextEntries.has(k)).map(([k,v])=>({[k]:v})),pending);
        c.base={name:committed.name,revision:committed.rev,root:committed.manifest.canonicalRootHash};c.enabled=true;c.migrated=true;config.lastSyncAt=now();saveConfig();
        p7PlanV402B=null;report.firstResult=report.firstResult||(mode==='migrate'?'MIGRATED':(report.forks.some(f=>f.kind==='fork'||f.kind==='item-fork')?'FORKED':null));
        // app-side normalization after the swap (e.g. sidebar order gaining the new chats) is committed in the same run
        if(!run.settledV402B&&attempt<P7_MAX_ATTEMPTS_V402B&&p7ApiV402B().buildRootFingerprint([...p7LocalV402B().entries.values()])!==committed.manifest.canonicalRootHash){run.settledV402B=true;report.settleCommit=true;p7PhaseV402B(run,'settling','P7 v7 · 앱 정규화 반영 커밋');continue}
        report.secret=await p7SecretSyncV402B(run,remote,interactive,true);
        p7PhaseV402B(run,'success',needCommit?`P7 v7 · 동기화 완료 (rev ${committed.rev})`:'P7 v7 · 원격 변경 반영 완료');
        return finish(true,report.firstResult||(mode==='migrate'?'MIGRATED':(report.forks.some(f=>f.kind==='fork'||f.kind==='item-fork')?'FORKED':'SYNCED')),{revision:committed.rev});
      }
      p7PhaseV402B(run,'failed','P7 v7 · 재시도 한도 초과');
      return finish(false,'STALE_RETRY_EXHAUSTED',{error:`retry limit ${P7_MAX_ATTEMPTS_V402B}`});
    }catch(error){
      if(run.trail[run.trail.length-1]!=='failed')p7PhaseV402B(run,'failed','P7 v7 · 실패');
      return finish(false,'FAILED',{error:String(error?.message||error)});
    }finally{state.busy=false;notifyMutationLockV269();render()}
  }
  // ---- Manual Sync v7 = P7 core + existing extension owner (D16; v245 stays the plugin/module authority) ----
  async function p7ManualSyncV402B(options={}){
    const core=await p7SyncV402B(options);
    const out={ok:false,status:'core-failed',result:core.result,core:{ok:!!core.ok,result:core.result,revision:core.revision??null,error:core.error||null},extension:{called:0,ok:null,error:null},coreReport:core};
    if(core.ok){
      const extApi=window.LumosExtensionSyncV245;let extOk=false,extErr=null;
      try{
        out.extension.called=1;setOperation('P7 v7 · 플러그인·모듈 동기화 (v245)');
        if(!extApi||typeof extApi.upload!=='function')throw new Error('확장 동기화 모듈(v245)을 찾지 못했습니다.');
        extOk=(await extApi.upload({quiet:true,integrated:true}))===true;
        if(!extOk)extErr=String(extApi?.state?.lastError||extApi?.state?.lastOperation||'확장 동기화 실패');
      }catch(e){extOk=false;extErr=String(e?.message||e)}
      out.extension.ok=extOk;out.extension.error=extOk?null:extErr;
      out.ok=extOk;out.status=extOk?'success':'extension-failed';out.result=extOk?core.result:'EXTENSION_FAILED';
      setOperation(extOk?`P7 v7 · 동기화 완료 (${core.result}) · 확장 완료`:`P7 v7 · 핵심 동기화 완료 (${core.result}) · 확장 동기화 실패: ${extErr}`,extOk?null:extErr);
    }
    try{patchManualSyncActivityV391({p7ManualV402B:{status:out.status,core:out.core.result,extension:out.extension.ok}})}catch(_){}
    p7LastManualV402B=clone({...out,coreReport:undefined});
    return out;
  }
  function p7ActiveV402B(){const c=config.p7V402B;return !!(c&&c.enabled===true&&c.base)}
  function p7StatusV402B(){const c=p7CfgV402B(),p=p7SecretPolicyV402B();return clone({enabled:c.enabled,migrated:c.migrated,base:c.base,active:p7ActiveV402B(),transport:p7TransportV402D(),secret:{enabled:!!p.enabled,disclosed:!!p.disclosed,source:p.source},pendingAssets:Object.keys(c.pendingAssets||{}).length,plan:p7PlanV402B?{planId:p7PlanV402B.planId,mode:p7PlanV402B.mode}:null,lastReport:p7LastReportV402B,lastManualSync:p7LastManualV402B})}
  function p7SetEnabledV402B(on){const c=p7CfgV402B();if(on&&!c.base)return false;c.enabled=!!on;saveConfig();return c.enabled}
  function p7SetSecretSyncV402B(enabled,options={}){const p=p7SecretPolicyV402B();p.enabled=!!enabled;if(enabled&&options.acknowledgeDisclosure===true)p.disclosed=true;saveConfig();return clone(p)}
  function p7ResetLocalBaseV402B(){const c=p7CfgV402B();c.base=null;c.enabled=false;c.migrated=false;c.pendingAssets={};p7PlanV402B=null;saveConfig();return true}
