Lumos v402 P7-B R4 — File-Origin Safe Google Drive Write Transport — Candidate submission package

STATUS: Candidate (not OFFICIAL). No real Google Drive write was performed.
NEXT:   Architect independent preflight. Do NOT run a live migration from this package.

READ IN THIS ORDER
1. P7B_R4_Report.md                 identity, scope, what changed, gates, residual risks
2. P7B_R4_Transport_Contract.md      the R4 write transport (relay on file://) + unchanged R2/R3 transport
3. P7B_R4_Migration_Contract.md      incl. failed-R3-attempt Drive compatibility (no manual cleanup)
4. P7B_R4_Secrets_Contract.md        incl. bearer-token handling
5. P7B_R4_Extension_Composition_Contract.md
6. P7B_R4_Test_Results.json          38 gates + evidence

FILES
Lumos_v402_P7B_Manual_Sync_V7_R4_Candidate.html   the Candidate
Lumos_v401_P7A_Canonical_State_Fingerprint_R5_OFFICIAL.html   exact direct parent (for diff/rebuild)
P7B_R4_correction.diff               R5 OFFICIAL -> R4 Candidate (patch --binary)
p7b_v7_block.js                      P7-B v7 block inserted into lumos-v136-drive-sync-script
build_p7b_candidate.py               deterministic builder (R5 + block -> Candidate)
run_all_p7b_r4_tests.py              H-P7B-01..38 harness
p7b_drive_sim.py                     synthetic Google Drive v3
p7b_device.py                        Playwright device + synthetic Lumos Universal Relay fixture
fixtures/                            profiles (unchanged from R3)
SHA256SUMS.txt

REPRODUCE
  python3 build_p7b_candidate.py Lumos_v401_P7A_Canonical_State_Fingerprint_R5_OFFICIAL.html p7b_v7_block.js out.html
  NO_COLOR=1 python3 run_all_p7b_r4_tests.py          (python3, playwright + Chromium, node >= 22, GNU patch; ~15 min)
