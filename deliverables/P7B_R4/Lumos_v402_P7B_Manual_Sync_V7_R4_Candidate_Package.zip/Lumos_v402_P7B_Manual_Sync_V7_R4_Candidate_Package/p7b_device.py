"""Playwright device wrapper: one browser context = one Lumos installation, all Drive traffic -> DriveSim.

R4: also serves a synthetic Lumos Universal Relay (POST https://nomal-nomal.wkd1107wkd.workers.dev/relay).
The fixture decodes the v106 envelope {url,method,headers,bodyText|bodyBase64}, forwards the upstream request
to the same DriveSim (tagged via='relay') and mirrors the upstream status (+ X-Lumos-Upstream-Status), like the
real relay. Every relayed request is recorded in holder['relay'] (upstream url/method/headers/body bytes) so
tests can decode the exact multipart/related bytes. Fault modes (holder['relay_fail'] callables) can make the
relay throw (connection abort), return an upstream 502 without forwarding, or forward and then return 502.
"""
import base64, json
from pathlib import Path

DEVICE_KEY = 'LUMOS_DRIVE_SYNC_V120_DEVICE'
CONFIG_KEY = 'LUMOS_DRIVE_SYNC_V136_CONFIG'
RELAY_ENDPOINT = 'https://nomal-nomal.wkd1107wkd.workers.dev/relay'
RELAY_EXPOSE = {'access-control-allow-origin': '*', 'access-control-expose-headers': 'X-Lumos-Upstream-Status, X-Lumos-Relay-Version',
                'X-Lumos-Relay-Version': 'sim-relay-1', 'content-type': 'application/json'}
HTTP_APP = 'http://lumos.test/'
HELPERS = r"""
window.__P7T={
  seed(p){for(const k of Object.keys(DB))delete DB[k];Object.assign(DB,JSON.parse(JSON.stringify(p.DB)));Object.assign(SETTINGS,JSON.parse(JSON.stringify(p.SETTINGS)));},
  edit(nid,suffix){const c=DB.chats.find(x=>x.novelId===nid);c.history[1].text+=suffix;return c.history[1].text},
  text(nid){const c=DB.chats.find(x=>x.novelId===nid);return c?c.history[1].text:null},
  chats(){return DB.chats.map(c=>({id:c.id,novelId:c.novelId,title:c.title,t:c.history&&c.history[1]&&c.history[1].text}))},
  root(){const A=window.LumosP7CanonicalV401A;return A.buildRootFingerprint(A.extractCanonical({DB,SETTINGS}).canonical)},
  snap(){return JSON.stringify([DB,SETTINGS])}
};"""


class Device:
    def __init__(self, browser, name, holder, candidate, existing=True, page_errors=None, extra_config=None, http_origin=False):
        self.name, self.holder = name, holder
        self.candidate = Path(candidate)
        holder.setdefault('relay', []); holder.setdefault('relay_fail', [])
        self.ctx = browser.new_context()
        self.net_other = []
        self.errors = page_errors if page_errors is not None else []
        cfg = dict(extra_config or {})
        if existing: cfg['everConnected'] = True
        init = f"try{{localStorage.setItem({json.dumps(DEVICE_KEY)},{json.dumps(name)});"
        if cfg: init += f"if(!localStorage.getItem({json.dumps(CONFIG_KEY)}))localStorage.setItem({json.dumps(CONFIG_KEY)},{json.dumps(json.dumps(cfg))});"
        init += "}catch(_){}"
        self.ctx.add_init_script(init)
        self.ctx.route('**/*', self._route)
        self.page = self.ctx.new_page()
        self.page.on('pageerror', lambda e: self.errors.append(f'{name}: {str(e)[:200]}'))
        self.page.on('dialog', lambda d: d.accept())
        self.console = []
        self.page.on('console', lambda m: self.console.append(m.text))
        self.page.goto(HTTP_APP + 'lumos.html' if http_origin else Path(candidate).as_uri(), wait_until='load', timeout=120000)
        self.page.wait_for_timeout(1800)
        self.page.add_script_tag(content=HELPERS)
        self.page.evaluate("()=>{const s=lumosDriveSyncV136.state;s.accessToken='SYN-ACCESS-TOKEN-NOT-REAL';s.tokenExpiresAt=Date.now()+36e5;}")

    def _route(self, route):
        req = route.request; url = req.url
        if url.startswith(('file:', 'data:', 'blob:', 'about:')):
            return route.continue_()
        if url.startswith(HTTP_APP):
            return route.fulfill(status=200, body=self.candidate.read_bytes(), headers={'content-type': 'text/html; charset=utf-8'})
        if url == RELAY_ENDPOINT and req.method == 'OPTIONS':
            return route.fulfill(status=204, headers={'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': 'POST'})
        if url == RELAY_ENDPOINT and req.method == 'POST':
            return self._relay(route, req)
        if url.startswith('https://www.googleapis.com/'):
            sim = self.holder['sim']
            status, payload = sim.handle(self.name, req.method, url, req.headers, req.post_data_buffer or b'')
            if isinstance(payload, (bytes, bytearray)):
                return route.fulfill(status=status, body=bytes(payload), headers={'content-type': 'application/json'})
            return route.fulfill(status=status, body='' if payload is None else json.dumps(payload), headers={'content-type': 'application/json'})
        self.net_other.append(url)
        return route.abort()

    def _relay(self, route, req):
        env = json.loads(req.post_data_buffer.decode('utf-8'))
        rh = {k.lower(): v for k, v in req.headers.items()}
        up_headers = {str(k).lower(): str(v) for k, v in (env.get('headers') or {}).items()}
        if 'bodyText' in env: body, enc = env['bodyText'].encode('utf-8'), 'text'
        elif 'bodyBase64' in env: body, enc = base64.b64decode(env['bodyBase64']), 'base64'
        else: body, enc = b'', 'none'
        rec = {'device': self.name, 'url': env.get('url'), 'method': env.get('method'), 'headers': up_headers, 'body': body, 'encoding': enc,
               'envelope_keys': sorted(env.keys()), 'proxy_token_ok': len(rh.get('x-lumos-proxy-token', '')) >= 16, 'outcome': 'forwarded'}
        self.holder['relay'].append(rec)
        mode = None
        for rule in self.holder['relay_fail']:
            mode = rule(rec) or mode
        if mode == 'throw':
            rec['outcome'] = 'aborted'; return route.abort('connectionreset')
        if mode == '502':
            rec['outcome'] = '502-not-forwarded'
            return route.fulfill(status=502, body=json.dumps({'error': 'synthetic relay upstream 502'}), headers=dict(RELAY_EXPOSE, **{'X-Lumos-Upstream-Status': '502'}))
        if not str(env.get('url', '')).startswith('https://www.googleapis.com/'):
            rec['outcome'] = 'refused'; return route.fulfill(status=400, body='{"error":"sim relay: non-Drive upstream"}', headers=RELAY_EXPOSE)
        status, payload = self.holder['sim'].handle(self.name, env.get('method', 'GET'), env['url'], up_headers, body, via='relay')
        if mode == '502-after':
            rec['outcome'] = 'forwarded-then-502'
            return route.fulfill(status=502, body=json.dumps({'error': 'synthetic relay 502 after upstream'}), headers=dict(RELAY_EXPOSE, **{'X-Lumos-Upstream-Status': '502'}))
        out = bytes(payload) if isinstance(payload, (bytes, bytearray)) else ('' if payload is None else json.dumps(payload)).encode()
        return route.fulfill(status=status, body=out, headers=dict(RELAY_EXPOSE, **{'X-Lumos-Upstream-Status': str(status)}))

    def ev(self, js, arg=None):
        return self.page.evaluate(js, arg) if arg is not None else self.page.evaluate(js)

    def seed(self, profile):
        self.ev("async(p)=>{__P7T.seed(p);if(window.saveData)await window.saveData();}", profile)

    def settle(self):
        """reload once so the app's boot normalization runs (real profiles are already settled)"""
        self.page.reload(wait_until='load'); self.page.wait_for_timeout(2200); self.page.add_script_tag(content=HELPERS)
        self.page.evaluate("()=>{const s=lumosDriveSyncV136.state;s.accessToken='SYN-ACCESS-TOKEN-NOT-REAL';s.tokenExpiresAt=Date.now()+36e5;}")

    def state(self):
        return json.loads(self.ev("()=>JSON.stringify({DB,SETTINGS})"))

    def preview(self, **opt):
        return self.ev("async(o)=>await lumosDriveSyncV136.p7PreviewSyncV402B(o)", opt)

    def sync(self, **opt):
        return self.ev("async(o)=>await lumosDriveSyncV136.p7SyncV402B(o)", opt)

    def accept_first(self, ack_secret=True, disable_secret=False, accept_unclassified=True):
        plan = self.preview()
        r = self.sync(acceptPlanId=plan['planId'], acceptUnclassified=accept_unclassified, acknowledgeSecretDisclosure=ack_secret, disableSecretSync=disable_secret)
        return plan, r

    def stub_extension(self, mode='ok'):
        """extension-owner stub: counts LumosExtensionSyncV245.upload calls; mode ok|fail|real (real = call the owner)"""
        self.ev("""(mode)=>{const a=window.LumosExtensionSyncV245;if(!a.__origUploadP7T)a.__origUploadP7T=a.upload;window.__extCalls=window.__extCalls||[];
          a.upload=async(o)=>{window.__extCalls.push(JSON.stringify(o||{}));if(mode==='fail'){a.state.lastError='synthetic extension failure';return false}if(mode==='real')return a.__origUploadP7T.call(a,o);return true}}""", mode)

    def ext_calls(self):
        return self.ev("()=>(window.__extCalls||[]).slice()")

    def close(self):
        self.ctx.close()
