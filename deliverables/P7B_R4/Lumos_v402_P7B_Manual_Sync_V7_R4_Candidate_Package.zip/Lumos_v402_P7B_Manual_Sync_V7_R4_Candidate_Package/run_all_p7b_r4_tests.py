#!/usr/bin/env python3
"""Lumos v402 P7-B R4 — file-origin safe Drive write transport, on P7-A R5 OFFICIAL (H-P7B-01..38).

    NO_COLOR=1 python3 run_all_p7b_r4_tests.py            # verify (read-only on the package)
    NO_COLOR=1 python3 run_all_p7b_r4_tests.py --write    # also write P7B_R4_Test_Results.json
Requires python3, playwright + Chromium ($LUMOS_CHROMIUM or bundled), node >= 22, GNU patch.
No real network: https://www.googleapis.com/** is served by the in-process DriveSim; the Lumos Universal Relay
endpoint is served by the synthetic relay fixture (p7b_device.py) in front of the same DriveSim; every other
non-file request is aborted and recorded. The candidate is loaded from file:// (origin "null"), exactly like the
operator's standalone HTML, so every P7 write in H-P7B-01..32 already travels the R4 relay path.
"""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, tempfile, time
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from p7b_drive_sim import DriveSim
from p7b_device import Device

PARENT = ROOT / 'Lumos_v401_P7A_Canonical_State_Fingerprint_R5_OFFICIAL.html'
CAND = ROOT / 'Lumos_v402_P7B_Manual_Sync_V7_R4_Candidate.html'
BLOCK = ROOT / 'p7b_v7_block.js'
DIFF = ROOT / 'P7B_R4_correction.diff'
PARENT_SHA = '48bc0e57d6256aef189086548d3061add6c8a9cee5683f401dbf4b291f77d17d'; PARENT_BYTES = 4663880
R5_P7A_BODY_SHA = '4e4bd81b01404cdb7344a117d8718a1f5422efad4579fab4dfea9d7d7ba0630c'
R2_V136_SHA = '3d39e5e79d9d43d0e23415e045644e927c94054cf903492d347c0880355e1454'  # accepted R2/R3 v136 (lineage)
R4_V136_SHA = 'f93bbfbbacf00b97a4caf18c82b92154bfbda8ec6b9ae20a63a1bc612cebf9e1'
R3_SHA = '858acdc55edaec381efe2e89a9527f500d6d7b9fb9e39346ec08b8d4fada6e93'
V379 = 'lumos-v379-version-authority'
REL = {'VERSION': 'v402 R4', 'BUILD': 'v402-p7b-manual-sync-v7-r4', 'TITLE': 'Lumos 3.0 · v402 R4 P7-B Manual Sync v7'}
V136 = 'lumos-v136-drive-sync-script'
PROTECTED = {'lumos-p7-canonical-state-v401a': R5_P7A_BODY_SHA, 'lumos-v161-storage-script': '8e74465b28c851b2a7eff5d19d291c1420ce4a082d46a4c5d9c9c1f15680dbed',
             'lumos-v391-operations-panel-script': 'd8f7154661efbc4912934704de75d05f61b921328dafcc25e0d53f5be59f6156',
             'lumos-risu-runtime-v140': 'c37ff04e0fa8ece0c295b9f0cae0775bd98eb937e34dcaa716613a9bdcae451b'}
MAIN_SHA = 'fee9ef8eb0fc6b84b8752934897f14154b431e314924e635fdf1b9c354cc8aa0'
P7A_MODULE_SHA = '5e2c7b0f'  # prefix check replaced below by exact parent comparison
PROFILES = json.loads((ROOT / 'fixtures' / 'profiles.json').read_text('utf-8'))
SECRETS = PROFILES['secretStrings']
G, TRAILS, TRUTH, SIMS, DEVICES, ERRORS = [], {}, [], [], [], []
LEGACY_DEVICES = {'devL', 'devLeg', 'devLegP'}
OTHER_NET = set()

def sha(b): return hashlib.sha256(b).hexdigest()
def writer(name): return 'w' + sha(name.encode())[:16]
def gate(i, n, ok, ev):
    G.append({'id': i, 'name': n, 'pass': bool(ok), 'evidence': ev}); print(f"{i} {'PASS' if ok else 'FAIL'} {n} :: {ev}", flush=True)
SRE = re.compile(rb'<script\b([^>]*)>(.*?)</script>', re.S | re.I)
def scripts(b):
    out = []
    for m in SRE.finditer(b):
        a = m.group(1).decode('utf-8', 'replace'); i = re.search(r'\bid\s*=\s*["\']([^"\']+)', a)
        out.append({'id': i.group(1) if i else None, 'attrs': a, 'body': m.group(2), 'src': 'src=' in a, 'start': m.start(), 'end': m.end()})
    return out
def chromium():
    for c in [os.environ.get('LUMOS_CHROMIUM') or '', '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', '/usr/bin/chromium']:
        if c and Path(c).exists(): return c

def head_manifest(sim):
    """independent (Python) head resolution: highest valid (rev, writer, nonce) with all bodies present + hash-verified"""
    objs = {f['name']: f for f in sim.children('objects')}
    cands = []
    for f in sim.children('manifests'):
        m = re.fullmatch(r'(\d{10})-([a-z0-9]+)-([a-z0-9]+)\.json', f['name'])
        if m: cands.append((int(m.group(1)), m.group(2), m.group(3), f))
    for rev, w, n, f in sorted(cands, reverse=True):
        try: man = json.loads(f['content'])
        except Exception: continue
        ok = man.get('revision') == rev and man.get('writer') == w
        for e in man.get('objects', []):
            key = 'o-' + sha((e['domain'] + '\u0000' + e['id']).encode())[:32] + '-' + e['hash'] + '.json'
            b = objs.get(key)
            if not b or sha(b['content']) != e['hash'] or len(b['content']) != e['size']: ok = False; break
        if ok: return man, f['name'], [c[3]['name'] for c in cands if c[0] == rev and c[3]['name'] != f['name']]
    return None, None, []

LIVE_WORLDS = []
class World:
    """one scenario = one synthetic Drive; opening a new scenario closes the previous scenario's browser contexts (memory bound)"""
    def __init__(self, browser):
        for old in LIVE_WORLDS:
            for d in old.devices:
                try: d.close()
                except Exception: pass
        LIVE_WORLDS.clear(); LIVE_WORLDS.append(self)
        self.browser = browser; self.sim = DriveSim(); SIMS.append(self.sim); self.devices = []
    def device(self, name, existing=True, extra_config=None, seed=None, http_origin=False):
        d = Device(self.browser, name, {'sim': self.sim}, CAND, existing=existing, page_errors=ERRORS, extra_config=extra_config, http_origin=http_origin)
        DEVICES.append(d); self.devices.append(d)
        if seed is not None: d.seed(seed)
        return d
    def mark(self): return len(self.sim.log)
    def since(self, m, dev=None): return DriveSim.summarize(self.sim.window(m), dev.name if dev else None)
    def run(self, dev, label=None, **opt):
        m = self.mark(); r = dev.sync(**opt); s = self.since(m, dev)
        if r.get('planned') is not None:
            p = r['planned']; TRUTH.append({'label': label or r.get('result'), 'ok': p['uploadCount'] == s['bodyUploads'] and p['uploadBytes'] == s['bodyUploadBytes']
                                              and p['downloadCount'] == s['bodyDownloads'] and p['downloadBytes'] == s['bodyDownloadBytes'], 'planned': p, 'measured': s})
        if label: TRAILS[label] = r.get('trail')
        return r, s

def settled_state(browser):
    w = World(browser); s = w.device('devSeed', seed=PROFILES['base']); s.settle(); s.settle(); st = s.state(); s.close(); return st

def pair(browser, st, a='devA', b='devB', a_config=None):
    w = World(browser); A = w.device(a, seed=st, extra_config=a_config); A.accept_first(); B = w.device(b, seed=st); B.accept_first(); return w, A, B

def main():
    write = '--write' in sys.argv
    par, cand = PARENT.read_bytes(), CAND.read_bytes(); ps, cs = scripts(par), scripts(cand)
    changed = [p['id'] for p, c in zip(ps, cs) if p['body'] != c['body'] or p['attrs'] != c['attrs']]
    prot = {k: sha(next(s for s in cs if s['id'] == k)['body']) for k in PROTECTED}
    prot_ok = all(prot[k] == sha(next(s for s in ps if s['id'] == k)['body']) for k in PROTECTED) and all(v is None or prot[k] == v for k, v in PROTECTED.items())
    main_c = [s for s in cs if s['id'] is None and not s['src'] and b'async function callCustomModelAPI' in s['body']]
    v136p, v136c = next(s for s in ps if s['id'] == V136)['body'], next(s for s in cs if s['id'] == V136)['body']
    v379p, v379c = next(s for s in ps if s['id'] == V379)['body'], next(s for s in cs if s['id'] == V379)['body']
    def nonscript(b, ss):
        out, p = b'', 0
        for s in ss: out += b[p:s['start']]; p = s['end']
        return out + b[p:]
    import difflib
    ns_diff = [l for l in difflib.unified_diff(nonscript(par, ps).decode('utf-8').split('\n'), nonscript(cand, cs).decode('utf-8').split('\n'), n=0, lineterm='') if l[:1] in '+-' and not l.startswith(('+++', '---'))]
    ns_ok = sorted(l[0] + l[1:].strip() for l in ns_diff) == sorted(['-<title>Lumos 3.0 · v390 R12 EIL H9 Safe Proof & Strict Batch · Manual Sync</title>', '-<meta name="lumos-build" content="v390-r12-eil-h9-safe-proof-strict-batch-integration">',
                                                       '+<title>Lumos 3.0 · v402 R4 P7-B Manual Sync v7</title>', '+<meta name="lumos-build" content="v402-p7b-manual-sync-v7-r4">'])
    gate('H-P7B-01', 'exact parent / scope', sha(par) == PARENT_SHA and len(par) == PARENT_BYTES and len(ps) == 257 and len(cs) == 257 and changed == [V379, V136] and prot_ok and sha(main_c[0]['body']) == MAIN_SHA
         and sha(v136c) == R4_V136_SHA and ns_ok,
         f'parent R5 OFFICIAL {len(par):,} B {sha(par)[:12]}… ; scripts 257→257 ; changed={changed} ; v136 {sha(v136p)[:12]}…→{sha(v136c)[:12]}… (= reviewed R4 v136 = R2/R3 v136 + R4 write transport) ; P7-A module = R5 body {prot["lumos-p7-canonical-state-v401a"][:12]}… ; v161/v391/v140/main byte-identical ; non-script changes = <title> + <meta lumos-build> only ; built from exact R5, not from R3 {sha(cand) != R3_SHA}')

    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        kw = {'headless': True, 'args': ['--no-sandbox']}
        if chromium(): kw['executable_path'] = chromium()
        br = pw.chromium.launch(**kw)
        ST = settled_state(br)

        # ---- H02 startup ----
        w = World(br); m0 = w.mark(); dn = w.device('devNew', existing=False); de = w.device('devOld', existing=True, extra_config={'folderId': 'x', 'lastSyncAt': 1})
        dn.page.wait_for_timeout(1500); boot = w.since(m0); boot['requests'] += len(dn.holder['relay']) + len(de.holder['relay'])
        st_false = dn.ev("async()=>await lumosDriveSyncV136.startupSync()") is False and de.ev("async()=>await lumosDriveSyncV136.startupSync()") is False
        blk = BLOCK.read_text('utf-8'); top = [l for l in blk.split('\n') if re.match(r'^  \S', l) and not re.match(r'^  (?:function|async function|const|let|//|\}\s*$)', l)]
        gate('H-P7B-02', 'startup remains OFF', boot['requests'] == 0 and st_false and not top and dn.ev("()=>lumosDriveSyncV136.p7StatusV402B().active") is False,
             f'Drive + relay requests during load (new + existing install) = {boot["requests"]} ; startupSync() → false ; v7 block top-level statements other than declarations = {len(top)} ; v7 inactive until migration gate')

        # ---- H03-H05 ----
        w, A, B = pair(br, ST)
        r, s = w.run(B, 'SAME')
        gate('H-P7B-03', 'SAME', r['result'] == 'SAME' and s['bodyUploads'] == 0 and s['bodyDownloads'] == 0 and s['manifestWrites'] == 0,
             f"result={r['result']} bodyUp={s['bodyUploads']} bodyDown={s['bodyDownloads']} manifestWrites={s['manifestWrites']} (metadata lists={s['lists']})")
        A.ev("()=>__P7T.edit('nov-005',' 수정')"); r4, s4 = w.run(A, 'upload-one')
        gate('H-P7B-04', 'one local object (100 novels)', r4['ok'] and s4['bodyUploads'] == 1 and s4['manifestWrites'] == 1 and s4['bodyDownloads'] == 0 and [u['id'] for u in r4['uploads']] == ['nov-005'],
             f"uploads={[u['id'] for u in r4['uploads']]} bodyUploads={s4['bodyUploads']} ({s4['bodyUploadBytes']} B) manifest={s4['manifestWrites']}")
        r5, s5 = w.run(B, 'download-one')
        gate('H-P7B-05', 'one remote object', r5['ok'] and s5['bodyDownloads'] == 1 and s5['bodyUploads'] == 0 and s5['manifestWrites'] == 0 and B.ev("()=>__P7T.text('nov-005')").endswith(' 수정') and A.ev("()=>__P7T.root()") == B.ev("()=>__P7T.root()"),
             f"downloads={[d['id'] for d in r5['downloads']]} bodyDownloads={s5['bodyDownloads']} unrelated=0 ; roots equal")

        # ---- H06 same-novel divergence ----
        ta = A.ev("()=>__P7T.edit('nov-010',' [PC 문장]')"); w.run(A)
        tb = B.ev("()=>__P7T.edit('nov-010',' [모바일 문장]')"); r6, s6 = w.run(B, 'fork')
        chats = B.ev("()=>__P7T.chats()"); orig = next(c for c in chats if c['novelId'] == 'nov-010'); fork = [c for c in chats if str(c['title']).endswith('(기기 분기본)')]
        w.run(A); conv = A.ev("()=>__P7T.root()") == B.ev("()=>__P7T.root()")
        gate('H-P7B-06', 'same novel divergence', r6['result'] == 'FORKED' and orig['t'] == ta and len(fork) == 1 and fork[0]['t'] == tb and '모바일' not in orig['t'] and 'PC 문장' not in fork[0]['t'] and conv,
             f"remote text kept at nov-010, local preserved as {fork[0]['novelId'] if fork else None} \"{fork[0]['title'] if fork else ''}\" ; no sentence merge ; devices converge")

        # ---- H07 disjoint ----
        A.ev("()=>__P7T.edit('nov-020',' A')"); w.run(A); B.ev("()=>__P7T.edit('nov-030',' B')"); r7, s7 = w.run(B, 'disjoint'); w.run(A)
        gate('H-P7B-07', 'disjoint bidirectional edits', s7['bodyUploads'] == 1 and s7['bodyDownloads'] == 1 and not r7['forks'] and A.ev("()=>__P7T.root()") == B.ev("()=>__P7T.root()"),
             f"B: upload {[u['id'] for u in r7['uploads']]} + download {[d['id'] for d in r7['downloads']]} ; forks=0 ; converged")

        # ---- H08 item conflict ----
        A.ev("()=>{SETTINGS.customPromptModes[0].content+=' A버전'}"); B.ev("()=>{SETTINGS.customPromptModes[0].content+=' B버전'}")
        w.run(A); r8, _ = w.run(B); w.run(A)
        ids = B.ev("()=>SETTINGS.customPromptModes.map(x=>x.id)"); prompts = B.ev("()=>SETTINGS.customPromptModes.map(x=>String(x.content).slice(-4))")
        gate('H-P7B-08', 'item conflict', any(f['kind'] == 'item-fork' for f in r8['forks']) and len(ids) == 2 and any('__conflict_' in i for i in ids) and sorted(prompts) == sorted([' A버전', ' B버전'])
             and A.ev("()=>__P7T.root()") == B.ev("()=>__P7T.root()"), f'item fork ids={ids} ; both versions kept ; converged')

        # ---- H09 long authored field ----
        A.ev("()=>{SETTINGS.agentPhase1Prompt+='\\nA의 긴 프롬프트 추가'.repeat(3);lumosDriveSyncV136._testRecordSettingsMutationV389('t9a')}"); w.run(A)
        A.page.wait_for_timeout(30)
        B.ev("()=>{SETTINGS.agentPhase1Prompt+='\\nB의 긴 프롬프트 추가'.repeat(3);lumosDriveSyncV136._testRecordSettingsMutationV389('t9b')}"); r9, _ = w.run(B); w.run(A)
        recs = A.ev("()=>JSON.stringify(SETTINGS.p7ConflictRecordsV402B||[])"); recs = json.loads(recs); rb = json.loads(B.ev("()=>JSON.stringify(SETTINGS.p7ConflictRecordsV402B||[])"))
        rec = next((x for x in recs if x['field'] == 'agentPhase1Prompt'), None)
        both = rec and ('A의 긴' in rec['winner']['value'] + rec['loser']['value']) and ('B의 긴' in rec['winner']['value'] + rec['loser']['value'])
        gate('H-P7B-09', 'long authored field conflict', rec is not None and both and recs == rb and not any(s in json.dumps(recs) for s in SECRETS),
             f"conflict record {rec['conflictId'] if rec else None}: winner={rec['winner']['writer'] if rec else None} loser={rec['loser']['writer'] if rec else None} (both texts verbatim) ; record identical on both devices ; no secrets")

        # ---- H10 scalar field ----
        A.ev("()=>{SETTINGS.temperature=0.3;lumosDriveSyncV136._testRecordSettingsMutationV389('t10a')}"); w.run(A); A.page.wait_for_timeout(30)
        B.ev("()=>{SETTINGS.temperature=1.4;lumosDriveSyncV136._testRecordSettingsMutationV389('t10b')}"); r10, _ = w.run(B); w.run(A)
        ta10, tb10 = A.ev("()=>SETTINGS.temperature"), B.ev("()=>SETTINGS.temperature")
        no_rec = not any(x['field'] == 'temperature' for x in json.loads(A.ev("()=>JSON.stringify(SETTINGS.p7ConflictRecordsV402B||[])")))
        wa, wb = writer('devA'), writer('devB')
        gate('H-P7B-10', 'ordinary scalar field', ta10 == tb10 == 1.4 and no_rec and any(f['kind'] == 'field-lww' and f['winner'] == 'local' for f in r10['forks']),
             f'newer field clock wins (temperature=1.4 on both), no conflict record for scalar ; equal-clock tie → lexically greater writer ({max(wa, wb)}) (rule in p7ResolveV402B; exercised for secrets in H-P7B-21)')

        # ---- H11 cache / body integrity ----
        A.ev("()=>__P7T.edit('nov-040',' c')"); w.run(A); man, _, _ = head_manifest(w.sim); e = next(x for x in man['objects'] if x['id'] == 'nov-040')
        B.ev("([k])=>lumosDriveSyncV136._p7TestV402B.bodyCache.set(k,'{\"poison\":true}')", [f"novel\u0000nov-040\u0000{e['hash']}"])
        r11, s11 = w.run(B)
        A.ev("()=>__P7T.edit('nov-041',' d')"); w.run(A); man, _, _ = head_manifest(w.sim); e2 = next(x for x in man['objects'] if x['id'] == 'nov-041')
        f = next(f for f in w.sim.children('objects') if f['name'].endswith(e2['hash'] + '.json')); f['content'] = f['content'].replace(' d"'.encode(), ' X"'.encode())
        before = B.ev("()=>__P7T.snap()"); r11b, _ = w.run(B); after = B.ev("()=>__P7T.snap()")
        gate('H-P7B-11', 'cache / body integrity', r11['ok'] and r11['cacheRejects'] == 1 and s11['bodyDownloads'] == 1 and r11b['result'] == 'INVALID_REMOTE' and before == after,
             f"poisoned cache rejected ({r11['cacheRejects']}) → authoritative body fetched & verified ; tampered remote body → {r11b['result']} ; B DB/SETTINGS byte-identical")
        f['content'] = f['content'].replace(' X"'.encode(), ' d"'.encode())

        # ---- H12 fence ----
        w, A, B = pair(br, ST)
        A.ev("()=>__P7T.edit('nov-050',' A')"); B.ev("()=>__P7T.edit('nov-060',' B')")
        clone = w.sim.clone(); since = w.sim.seq; hb = B.holder; hb['sim'] = clone; B.sync(); hb['sim'] = w.sim
        fired = []
        def inject(sim, info, body, clone=clone, since=since):
            if not fired and info['device'] == 'devA' and info['method'] == 'POST' and b'p7-v402b-object' in (body or b''):
                fired.append(1); sim.import_new_files(clone, since)
        w.sim.hooks.append(inject); r12, _ = w.run(A, 'stale-retry'); w.sim.hooks.clear()
        rB, _ = w.run(B)
        gate('H-P7B-12', 'compare-at-commit fence', r12['ok'] and r12['attempts'] == 2 and 'retryable' in r12['trail'] and A.ev("()=>__P7T.text('nov-060')").endswith(' B') and A.ev("()=>__P7T.root()") == B.ev("()=>__P7T.root()"),
             f"remote advanced between inspect and commit → attempt 1 aborted at fence, re-evaluated, committed rev {r12['revision']} with both changes ; trail={'>'.join(r12['trail'])}")

        # ---- H13 crash ----
        w, A, B = pair(br, ST)
        A.ev("()=>__P7T.edit('nov-070',' crash')"); h0 = head_manifest(w.sim)[1]; rootA = A.ev("()=>__P7T.root()")
        # R4: the file-origin relay transport (Provider Core v134 wrapper) retries a one-shot 5xx, so the manifest write is kept failing for the whole run
        w.sim.fail_rules.append(lambda info, body: 500 if (info['device'] == 'devA' and b'p7-v402b-manifest' in (body or b'')) else None)
        r13, s13 = w.run(A, 'crash'); w.sim.fail_rules.clear(); h1 = head_manifest(w.sim)[1]
        r13b, s13b = w.run(A)
        gate('H-P7B-13', 'partial / crash', r13['ok'] is False and s13['bodyUploads'] == 1 and h0 == h1 and A.ev("()=>__P7T.root()") == rootA and r13b['ok'] and s13b['bodyUploads'] == 0 and s13b['manifestWrites'] == 1,
             f"body uploaded (relay), manifest write failed (every relayed try 500) → {r13['result']}, head unchanged ; retry reuses content-addressed body (uploads 0, manifest 1)")

        # ---- H14 sibling race (both directions) ----
        names = ['devA', 'devB', 'devC', 'devD', 'devE', 'devF']
        lo, hi = sorted(names[:2], key=writer)  # writer(lo) < writer(hi)
        res14 = {}
        for label, (a_name, b_name) in {'A-loses': (lo, hi), 'B-loses-after-success': (hi, lo)}.items():
            w, A, B = pair(br, ST, a_name, b_name)
            A.ev("()=>__P7T.edit('nov-080',' A')"); B.ev("()=>__P7T.edit('nov-090',' B')")
            clone = w.sim.clone(); since = w.sim.seq; hb = B.holder; hb['sim'] = clone; rbc = B.sync(); hb['sim'] = w.sim
            fired = []
            def inject2(sim, info, body, clone=clone, since=since, fired=fired, a_name=a_name):
                if not fired and info['device'] == a_name and info['method'] == 'POST' and b'p7-v402b-manifest' in (body or b''):
                    fired.append(1); sim.import_new_files(clone, since)
            w.sim.hooks.append(inject2); ra, _ = w.run(A); w.sim.hooks.clear()
            rb2, _ = w.run(B); ra2, _ = w.run(A)
            man, hname, _ = head_manifest(w.sim)
            revs = sorted(int(f['name'][:10]) for f in w.sim.children('manifests'))
            res14[label] = {'A': ra['result'], 'A_attempts': ra['attempts'], 'A_siblingsLost': ra['siblingsLost'], 'B_first': rbc['result'], 'B_next': rb2['result'], 'baseKind': rb2.get('baseKind'),
                            'bothChanges': A.ev("()=>__P7T.text('nov-090')").endswith(' B') and B.ev("()=>__P7T.text('nov-080')").endswith(' A'),
                            'converged': A.ev("()=>__P7T.root()") == B.ev("()=>__P7T.root()"), 'sameRevSiblings': revs.count(2), 'deletes': DriveSim.summarize(w.sim.log)['deletes']}
        ok14 = (res14['A-loses']['A_siblingsLost'] >= 1 and res14['A-loses']['A'] == 'SYNCED' and res14['A-loses']['A_attempts'] >= 2 and all(v['bothChanges'] and v['converged'] and v['sameRevSiblings'] == 2 and v['deletes'] == 0 for v in res14.values())
                and res14['B-loses-after-success']['baseKind'] == 'common-ancestor')
        gate('H-P7B-14', 'same-revision sibling race', ok14,
             f"A loses: post-verify sees winner, siblingsLost={res14['A-loses']['A_siblingsLost']}, no success until later rev ; B reported success but lost total order: next sync resolves base via common ancestor → its change re-committed ; both rev2 siblings preserved, deletes 0 ; converged")

        # ---- H15 pagination ----
        res15 = {}
        for n in (25, 100, 150):
            w, A, B = pair(br, ST); man, hname, _ = head_manifest(w.sim); mf = w.sim.folder_ids('manifests')[0]; prev = hname
            for i in range(n):
                rev = man['revision'] + 1 + i; m2 = dict(man, revision=rev, parentRevision=rev - 1, writer='w0000000000000000', parentNameV402B=prev)
                name = f'{rev:010d}-w0000000000000000-{i:06d}.json'; w.sim.add_file(name, [mf], json.dumps(m2).encode()); prev = name
            top = man['revision'] + n
            bad = dict(man, revision=top + 1, writer='w0000000000000000', objects=[dict(man['objects'][0], hash='0' * 64)] + man['objects'][1:])
            w.sim.add_file(f'{top + 1:010d}-w0000000000000000-zzzzzz.json', [mf], json.dumps(bad).encode())
            r15, s15 = w.run(B); res15[n] = {'result': r15['result'], 'revision': r15['revision'], 'expected': top, 'lists': s15['lists']}
        gate('H-P7B-15', 'pagination', all(v['result'] == 'SAME' and v['revision'] == v['expected'] for v in res15.values()),
             f"Drive page size forced to 10: histories 25/100/150 (+1 invalid top manifest) → head revs {[v['revision'] for v in res15.values()]} = expected {[v['expected'] for v in res15.values()]} ; invalid top skipped")

        # ---- H16/H17 v6 migration ----
        w = World(br); L = w.device('devL', seed=ST)
        L.ev("()=>{const c=JSON.parse(JSON.stringify(DB.chats[0]));c.id='chat-L-only';c.novelId='nov-L-only';c.title='레거시 전용';delete c.novelSyncV136;DB.chats.push(c)}")
        L.ev("async()=>{await window.saveData()}"); L.ev("async()=>await lumosDriveSyncV136._legacySyncV246({interactive:true,force:true})")
        legacy = {f['name']: sha(f['content']) for f in w.sim.files.values() if f['name'] in ('lumos-settings.json', 'lumos-novels.json')}
        M = w.device('devM', seed=ST); M.ev("()=>__P7T.edit('nov-001',' M수정')"); M.ev("async()=>{await window.saveData()}")
        snapM = M.ev("()=>__P7T.snap()"); m0 = w.mark(); plan = M.preview(); s16 = w.since(m0, M)
        creates16 = [e for e in w.sim.window(m0) if e['kind'] in ('upload', 'create-meta', 'patch', 'delete')]
        gate('H-P7B-16', 'v6 migration dry-run', plan['mode'] == 'migrate' and plan['legacyFiles'] == {'settings': True, 'novels': True} and plan['uploadCount'] > 0 and not creates16 and M.ev("()=>__P7T.snap()") == snapM and plan['secret']['count'] > 0 and not any(s in json.dumps(plan, ensure_ascii=False) for s in SECRETS),
             f"plan mode=migrate, legacy settings+novels found, uploadCount={plan['uploadCount']} ({plan['uploadBytes']:,} B), secret count={plan['secret']['count']} (values 0) ; Drive writes/creates={len(creates16)} ; local DB/SETTINGS unchanged")
        r17, s17 = w.run(M, 'migrate', acceptPlanId=plan['planId'], acceptUnclassified=True, acknowledgeSecretDisclosure=True)
        man, hname, _ = head_manifest(w.sim); rev1 = [f for f in w.sim.children('manifests') if f['name'].startswith('0000000001-')]
        rev1_ok = len(rev1) == 1 and all(any(o['name'].endswith(e['hash'] + '.json') and sha(o['content']) == e['hash'] for o in w.sim.children('objects')) for e in json.loads(rev1[0]['content'])['objects'])
        chain_ok = man['revision'] == 1 or man.get('parentNameV402B') == rev1[0]['name']; legacy2 = {f['name']: sha(f['content']) for f in w.sim.files.values() if f['name'] in ('lumos-settings.json', 'lumos-novels.json')}
        chatsM = M.ev("()=>__P7T.chats()")
        gate('H-P7B-17', 'v6 migration commit', r17['result'] == 'MIGRATED' and man and rev1_ok and chain_ok and legacy == legacy2 and any(c['novelId'] == 'nov-L-only' for c in chatsM) and M.ev("()=>__P7T.text('nov-001')").endswith(' M수정')
             and man['canonicalRootHash'] == M.ev("()=>__P7T.root()"),
             f"rev1 {rev1[0]['name'] if rev1 else None} valid (every body hash verified independently) ; head {hname} (settle={r17.get('settleCommit', False)}, parent=rev1) ; legacy lumos-settings/lumos-novels bytes unchanged ; merged: legacy-only novel present + local edit kept ; local root == head root")

        # ---- H18 unclassified gate ----
        w = World(br); U = w.device('devU', seed=ST)
        U.ev("()=>{for(let i=0;i<16;i++){DB.chats[i]['userNoteX'+String.fromCharCode(65+i)]='메모'+i}DB.futureRootA={a:1};DB.futureRootB=[1];DB.futureRootC='c'}")
        snapU = U.ev("()=>__P7T.snap()"); plan = U.preview(); m0 = w.mark()
        blocked = U.sync(acceptPlanId=plan['planId'], acknowledgeSecretDisclosure=True); sb = w.since(m0, U); snapU2 = U.ev("()=>__P7T.snap()")
        ok_run, _ = w.run(U, None, acceptPlanId=plan['planId'], acceptUnclassified=True, acknowledgeSecretDisclosure=True)
        gate('H-P7B-18', 'real-profile unclassified gate', plan['unclassifiedCount'] == 19 and blocked['result'] == 'ACCEPTANCE_REQUIRED' and sb['requests'] == 0 and snapU == snapU2 and ok_run['ok'] and not any(s in json.dumps(plan, ensure_ascii=False) for s in SECRETS),
             f"dry-run lists 19 paths (e.g. {plan['unclassified'][:2]}…) without secret values ; commit without acceptUnclassified → {blocked['result']} (Drive requests 0, local unchanged) ; after explicit acceptance → {ok_run['result']}")

        # ---- H19 secret defaults / disclosure ----
        w = World(br); N = w.device('devN', existing=False, seed=ST); E = w.device('devE', existing=True, seed=ST); E2 = w.device('devE2', existing=True, seed=ST)
        stN, stE = N.ev("()=>lumosDriveSyncV136.p7StatusV402B().secret"), E.ev("()=>lumosDriveSyncV136.p7StatusV402B().secret")
        planE = E.preview(); nodisc = E.sync(acceptPlanId=planE['planId'], acceptUnclassified=True)
        rE, sE = w.run(E, None, acceptPlanId=planE['planId'], acceptUnclassified=True, disableSecretSync=True)
        planE2 = E2.preview(); rE2, sE2 = w.run(E2, None, acceptPlanId=planE2['planId'], acceptUnclassified=True, acknowledgeSecretDisclosure=True)
        gate('H-P7B-19', 'secret channel defaults / disclosure', stN['enabled'] is False and stN['source'] == 'new-install' and stE['enabled'] is True and stE['disclosed'] is False and nodisc['result'] == 'ACCEPTANCE_REQUIRED'
             and rE['ok'] and sE['secretWrites'] == 0 and E.ev("()=>lumosDriveSyncV136.p7StatusV402B().secret.enabled") is False and rE2['ok'] and sE2['secretWrites'] == 1,
             f"new install → OFF ; existing install → ON + disclosure required (commit blocked without it) ; disabled before commit → secret writes 0 ; acknowledged → 1 secret snapshot")

        # ---- H20 secret isolation ----
        w, A, B = pair(br, ST, 'devA', 'devB', a_config={'refreshToken': 'SYN-REFRESH-TOKEN-XYZ'})
        r0 = A.ev("()=>__P7T.root()"); A.ev("()=>{SETTINGS.apiKey='AIzaSy-CHANGED-SECRET-000099'}"); r1 = A.ev("()=>__P7T.root()")
        r20, s20 = w.run(A)
        canon_files = [f for f in w.sim.files.values() if w.sim._area(f) in ('objects', 'manifests')]
        leak = [s for s in SECRETS + ['AIzaSy-CHANGED-SECRET-000099', 'SYN-ACCESS-TOKEN-NOT-REAL', 'SYN-REFRESH-TOKEN-XYZ'] if any(s.encode() in f['content'] or s in f['name'] for f in canon_files)]
        sec_files = [f for f in w.sim.files.values() if w.sim._area(f) == 'secrets']
        oauth_leak = [s for s in ('SYN-ACCESS-TOKEN-NOT-REAL', 'SYN-REFRESH-TOKEN-XYZ') if any(s.encode() in f['content'] for f in w.sim.files.values())]
        name_leak = [f['name'] for f in w.sim.files.values() if any(s in f['name'] for s in SECRETS)]
        gate('H-P7B-20', 'secret isolation', r0 == r1 and r20['result'] == 'SAME' and s20['bodyUploads'] == 0 and s20['manifestWrites'] == 0 and s20['secretWrites'] == 1 and not leak and not oauth_leak and not name_leak
             and any(b'AIzaSy-CHANGED-SECRET-000099' in f['content'] for f in sec_files) and not any(s in json.dumps(r20, ensure_ascii=False) for s in SECRETS + ['AIzaSy-CHANGED-SECRET-000099']),
             f"changing only a provider key: canonical root identical, sync SAME (bodies 0, manifest 0), secret snapshot 1 ; secrets in object/manifest bytes or any filename = 0 ; Drive OAuth/relay material in any Drive file = 0 ; report contains no secret values")

        # ---- H21 secret concurrent merge ----
        A.ev("()=>{SETTINGS.openaiApiKey='sk-NEW-A-000100'}"); B.ev("()=>{SETTINGS.ollamaApiKey='ollama-NEW-B-000101'}")
        w.run(A); w.run(B); w.run(A)
        both = A.ev("()=>[SETTINGS.openaiApiKey,SETTINGS.ollamaApiKey]") == ['sk-NEW-A-000100', 'ollama-NEW-B-000101'] == B.ev("()=>[SETTINGS.openaiApiKey,SETTINGS.ollamaApiKey]")
        sf = w.sim.folder_ids('secrets')[0]; T = int(time.time() * 1000) + 10 ** 9
        for wid, val in (('w0000000000000001', 'TIE-LOW-000102'), ('wfffffffffffffff', 'TIE-HIGH-000103')):
            snap = {'format': 'lumos-p7-secret-snapshot', 'schemaVersion': 1, 'writer': wid, 'entries': {'["naiToken"]': {'segs': ['naiToken'], 'value': val, 't': T, 'w': wid}}}
            w.sim.add_file(f's-{wid}-0000000001.json', [sf], json.dumps(snap).encode())
        w.run(A); w.run(B)
        tie = A.ev("()=>SETTINGS.naiToken") == 'TIE-HIGH-000103' == B.ev("()=>SETTINGS.naiToken")
        gate('H-P7B-21', 'secret concurrent merge', both and tie, 'different paths from two writers converge on both devices ; same path, equal clock → deterministic writer tie-break (wfff… wins) on both devices')

        # ---- H22 naiCharacterRefImage ----
        imgs_in_store = [f['name'] for s in SIMS for f in s.files.values() if s._area(f) in ('objects', 'manifests') and (b'data:image' in f['content'] or b'iVBORw0KGgo' in f['content'] or b'StoreKey' in f['content'])]
        w = World(br); A = w.device('devA', seed=ST); A.accept_first()
        noimg = json.loads(json.dumps(ST)); noimg['SETTINGS'].pop('naiCharacterRefImage', None); noimg['DB']['chats'][0].pop('representativeImageDataUrl', None)
        P = w.device('devP', seed=noimg); _, rp = P.accept_first(); rp2, sp2 = w.run(P)
        gate('H-P7B-22', 'naiCharacterRefImage', not imgs_in_store and A.ev("()=>typeof SETTINGS.naiCharacterRefImage==='string'&&SETTINGS.naiCharacterRefImage.startsWith('data:')") and rp['ok'] and rp2['result'] == 'SAME' and sp2['bodyUploads'] == 0
             and P.ev("()=>!String(SETTINGS.naiCharacterRefImage||'').startsWith('data:')"),
             f"object store + manifests across every run: image bytes/data URLs/store keys = {len(imgs_in_store)} ; device without the image joins → marker kept remote (pending asset), no bytes transferred, next sync SAME with 0 uploads (no ping-pong)")

        # ---- H29 secret deletion convergence ----
        OLD = 'SECRET-TO-DELETE-XYZ-000201'
        w, A, B = pair(br, ST)
        A.ev("(v)=>{SETTINGS.apiKey=v}", OLD); w.run(A); w.run(B)
        had = B.ev("()=>SETTINGS.apiKey") == OLD
        root0 = A.ev("()=>__P7T.root()"); A.ev("()=>{SETTINGS.apiKey=''}"); root1 = A.ev("()=>__P7T.root()")
        m0 = w.mark(); rA, sA = w.run(A, 'secret-clear')
        a_cleared = A.ev("()=>SETTINGS.apiKey") == ''
        tomb_files = [f for f in w.sim.window(m0) if f['kind'] == 'upload' and f.get('area') == 'secrets']
        tomb = [f for f in w.sim.children('secrets') if f['name'] in [t['name'] for t in tomb_files]]
        tomb_entry = json.loads(tomb[0]['content'])['entries'].get('["apiKey"]') if tomb else None
        rB, _ = w.run(B); b_cleared = B.ev("()=>SETTINGS.apiKey") == ''
        m1 = w.mark(); w.run(A); w.run(B); w.run(A); quiet = w.since(m1)['secretWrites']
        ok29a = had and a_cleared and rA['secret']['tombstonesCreated'] == 1 and tomb_entry == {'segs': ['apiKey'], 'deleted': True, 't': tomb_entry['t'], 'w': writer('devA')} and b_cleared and quiet == 0
        # 29D isolation (same run)
        canon = [f for f in w.sim.files.values() if w.sim._area(f) in ('objects', 'manifests')]
        leak29 = [where for where, hit in (('object/manifest', any(OLD.encode() in f['content'] for f in canon)), ('filename', any(OLD in f['name'] for f in w.sim.files.values())),
                                             ('tombstone', any(OLD.encode() in f['content'] for f in tomb)), ('report', OLD in json.dumps([rA, rB], ensure_ascii=False)),
                                             ('console', any(OLD in m for d in (A, B) for m in d.console)), ('status', OLD in json.dumps(A.ev("()=>lumosDriveSyncV136.p7StatusV402B()"), ensure_ascii=False)),
                                             ('local-config', OLD in A.ev("()=>localStorage.getItem('LUMOS_DRIVE_SYNC_V136_CONFIG')"))) if hit]
        ok29d = root0 == root1 and rA['result'] == 'SAME' and sA['bodyUploads'] == 0 and sA['manifestWrites'] == 0 and not leak29
        # 29B fresh device
        w2, A2, _B2 = pair(br, ST); LIVE = 'LIVE-FOR-FRESH-000202'
        A2.ev("(v)=>{SETTINGS.apiKey=v}", LIVE); w2.run(A2)
        fresh = json.loads(json.dumps(ST)); fresh['SETTINGS']['apiKey'] = ''
        C = w2.device('devC', seed=fresh); m2 = w2.mark(); _, rC = C.accept_first()
        c_snaps = [json.loads(f['content']) for f in w2.sim.children('secrets') if f['name'].startswith('s-' + writer('devC'))]
        ok29b = rC['ok'] and C.ev("()=>SETTINGS.apiKey") == LIVE and rC['secret']['tombstonesCreated'] == 0 and not any(e.get('deleted') for s in c_snaps for e in s['entries'].values())
        w2.run(A2); ok29b = ok29b and A2.ev("()=>SETTINGS.apiKey") == LIVE
        # 29C concurrent edit vs delete (+ equal-clock tie)
        w3, A3, B3 = pair(br, ST)
        A3.ev("()=>{SETTINGS.openaiApiKey='';}"); w3.run(A3)                              # older delete
        B3.ev("()=>{SETTINGS.openaiApiKey='sk-NEWER-LIVE-000203'}"); w3.run(B3); w3.run(A3); w3.run(B3)   # newer live
        c1 = A3.ev("()=>SETTINGS.openaiApiKey") == B3.ev("()=>SETTINGS.openaiApiKey") == 'sk-NEWER-LIVE-000203'
        A3.ev("()=>{SETTINGS.ollamaApiKey='ollama-OLDER-LIVE-000204'}"); w3.run(A3); w3.run(B3)   # older live, known on B
        B3.ev("()=>{SETTINGS.ollamaApiKey=''}"); w3.run(B3); w3.run(A3); w3.run(B3)            # newer delete
        c2 = A3.ev("()=>SETTINGS.ollamaApiKey") == B3.ev("()=>SETTINGS.ollamaApiKey") == ''
        A3.ev("()=>{SETTINGS.xaiApiKey='xai-K3-000205';SETTINGS.groqApiKey='groq-K4-OLD-000206'}"); w3.run(A3); w3.run(B3)
        sf = w3.sim.folder_ids('secrets')[0]; T3 = int(time.time() * 1000) + 10 ** 9
        for wid, ents in (('w0000000000000001', {'["xaiApiKey"]': {'segs': ['xaiApiKey'], 'value': 'xai-TIE-LIVE-000207', 'deleted': False, 't': T3, 'w': 'w0000000000000001'},
                                                  '["groqApiKey"]': {'segs': ['groqApiKey'], 'deleted': True, 't': T3, 'w': 'w0000000000000001'}}),
                          ('wfffffffffffffff', {'["xaiApiKey"]': {'segs': ['xaiApiKey'], 'deleted': True, 't': T3, 'w': 'wfffffffffffffff'},
                                                  '["groqApiKey"]': {'segs': ['groqApiKey'], 'value': 'groq-TIE-LIVE-000208', 't': T3, 'w': 'wfffffffffffffff'}})):
            w3.sim.add_file(f's-{wid}-0000000001.json', [sf], json.dumps({'format': 'lumos-p7-secret-snapshot', 'schemaVersion': 2, 'writer': wid, 'entries': ents}).encode())
        w3.run(A3); w3.run(B3); w3.run(A3)
        c3 = A3.ev("()=>[SETTINGS.xaiApiKey,SETTINGS.groqApiKey]") == ['', 'groq-TIE-LIVE-000208'] == B3.ev("()=>[SETTINGS.xaiApiKey,SETTINGS.groqApiKey]")
        m3 = w3.mark(); w3.run(A3); w3.run(B3); quiet3 = w3.since(m3)['secretWrites']
        ok29c = c1 and c2 and c3 and quiet3 == 0
        gate('H-P7B-29', 'secret deletion convergence', ok29a and ok29b and ok29c and ok29d,
             f"29A clear → A stays cleared in the same sync, value-free tombstone {tomb_entry and {k: tomb_entry[k] for k in ('segs', 'deleted')}}, B cleared, following syncs secretWrites={quiet} ; "
             f"29B fresh device adopts remote live value, tombstones emitted 0 ; 29C newer-live>older-delete={c1}, newer-delete>older-live={c2}, equal-clock writer tie (wfff… tombstone vs live, both directions)={c3}, then secretWrites={quiet3} ; "
             f"29D root unchanged={root0 == root1}, core {rA['result']} (P7 objects 0 / manifests 0), old value leaks={leak29} (objects, manifests, filenames, tombstone, reports, console, status, local config)")
        SEC29 = {'29A': ok29a, '29B': ok29b, '29C': {'newer_live': c1, 'newer_delete': c2, 'tie': c3, 'quiet': quiet3}, '29D': {'leaks': leak29}}

        # ---- H30 extension owner composition ----
        w, A, B = pair(br, ST); A.stub_extension('ok'); B.stub_extension('ok')
        msync = lambda d: d.ev("async()=>{const ok=await lumosDriveSyncV136.sync();return {ok,m:lumosDriveSyncV136.p7StatusV402B().lastManualSync}}")
        a30 = msync(A); c30a = len(A.ext_calls())
        ok30a = a30['ok'] is True and c30a == 1 and a30['m']['status'] == 'success' and a30['m']['core']['result'] == 'SAME' and json.loads(A.ext_calls()[0]) == {'quiet': True, 'integrated': True}
        A.ev("()=>__P7T.edit('nov-033',' ext')"); b1 = msync(A); b2 = msync(B)
        ok30b = b1['ok'] and b1['m']['core']['result'] == 'SYNCED' and len(A.ext_calls()) == 2 and b2['ok'] and b2['m']['core']['result'] == 'SYNCED' and len(B.ext_calls()) == 1
        A.stub_extension('real'); m0 = w.mark(); real = msync(A); real_files = [e['name'] for e in w.sim.window(m0) if e['kind'] == 'upload' and e.get('area') not in ('objects', 'manifests', 'secrets')]
        ok30b = ok30b and real['ok'] and len(A.ext_calls()) == 3
        A.stub_extension('ok'); nC = len(A.ext_calls()); fails = []
        w.sim.fail_rules.append(lambda info, body: (fails.append(1) or 500) if (info['device'] == 'devA' and info['method'] == 'GET' and info['path'] == '/drive/v3/files') else None)
        c30 = msync(A); w.sim.fail_rules.clear()
        ok30c = c30['ok'] is False and len(A.ext_calls()) == nC and c30['m']['status'] == 'core-failed' and c30['m']['extension']['called'] == 0
        A.stub_extension('fail'); A.ev("()=>__P7T.edit('nov-034',' extfail')"); m1 = w.mark(); d30 = msync(A); sd = w.since(m1, A)
        head_after, _, _ = head_manifest(w.sim)
        A.stub_extension('ok'); m2 = w.mark(); d31 = msync(A); sd2 = w.since(m2, A)
        ok30d = (d30['ok'] is False and d30['m']['status'] == 'extension-failed' and d30['m']['result'] == 'EXTENSION_FAILED' and d30['m']['core']['ok'] is True and 'synthetic extension failure' in (d30['m']['extension']['error'] or '')
                 and sd['manifestWrites'] >= 1 and head_after['canonicalRootHash'] == A.ev("()=>__P7T.root()") and d31['ok'] and d31['m']['core']['result'] == 'SAME' and sd2['manifestWrites'] == 0 and sd2['bodyUploads'] == 0)
        # 30E pre-migration legacy Manual Sync: owner call count identical to the R4 parent, no double call
        legacy_calls = {}
        for label, html, nm in (('parent', PARENT, 'devLegP'), ('candidate', CAND, 'devLeg')):
            wl = World(br); dl = Device(br, nm, {'sim': wl.sim}, html, page_errors=ERRORS); DEVICES.append(dl); wl.devices.append(dl); dl.seed(ST); dl.stub_extension('ok')
            okl = dl.ev("async()=>await lumosDriveSyncV136.sync()"); okl2 = dl.ev("async()=>await lumosDriveSyncV136.sync()")
            legacy_calls[label] = {'ok': [okl, okl2], 'calls': len(dl.ext_calls()), 'v7Active': html == CAND and dl.ev("()=>lumosDriveSyncV136.p7StatusV402B().active")}
        ok30e = legacy_calls['parent']['calls'] == legacy_calls['candidate']['calls'] and legacy_calls['candidate']['calls'] <= 2 and legacy_calls['parent']['ok'] == legacy_calls['candidate']['ok'] and legacy_calls['candidate']['v7Active'] is False
        # 30F no Risu plugin bodies in the P7 store
        plugin_objs = [f['name'] for s in SIMS for f in s.files.values() if s._area(f) == 'manifests' and b'extension.risuPlugin' in f['content']]
        plugin_bytes = [f['name'] for s in SIMS for f in s.files.values() if s._area(f) == 'objects' and (b'risuPlugin' in f['content'] or b'"plugins"' in f['content'])]
        ok30f = not plugin_objs and not plugin_bytes and not any(n.startswith('o-') for n in real_files)
        gate('H-P7B-30', 'extension owner composition', ok30a and ok30b and ok30c and ok30d and ok30e and ok30f,
             f"30A core SAME → owner upload({{quiet,integrated}}) ×{c30a}, overall success ; 30B upload/download success → ×1 each (real v245 owner run ok={real['ok']}, wrote {sorted(set(real_files))} outside P7 folders) ; "
             f"30C core failure → owner ×0, overall false ; 30D owner failure → overall false, status extension-failed, core committed once (manifest {sd['manifestWrites']}) and next run SAME with 0 manifest/body writes ; "
             f"30E pre-migration legacy Manual Sync owner calls parent={legacy_calls['parent']['calls']} candidate={legacy_calls['candidate']['calls']} (identical, v7 inactive) ; 30F risuPlugin objects/bytes in P7 store = {len(plugin_objs) + len(plugin_bytes)}")
        EXT30 = {'30A_calls': c30a, 'legacy': legacy_calls, 'real_owner_files': sorted(set(real_files)), '30D': d30['m']}

        # ---- H31 R5 canonical integration ----
        R5_INC = ['eilV390', 'englishProcessingV250', 'imageStudioRecord', 'inlayNexusV159', 'novelBranchTombstonesV229', 'novelTurnCounterV216', 'risuScriptPacksV152']
        R5_EXC = ['baseLanguageModeConfirmedAtV253', 'baseLanguageModeSourceV253', 'branchHistoryUpdatedAtV229', 'lastMessage', 'longMemoryBaselineStatusV111', 'longMemoryLastWriteV110',
                  'sceneAssistLastStabilityReport', 'sceneAssistSchemaVersion', 'sourceHashV128']
        blk_txt = BLOCK.read_text('utf-8')
        shadow = [k for k in R5_INC + R5_EXC if k in blk_txt] + [t for t in ('CHAT_INCLUDE_KEYS', 'CHAT_EXCLUDE_KEYS', 'CHAT_DERIVED_EXCLUDE_KEYS', 'isNovelSyncVolatileKey') if t in blk_txt]
        extract_calls = re.findall(r'extractCanonical\(([^)]*)\)', blk_txt)
        ST16 = json.loads(json.dumps(ST))
        for i, c in enumerate(ST16['DB']['chats'][:12]):
            c.update({'eilV390': {'beliefs': [{'id': f'b{i}', 'p': 0.7}]}, 'englishProcessingV250': {'enabled': i % 2 == 0}, 'imageStudioRecord': {'items': [{'id': f'img-{i}'}]},
                      'inlayNexusV159': {'nodes': [f'n{i}']}, 'novelBranchTombstonesV229': [{'id': f'br-{i}', 'deletedAt': 1}], 'novelTurnCounterV216': 10 + i, 'risuScriptPacksV152': [{'id': 'pack-1', 'on': True}],
                      'baseLanguageModeConfirmedAtV253': 1790000000000 + i, 'baseLanguageModeSourceV253': 'user', 'branchHistoryUpdatedAtV229': 1790000000000 + i, 'lastMessage': f'미리보기 {i}',
                      'longMemoryBaselineStatusV111': {'state': 'done'}, 'longMemoryLastWriteV110': {'ok': True}, 'sceneAssistLastStabilityReport': {'score': 0.9}, 'sceneAssistSchemaVersion': 2, 'sourceHashV128': f'h{i}'})
        w = World(br); Rd = w.device('devR5', seed=ST16)
        probe = Rd.ev("""([INC,EXC])=>{const A=window.LumosP7CanonicalV401A;const ex=A.extractCanonical({DB,SETTINGS});const n=ex.canonical.novels[DB.chats[0].novelId];
          return{inc:INC.filter(k=>k in n),exc:EXC.filter(k=>k in n),excReported:EXC.filter(k=>ex.report.excluded.some(e=>e.path.endsWith('.'+k)&&/R5/.test(e.why))),
            chatUnclassified:ex.report.unclassified.filter(p=>p.startsWith('chat.')),dbUnclassified:ex.report.unclassified.filter(p=>p.startsWith('DB.')),
            root:A.buildRootFingerprint(ex.canonical),objects:A.buildObjectFingerprints(ex.canonical).map(e=>[e.domain,e.id,e.hash,e.size])}}""", [R5_INC, R5_EXC])
        plan31 = Rd.preview()
        _, r31 = Rd.accept_first(); man31, _, _ = head_manifest(w.sim)
        post = Rd.ev("()=>{const A=window.LumosP7CanonicalV401A;const ex=A.extractCanonical({DB,SETTINGS});return{root:A.buildRootFingerprint(ex.canonical),objects:A.buildObjectFingerprints(ex.canonical).map(e=>[e.domain,e.id,e.hash,e.size])}}")
        Rd.ev("()=>{const c=DB.chats[0];c.lastMessage='바뀐 미리보기';c.sourceHashV128='changed';c.longMemoryLastWriteV110={ok:false};c.baseLanguageModeConfirmedAtV253=1}")
        r31x, s31x = w.run(Rd)
        nid0 = Rd.ev("()=>DB.chats[0].novelId"); Rd.ev("()=>{DB.chats[0].novelTurnCounterV216+=1}")
        r31i, s31i = w.run(Rd)
        ok31 = (prot['lumos-p7-canonical-state-v401a'] == R5_P7A_BODY_SHA and not shadow and probe['inc'] == R5_INC and probe['exc'] == [] and probe['excReported'] == R5_EXC
                and probe['chatUnclassified'] == [] and probe['dbUnclassified'] == [] and plan31['unclassified'] == [] and plan31['localRoot'] == probe['root'] and plan31['proposedRoot'] == probe['root']
                and r31['ok'] and man31['canonicalRootHash'] == post['root'] and [[e['domain'], e['id'], e['hash'], e['size']] for e in man31['objects']] == post['objects']
                and r31x['result'] == 'SAME' and s31x['bodyUploads'] == 0 and s31x['manifestWrites'] == 0
                and r31i['ok'] and [u['id'] for u in r31i['uploads']] == [nid0] and s31i['bodyUploads'] == 1)
        gate('H-P7B-31', 'R5 canonical integration', ok31,
             f"P7-A body = R5 {prot['lumos-p7-canonical-state-v401a'][:12]}… ; real-profile-shaped fixture (16 R5 fields on 12 chats): 7 INCLUDE in canonical, 9 EXCLUDE absent + reported excluded (R5), chat unclassified={probe['chatUnclassified']} DB unclassified={probe['dbUnclassified']} ; "
             f"dry-run plan unclassified={plan31['unclassified']}, plan.localRoot == plan.proposedRoot == P7-A root ; rev1 manifest objects/root == P7-A fingerprints exactly ; EXCLUDE-only edits → {r31x['result']} (bodies {s31x['bodyUploads']}, manifests {s31x['manifestWrites']}) ; "
             f"INCLUDE edit (novelTurnCounterV216) → uploads {[u['id'] for u in r31i['uploads']]} ; v136 shadow-filter tokens (16 field names / classification sets) = {len(shadow)} ; v136 extractCanonical call sites = {len(extract_calls)} (inputs {{DB,SETTINGS}} or legacy payload only)")
        R5INT = {'probe': {k: v for k, v in probe.items() if k != 'objects'}, 'plan_unclassified': plan31['unclassified'], 'shadow_tokens': shadow, 'extract_call_args': extract_calls,
                 'exclude_only': {'result': r31x['result'], **{k: s31x[k] for k in ('bodyUploads', 'manifestWrites')}}, 'include_edit_uploads': [u['id'] for u in r31i['uploads']]}

        # ---- H32 release identity ----
        v379_diff = [l for l in difflib.unified_diff(v379p.decode('utf-8').split('\n'), v379c.decode('utf-8').split('\n'), n=0, lineterm='') if l[:1] in '+-' and not l.startswith(('+++', '---'))]
        hist_ok = all(any(s['id'] == hid for s in cs) for hid in ('lumos-v390-eil-core', 'lumos-v390-release-marker', 'lumos-v161-storage-script', 'lumos-v391-operations-panel-script')) and b'LumosExtensionSyncV245' in cand
        ident = Rd.ev("""async()=>{const g=()=>({title:document.title,meta:(document.querySelector('meta[name="lumos-build"]')||{}).content,badge:(document.getElementById('lumos-visible-version')||{}).textContent,
            patch:window.LUMOS_PATCH_VERSION,patch2:window.__LUMOS_PATCH_VERSION__,build:window.LUMOS_BUILD_LABEL,data:document.documentElement.dataset.lumosVersion});
          const a=g();document.title='tamper';const m=document.querySelector('meta[name="lumos-build"]');if(m)m.content='tamper';await new Promise(r=>setTimeout(r,150));return{a,b:g()}}""")
        wp = World(br); Pd = Device(br, 'devPar', {'sim': wp.sim}, PARENT, page_errors=ERRORS); DEVICES.append(Pd); wp.devices.append(Pd)
        par_ident = Pd.ev("()=>({title:document.title,badge:(document.getElementById('lumos-visible-version')||{}).textContent,patch:window.LUMOS_PATCH_VERSION})")
        want = {'title': REL['TITLE'], 'meta': REL['BUILD'], 'badge': REL['VERSION'], 'patch': REL['VERSION'], 'patch2': REL['VERSION'], 'build': REL['BUILD'], 'data': REL['VERSION']}
        ok32 = (ident['a'] == want and ident['b'] == want and len(v379_diff) == 2 and v379_diff[0].startswith("-      const VERSION='v390 R12'") and v379_diff[1].startswith("+      const VERSION='v402 R4'")
                and ns_ok and hist_ok and par_ident['patch'] == 'v390 R12')
        gate('H-P7B-32', 'global release identity', ok32,
             f"loaded app: title/meta/badge/LUMOS_PATCH_VERSION/__LUMOS_PATCH_VERSION__/LUMOS_BUILD_LABEL/data-lumos-version = v402 R4 identity (re-asserted after tamper) ; parent shows {par_ident['patch']} (control) ; "
             f"v379 change = 1 constant line ; document change = <title> + <meta lumos-build> only ; historical component ids (lumos-v390-eil-core, lumos-v390-release-marker, v161, v391, LumosExtensionSyncV245) unchanged")
        REL32 = {'loaded': ident, 'parent': par_ident, 'v379_diff': v379_diff}

        # ---- H23 / H25 / H26 / H24 / H27 ----
        gate('H-P7B-23', 'transfer metrics', len(TRUTH) >= 20 and all(t['ok'] for t in TRUTH),
             f"{sum(t['ok'] for t in TRUTH)}/{len(TRUTH)} sync runs: planned object count/bytes == DriveSim-measured body uploads/downloads (manifest bytes counted separately)")
        w, A, B = pair(br, ST)
        A.ev("()=>__P7T.edit('nov-012',' net')"); w.run(A)
        once = []
        w.sim.fail_rules.append(lambda info, body: (once.append(1) or 503) if (not once and info['device'] == 'devB' and info['kind'] == 'other' and info['method'] == 'GET' and '/drive/v3/files/' in info['path']) else None)
        sB0 = B.ev("()=>__P7T.snap()"); r26, _ = w.run(B); sB1 = B.ev("()=>__P7T.snap()"); w.sim.fail_rules.clear()
        gate('H-P7B-26', 'failed attempt no local half-apply', r26['ok'] is False and sB0 == sB1 and before == after and A.ev("()=>__P7T.root()") != B.ev("()=>__P7T.root()"),
             f"network 503 during body download → {r26['result']}, DB/SETTINGS byte-identical ; tampered body (H-P7B-11) → INVALID_REMOTE, byte-identical ; crash before manifest (H-P7B-13) → local root unchanged")
        exp = {'SAME': 'idle>inspecting>same>success', 'upload-one': 'idle>inspecting>uploading>validating>success', 'download-one': 'idle>inspecting>downloading>validating>success',
               'fork': 'idle>inspecting>fork-required>downloading>uploading>validating>settling>inspecting>uploading>validating>success', 'stale-retry': 'idle>inspecting>uploading>retryable>inspecting>downloading>uploading>validating>success'}
        got = {k: '>'.join(TRAILS.get(k) or []) for k in exp}
        gate('H-P7B-25', 'status machine', got == exp, ' | '.join(f'{k}: {v}' for k, v in got.items()))
        dels = sum(DriveSim.summarize(s.log)['deletes'] for s in SIMS)
        V6 = ('lumos-settings.json', 'lumos-novels.json', 'lumos-novels-backup.json')
        v7_legacy_writes = sum(1 for s in SIMS for e in s.log if e['device'] not in LEGACY_DEVICES and ((e['kind'] == 'patch' and e.get('name') in V6) or (e['kind'] == 'upload' and e.get('name') in V6)))
        gate('H-P7B-24', 'no GC / legacy preservation', dels == 0 and v7_legacy_writes == 0 and legacy == legacy2,
             f'DELETE/trash calls across all {len(SIMS)} synthetic Drives = {dels} ; v7 writes to legacy v6 files = {v7_legacy_writes} ; legacy bytes unchanged through migration')
        paths = set()
        for s in SIMS:
            for e in s.log:
                p = e['path']; paths.add(re.sub(r'/files/[^/]+$', '/files/{id}', p))
        allowed = {'/drive/v3/files', '/drive/v3/files/{id}', '/upload/drive/v3/files', '/upload/drive/v3/files/{id}'}
        others = sorted({u for d in DEVICES for u in d.net_other})
        cdn = [u for u in others if not any(h in u for h in ('cdn.tailwindcss.com', 'cdn.jsdelivr.net', 'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com'))]
        urls_in_block = re.findall(r'https?://', blk)
        relay_up = sorted({re.sub(r'\?.*$', '', re.sub(r'/files/[^/?]+', '/files/{id}', r['url'])) for d in DEVICES for r in d.holder['relay']})
        relay_ok = all(u.startswith('https://www.googleapis.com/') for u in relay_up) and all(r['proxy_token_ok'] for d in DEVICES for r in d.holder['relay'])
        gate('H-P7B-27', 'real Drive request shape / allowlist', paths <= allowed and not cdn and not urls_in_block and relay_ok,
             f'googleapis paths used (direct + relayed) = {sorted(paths)} (⊆ Drive v3 files + upload) ; relay upstreams = {relay_up} (existing Universal Relay endpoint only) ; other attempted requests = pre-existing app-shell CDN tags only ({len(others)}) ; URL literals in v7 block = {len(urls_in_block)} (uses existing API_ROOT/UPLOAD_ROOT + driveFetch/LumosUniversalRelay106)')

        # ======================= R4 file-origin write transport gates (H-P7B-33..38) =======================
        TOKEN = 'SYN-ACCESS-TOKEN-NOT-REAL'
        P7_FOLDER_NAMES = {'lumos-p7-manifests', 'lumos-p7-objects', 'lumos-p7-secrets'}
        def p7_write(e):
            return e['method'] != 'GET' and e['device'] not in LEGACY_DEVICES and (
                (e['kind'] == 'upload' and e.get('area') in ('objects', 'manifests', 'secrets'))
                or (e['kind'] == 'create-meta' and e.get('name') in P7_FOLDER_NAMES | {'Rumos'}))
        def relay_recs(*devs): return [r for d in devs for r in d.holder['relay']]
        SPY = """()=>{const R=window.LumosUniversalRelay106;if(R.__spyP7T)return;const orig=R.fetch;window.__relaySpy=[];
          R.fetch=async function(u,o,ro){const b=o&&o.body;window.__relaySpy.push({url:String(u).replace(/\\?.*$/,''),bodyType:b===undefined?'none':(typeof FormData!=='undefined'&&b instanceof FormData)?'FormData':(b instanceof Blob)?'Blob':typeof b,
            ct:String((o&&o.headers&&(o.headers['Content-Type']||o.headers['content-type']))||'')});return orig.call(this,u,o,ro)};R.__spyP7T=true}"""
        def multipart_check(rec):
            """strict decode of one relayed Drive multipart/related request; returns (meta, content bytes, problems)"""
            import email.parser, email.policy
            ct = rec['headers'].get('content-type', ''); probs = []
            m = re.fullmatch(r'multipart/related; boundary=(lumos_p7_[0-9a-f]{36})', ct)
            if not m: return None, None, ['content-type ' + ct]
            bnd = m.group(1).encode(); body = rec['body']
            hdr = b'Content-Type: application/json; charset=UTF-8\r\n\r\n'
            if not body.startswith(b'--' + bnd + b'\r\n' + hdr): probs.append('part1 framing')
            if not body.endswith(b'\r\n--' + bnd + b'--'): probs.append('closing boundary')
            if body.count(b'--' + bnd) != 3: probs.append('boundary count')
            inner = body[len(b'--' + bnd + b'\r\n' + hdr):-len(b'\r\n--' + bnd + b'--')]
            sep = b'\r\n--' + bnd + b'\r\n' + hdr
            if inner.count(sep) != 1: probs.append('part separator'); return None, None, probs
            meta_b, content = inner.split(sep)
            msg = email.parser.BytesParser(policy=email.policy.HTTP).parsebytes(b'Content-Type: ' + ct.encode() + b'\r\n\r\n' + body)
            parts = list(msg.iter_parts())
            if len(parts) != 2 or parts[1].get_payload(decode=True) != content: probs.append('mime parser disagrees')
            return json.loads(meta_b.decode('utf-8')), content, probs

        R4EVIDENCE = {}
        PROBE38 = []
        def probe38(d):
            PROBE38.append({'device': d.name, **d.ev("""(T)=>{const out=[];const ls={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);ls[k]=localStorage.getItem(k)}
              const st=lumosDriveSyncV136.p7StatusV402B();
              if(JSON.stringify(ls).includes(T))out.push('localStorage');if(JSON.stringify(st).includes(T))out.push('p7Status/report/trail');
              if(JSON.stringify([DB,SETTINGS]).includes(T))out.push('DB/SETTINGS');if(document.body.innerText.includes(T)||document.body.innerHTML.includes(T))out.push('DOM (incl. Provider Core monitor)');
              if(JSON.stringify(window.LumosProviderCore134.getLogs()).includes(T))out.push('Provider Core logs');
              const A=window.LumosP7CanonicalV401A;if(A.canonicalJSON(A.extractCanonical({DB,SETTINGS}).canonical).includes(T))out.push('canonical');
              return{leaks:out,relayRuntime:SETTINGS.universalRelayLastRuntimeV106||null,monitorLogs:window.LumosProviderCore134.getLogs().length}}""", TOKEN)})
        SNAP_STEADY = "()=>{const s=JSON.parse(JSON.stringify(SETTINGS));delete s.universalRelayLastRuntimeV106;return JSON.stringify([DB,s])}"

        # ---- H33 file-origin transport selection ----
        p7w = [e for s in SIMS for e in s.log if p7_write(e)]
        direct_p7 = [e for e in p7w if e.get('via') != 'relay']
        reads_direct = sum(1 for s in SIMS for e in s.log if e['method'] == 'GET' and e.get('via') == 'direct')
        reads_relay = sum(1 for s in SIMS for e in s.log if e['method'] == 'GET' and e.get('via') == 'relay')
        w = World(br); X = w.device('devX', seed=ST); X.ev("()=>{delete window.LumosUniversalRelay106}")
        snapX = X.ev("()=>__P7T.snap()"); planX = X.preview(); m0 = w.mark(); rX = X.sync(acceptPlanId=planX['planId'], acceptUnclassified=True, acknowledgeSecretDisclosure=True); sX = w.since(m0, X)
        stX = X.ev("()=>lumosDriveSyncV136.p7StatusV402B()")
        okX = rX['result'] == 'TRANSPORT_UNAVAILABLE' and sX['requests'] == 0 and planX['transport'] == {'origin': 'file', 'write': 'relay', 'relayAvailable': False, 'ready': False} and stX['migrated'] is False and stX['base'] is None and X.ev("()=>__P7T.snap()") == snapX
        w = World(br); Hd = w.device('devHttp', seed=ST, http_origin=True); m0 = w.mark(); planH, rH = Hd.accept_first(); sH = w.since(m0, Hd)
        okH = Hd.ev("()=>location.protocol") == 'http:' and planH['transport']['write'] == 'direct' and rH['result'] == 'MIGRATED' and sH['relayWrites'] == 0 and sH['directWrites'] > 0 and not Hd.holder['relay']
        # Provider Core (v134) normalizes SETTINGS.providerCoreV134 (canonical) on its first monitored call: a profile loaded after boot
        # leaves it un-normalized, so the first relay write would move the canonical root mid-sync unless primed before local state is read
        w = World(br); Y = w.device('devPrime', seed=ST); Y.ev("()=>{SETTINGS.providerCoreV134={routing:'auto'}}")
        pc0 = Y.ev("()=>Object.keys(SETTINGS.providerCoreV134).sort()"); _, rY = Y.accept_first(); manY, _, _ = head_manifest(w.sim)
        okY = pc0 == ['routing'] and rY['result'] == 'MIGRATED' and manY is not None and manY['canonicalRootHash'] == Y.ev("()=>__P7T.root()") and 'retryEnabled' in Y.ev("()=>SETTINGS.providerCoreV134")
        ok33 = len(p7w) > 500 and not direct_p7 and reads_direct > 0 and reads_relay == 0 and okX and okH and okY
        gate('H-P7B-33', 'file-origin transport selection', ok33,
             f"file:// (origin null) across every scenario of this run: P7 writes via Universal Relay = {len(p7w)}, direct Google P7 write fetches = {len(direct_p7)} ; P7 reads/lists direct = {reads_direct} (relayed reads {reads_relay}) ; "
             f"relay absent → {rX['result']} before any Drive request (requests {sX['requests']}), migrated/base unchanged, local byte-identical ; http(s) origin control → {rH['result']} via R3 direct path (relay writes {sH['relayWrites']}, direct writes {sH['directWrites']}) ; un-normalized providerCoreV134 {pc0} primed before local read → {rY['result']}, head root == local root")
        R4EVIDENCE['H33'] = {'p7_relay_writes': len(p7w), 'p7_direct_writes': len(direct_p7), 'reads_direct': reads_direct, 'relay_missing': {'result': rX['result'], 'error': rX.get('error'), 'requests': sX['requests'], 'plan_transport': planX['transport']},
                             'http_origin': {'result': rH['result'], 'transport': rH.get('transport'), 'relayWrites': sH['relayWrites'], 'directWrites': sH['directWrites']}}

        # ---- H34 relayed folder creation (fresh Drive) + reuse of R3-attempt folders ----
        w = World(br); F = w.device('devF', seed=ST); F.ev(SPY); m0 = w.mark(); planF, rF = F.accept_first(); winF = w.sim.window(m0)
        cm = [e for e in winF if e['kind'] == 'create-meta']
        root_e = [e for e in cm if e['name'] == 'Rumos']; sub_e = [e for e in cm if e['name'] in P7_FOLDER_NAMES]
        root_id = next((f['id'] for f in w.sim.files.values() if f['name'] == 'Rumos'), None)
        FM = 'application/vnd.google-apps.folder'
        meta_ok = (len(root_e) == 1 and root_e[0]['meta'] == {'name': 'Rumos', 'mimeType': FM, 'parents': ['root'], 'appProperties': {'lumos': 'drive-sync-v136'}}
                   and sorted(e['name'] for e in sub_e) == sorted(P7_FOLDER_NAMES)
                   and all(e['meta'] == {'name': e['name'], 'mimeType': FM, 'parents': [root_id], 'appProperties': {'lumos': 'p7-v402b', 'kind': e['name'].replace('lumos-p7-', '')}} for e in sub_e))
        via_ok = all(e['via'] == 'relay' for e in cm) and len(cm) == 4
        cfg_root = F.ev("()=>JSON.parse(localStorage.getItem('LUMOS_DRIVE_SYNC_V136_CONFIG')||'{}').folderId")
        G2 = w.device('devG', seed=ST); m1 = w.mark(); _, rG = G2.accept_first(); cmG = [e for e in w.sim.window(m1) if e['kind'] == 'create-meta']
        # ---- H35 multipart/related exactness (decoded from the relay fixture) ----
        recsF = [r for r in F.holder['relay'] if '/upload/drive/v3/files' in r['url']]
        bad35, korean, kinds, checked = [], 0, {}, 0
        uploadsF = [e for e in winF if e['kind'] == 'upload']
        by_name = {}
        for f in w.sim.files.values(): by_name.setdefault(f['name'], f)
        for rec, ent in zip(recsF, uploadsF):
            meta, content, probs = multipart_check(rec)
            if probs: bad35.append(probs); continue
            f = by_name.get(meta['name'])
            exp_props = {'objects': {'lumos': 'p7-v402b-object'}, 'secrets': {'lumos': 'p7-v402b-secrets'}}.get(ent['area'])
            if ent['area'] == 'manifests': exp_props = {'lumos': 'p7-v402b-manifest', 'revision': str(int(meta['name'][:10]))}
            if not (f and meta == {'name': f['name'], 'mimeType': 'application/json', 'parents': [f['parents'][0]], 'appProperties': exp_props} and f['parents'][0] in w.sim.folder_ids(ent['area'])
                    and meta['name'] == ent['name'] and content == f['content'] and rec['encoding'] == 'text' and rec['envelope_keys'] == ['bodyText', 'headers', 'method', 'url']
                    and rec['method'] == 'POST' and rec['url'].startswith('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart')):
                bad35.append(['meta/content', meta.get('name')]); continue
            if ent['area'] == 'objects':
                h = re.fullmatch(r'o-[0-9a-f]{32}-([0-9a-f]{64})\.json', meta['name']).group(1)
                if sha(content) != h: bad35.append(['hash', meta['name']])
            json.loads(content.decode('utf-8'))
            if re.search('[가-힣]', content.decode('utf-8')): korean += 1
            kinds[ent['area']] = kinds.get(ent['area'], 0) + 1; checked += 1
        man, _, _ = head_manifest(w.sim); sizes_ok = all(len(by_name['o-' + sha((e['domain'] + '\u0000' + e['id']).encode())[:32] + '-' + e['hash'] + '.json']['content']) == e['size'] for e in man['objects'])
        spy = F.ev("()=>window.__relaySpy")
        spy_types = sorted({s['bodyType'] for s in spy}); spy_ct = sorted({s['ct'].split(';')[0] for s in spy})
        # unit: builder with adversarial content (Korean, emoji, CRLF, boundary-looking text, quotes, NUL-free control chars)
        tricky = '{"t":"이야기 ✨ 👩‍👩‍👧 \\r\\n--lumos_p7_00 \\"q\\" é́ 中文","n":1}'
        meta_u = {'name': 'o-x.json', 'mimeType': 'application/json', 'parents': ['fid-한글'], 'appProperties': {'lumos': 'p7-v402b-object', 'note': '값'}}
        mp = F.ev("([m,x])=>lumosDriveSyncV136._p7TestV402B.multipart(m,x)", [meta_u, tricky])
        mu, cu, pu = multipart_check({'headers': {'content-type': mp['contentType']}, 'body': mp['body'].encode('utf-8')})
        unit_ok = not pu and mu == meta_u and cu == tricky.encode('utf-8')
        probe38(F)
        ok35 = checked == len(uploadsF) == len(recsF) and checked > 100 and not bad35 and korean > 0 and kinds.get('manifests', 0) >= 1 and kinds.get('secrets', 0) == 1 and sizes_ok and spy_types == ['string'] and spy_ct == ['application/json', 'multipart/related'] and unit_ok
        gate('H-P7B-35', 'multipart/related exactness', ok35,
             f"{checked}/{len(uploadsF)} relayed uploads decoded byte-exactly from the relay envelope (objects {kinds.get('objects', 0)}, manifests {kinds.get('manifests', 0)}, secrets {kinds.get('secrets', 0)}) : "
             f"metadata JSON / parent folder / appProperties / file name exact ; content bytes == stored Drive bytes, object SHA-256 == content-addressed name, sizes == manifest ; Korean content parts {korean} intact ; "
             f"relay body types seen by LumosUniversalRelay106.fetch = {spy_types} (no FormData/Blob) ; envelope = bodyText ; builder unit (Korean/emoji/CRLF/boundary-like text) exact={unit_ok} ; problems={bad35[:3]}")
        R4EVIDENCE['H35'] = {'checked': checked, 'kinds': kinds, 'korean_parts': korean, 'spy_body_types': spy_types, 'spy_content_types': spy_ct, 'unit_exact': unit_ok, 'problems': bad35[:10]}

        # (34B runs after H35 because opening a new World closes devF)
        # 34B: Drive left behind by the failed R3 live attempt (root + P7 folders + one uncertain content-addressed object)
        w2 = World(br); sim = w2.sim
        rid = sim.add_file('Rumos', ['root'], b'', FM, {'lumos': 'drive-sync-v136'})
        fids = {k: sim.add_file(f'lumos-p7-{k}', [rid], b'', FM, {'lumos': 'p7-v402b', 'kind': k}) for k in ('manifests', 'objects', 'secrets')}
        K = w2.device('devK', seed=ST)
        stray = K.ev("""()=>{const A=window.LumosP7CanonicalV401A,ex=A.extractCanonical({DB,SETTINGS}),e=A.buildObjectFingerprints(ex.canonical).find(x=>x.domain==='novel');
          return{name:lumosDriveSyncV136._p7TestV402B.objectName(e),text:A.canonicalJSON(ex.canonical.novels[e.id]),hash:e.hash,size:e.size}}""")
        sb = stray['text'].encode('utf-8'); assert sha(sb) == stray['hash'] and len(sb) == stray['size']
        sim.add_file(stray['name'], [fids['objects']], sb, 'application/json', {'lumos': 'p7-v402b-object'})
        m2 = w2.mark(); planK, rK = K.accept_first(); sK = w2.since(m2, K)
        up_names = [e['name'] for e in w2.sim.window(m2) if e['kind'] == 'upload']
        manK, _, _ = head_manifest(w2.sim)
        okK = (rK['result'] == 'MIGRATED' and sK['folderCreates'] == 0 and stray['name'] not in up_names and sK['deletes'] == 0 and manK is not None and planK['uploadCount'] == len(manK['objects']) - 1
               and len([f for f in sim.files.values() if f['mimeType'] == FM]) == 4 and sK['directWrites'] == 0)
        ok34 = rF['result'] == 'MIGRATED' and meta_ok and via_ok and rF['metrics']['folderCreates'] == 3 and cfg_root == root_id and rG['ok'] and not cmG and okK
        gate('H-P7B-34', 'relayed folder creation', ok34,
             f"fresh Drive: Rumos root + 3 P7 folders created through the relay write transport ({len(cm)} creates, direct 0) ; metadata exact (root parents=['root'] appProperties lumos=drive-sync-v136 ; P7 folders parents=[root] appProperties lumos=p7-v402b/kind) ; "
             f"metrics.folderCreates={rF['metrics']['folderCreates']} (+ root) ; config.folderId = created root ; 2nd device joins → folder creates {len(cmG)} ; "
             f"R3-failed-attempt Drive (existing root + P7 folders + 1 uncertain object) → {rK['result']}, folder creates {sK['folderCreates']}, existing object reused (not re-uploaded), deletes {sK['deletes']}, no manual cleanup")
        R4EVIDENCE['H34'] = {'creates': [{'name': e['name'], 'via': e['via'], 'meta': e['meta']} for e in cm], 'metrics': rF['metrics'], 'join_creates': len(cmG),
                             'r3_attempt_drive': {'result': rK['result'], 'folderCreates': sK['folderCreates'], 'uploads': sK['bodyUploads'], 'planned': planK['uploadCount'], 'stray_reused': stray['name'] not in up_names}}

        # ---- H36 object / manifest / secret write routing ----
        w = World(br); A6 = w.device('devA', seed=ST); B6 = w.device('devB', seed=ST)
        m0 = w.mark(); _, ra6 = A6.accept_first(ack_secret=True); sa = w.since(m0, A6)
        m1 = w.mark(); _, rb6 = B6.accept_first(ack_secret=False, disable_secret=True); sb6 = w.since(m1, B6)
        A6.ev("()=>__P7T.edit('nov-007',' 라우팅')"); m2 = w.mark(); r36, s36 = w.run(A6); win2 = w.sim.window(m2)
        B6.ev("()=>{SETTINGS.apiKey='AIzaSy-B-ONLY-000361'}"); m3 = w.mark(); rb36, sb36 = w.run(B6)
        def areas(win, dev): return sorted({(e['area'], e['via']) for e in win if e['kind'] == 'upload' and e['device'] == dev})
        okA = sa['bodyUploads'] > 0 and sa['manifestWrites'] >= 1 and sa['secretWrites'] == 1 and sa['directWrites'] == 0 and areas(w.sim.window(m0), 'devA') == [('manifests', 'relay'), ('objects', 'relay'), ('secrets', 'relay')]
        okB = rb6['ok'] and sb6['secretWrites'] == 0 and sb6['directWrites'] == 0 and B6.ev("()=>lumosDriveSyncV136.p7StatusV402B().secret.enabled") is False and sb36['secretWrites'] == 0 and rb36['ok'] and sb36['bodyUploads'] == 0
        okE = s36['bodyUploads'] == 1 and s36['manifestWrites'] == 1 and areas(win2, 'devA') == [('manifests', 'relay'), ('objects', 'relay')] and s36['directWrites'] == 0
        gate('H-P7B-36', 'object/manifest/secret write routing', okA and okB and okE,
             f"file origin, secret sync acknowledged: objects {sa['bodyUploads']} + manifests {sa['manifestWrites']} + secret snapshot {sa['secretWrites']} all via relay (direct 0) ; "
             f"disableSecretSync:true device: secret writes {sb6['secretWrites']} at migration and {sb36['secretWrites']} after a provider-key edit (core {rb36['result']}) ; one-object edit → 1 object + 1 manifest via relay")
        probe38(A6); probe38(B6)
        R4EVIDENCE['H36'] = {'secret_on': {k: sa[k] for k in ('bodyUploads', 'manifestWrites', 'secretWrites', 'relayWrites', 'directWrites')}, 'secret_off': {k: sb6[k] for k in ('bodyUploads', 'manifestWrites', 'secretWrites')}, 'edit': {k: s36[k] for k in ('bodyUploads', 'manifestWrites', 'relayWrites', 'directWrites')}}

        # ---- H37 failure safety ----
        def manual(d, plan): return d.ev("async(o)=>await lumosDriveSyncV136.p7ManualSyncV402B(o)", {'acceptPlanId': plan['planId'], 'acceptUnclassified': True, 'acknowledgeSecretDisclosure': True})
        res37 = {}
        for mode in ('throw', '502', '502-after'):
            w = World(br); D = w.device('devF' + mode.replace('-', ''), seed=ST); D.stub_extension('ok')
            first = []
            def rule(rec, first=first, mode=mode):
                if '/upload/' not in rec['url'] or b'p7-v402b-object' not in rec['body']: return None
                name = json.loads(rec['body'].split(b'\r\n\r\n', 1)[1].split(b'\r\n--', 1)[0])['name']
                if not first: first.append(name)
                return mode if name == first[0] else None
            D.holder['relay_fail'].append(rule)
            D.ev("()=>window.LumosProviderCore134.settings()")   # Provider Core steady state (what any monitored request does)
            snap0 = D.ev(SNAP_STEADY); plan = D.preview(); m0 = w.mark(); t0 = time.time(); out = manual(D, plan); dt = round(time.time() - t0, 1); s1 = w.since(m0, D)
            st = D.ev("()=>lumosDriveSyncV136.p7StatusV402B()"); cfg = json.loads(D.ev("()=>localStorage.getItem('LUMOS_DRIVE_SYNC_V136_CONFIG')"))
            tries = sum(1 for r in D.holder['relay'] if r['outcome'] != 'forwarded')
            fail_ok = (out['ok'] is False and out['status'] == 'core-failed' and out['extension']['called'] == 0 and len(D.ext_calls()) == 0 and st['migrated'] is False and st['active'] is False and st['base'] is None
                       and cfg.get('p7V402B', {}).get('base') is None and not cfg.get('p7V402B', {}).get('migrated') and head_manifest(w.sim)[0] is None and s1['manifestWrites'] == 0
                       and s1['directWrites'] == 0 and D.ev(SNAP_STEADY) == snap0)
            probe38(D); D.holder['relay_fail'].clear()
            plan2 = D.preview(); m1 = w.mark(); out2 = manual(D, plan2); s2 = w.since(m1, D); man, _, _ = head_manifest(w.sim)
            names2 = [e['name'] for e in w.sim.window(m1) if e['kind'] == 'upload' and e.get('area') == 'objects']
            present = mode == '502-after'
            ids2 = [u['domain'] + '/' + u['id'] for u in out2['coreReport']['uploads']]
            conv_ok = (out2['ok'] and out2['core']['result'] == 'MIGRATED' and len(D.ext_calls()) == 1 and man is not None and man['canonicalRootHash'] == D.ev("()=>__P7T.root()")
                       and len(ids2) == len(set(ids2)) and len(names2) == len(set(names2)) and ((first[0] not in names2) if present else (first[0] in names2))
                       and plan2['uploadCount'] == plan['uploadCount'] - (1 if present else 0) and s2['directWrites'] == 0 and s2['deletes'] == 0)
            res37[mode] = {'first_attempt': {'ok': out['ok'], 'status': out['status'], 'error': out['core']['error'], 'extension_called': out['extension']['called'], 'migrated': st['migrated'], 'active': st['active'], 'base': st['base'],
                                             'head': None, 'relay_failed_tries': tries, 'seconds': dt, 'local_unchanged_except_relay_runtime_marker': D.ev(SNAP_STEADY) == snap0},
                           'pass_fail_safety': fail_ok, 'retry': {'result': out2['core']['result'], 'object_already_present': present, 'reused': present and first[0] not in names2, 'uploads': len(names2), 'planned': plan2['uploadCount'],
                                                                   'extension_calls': len(D.ext_calls())}, 'pass_converge': conv_ok}
        # transient single 502 (transport-level bounded retry inside the relay wrapper) → same attempt succeeds, no duplicate logical transfer
        w = World(br); T7 = w.device('devT', seed=ST); once7 = []
        T7.holder['relay_fail'].append(lambda rec: (once7.append(1) or '502') if (not once7 and b'p7-v402b-object' in rec['body']) else None)
        _, rT = T7.accept_first(); idsT = [u['domain'] + '/' + u['id'] for u in rT['uploads']]
        probe38(T7)
        okT = rT['result'] == 'MIGRATED' and len(idsT) == len(set(idsT)) and len(once7) == 1
        ok37 = all(v['pass_fail_safety'] and v['pass_converge'] for v in res37.values()) and okT
        gate('H-P7B-37', 'failure safety', ok37,
             " ; ".join(f"relay {k} on first body upload → {v['first_attempt']['status']} (error: {str(v['first_attempt']['error'])[:60]}), migrated false, active false, base null, extension 0, head absent, direct fallback 0, local DB/SETTINGS byte-identical (relay runtime marker aside) → next attempt {v['retry']['result']}"
                        + (f", already-present object reused (uploads {v['retry']['uploads']} = planned {v['retry']['planned']})" if v['retry']['object_already_present'] else '') for k, v in res37.items())
             + f" ; transient single 502 → absorbed by the relay wrapper's bounded retry in the same attempt ({rT['result']}, no duplicate logical upload)")
        R4EVIDENCE['H37'] = {'modes': res37, 'transient_502': {'result': rT['result'], 'uploads': len(idsT)}}

        # ---- H38 transport credential / log safety ----
        allrec = [r for d in DEVICES for r in d.holder['relay']]
        auth_only = all(r['headers'].get('authorization') == 'Bearer ' + TOKEN for r in allrec)
        in_url_body = [r['url'] for r in allrec if TOKEN in r['url'] or TOKEN.encode() in r['body'] or any(TOKEN in v for k, v in r['headers'].items() if k != 'authorization')]
        in_drive = [f['name'] for s in SIMS for f in s.files.values() if TOKEN.encode() in f['content'] or TOKEN in f['name'] or 'SYN-REFRESH-TOKEN-XYZ' in f['name']]
        in_console = [m for d in DEVICES for m in d.console if TOKEN in m]
        rep_leak = [k for k, v in (('reports', json.dumps([res37, R4EVIDENCE], ensure_ascii=False, default=str)), ('trails', json.dumps(TRAILS))) if TOKEN in v]
        ok38 = allrec and auth_only and not in_url_body and not in_drive and not in_console and not any(p['leaks'] for p in PROBE38) and len(PROBE38) == 7 and not rep_leak
        gate('H-P7B-38', 'transport credential/log safety', ok38,
             f"bearer value present only as the transient upstream Authorization header of {len(allrec)} relayed requests (url/body/other headers 0) ; Drive file bytes + filenames {len(in_drive)} ; console {len(in_console)} ; "
             f"canonical / manifest / object / P7 report / trail / status / localStorage config / DB+SETTINGS / DOM incl. Provider Core monitor = {sorted({l for p in PROBE38 for l in p['leaks']})} on {len(PROBE38)} live devices (Provider Core monitor rows {sum(p['monitorLogs'] for p in PROBE38)}) ; harness reports {rep_leak} ; relay runtime marker = {PROBE38[0]['relayRuntime']}")
        R4EVIDENCE['H38'] = {'relayed_requests': len(allrec), 'auth_header_only': auth_only, 'probes': PROBE38}

        br.close()

    # ---- H28 ----
    tmp = Path(tempfile.mkdtemp()); fails = []; n = 0
    for i, s in enumerate(cs):
        if s['src'] or not s['body'].strip(): continue
        n += 1; f = tmp / f's{i}.js'; f.write_bytes(s['body'])
        if subprocess.run(['node', '--check', str(f)], capture_output=True).returncode: fails.append(i)
    work = tmp / 'rt.html'; work.write_bytes(par)
    rt = subprocess.run(['patch', '--binary', '-s', str(work), str(DIFF)], capture_output=True, text=True); rt_ok = rt.returncode == 0 and sha(work.read_bytes()) == sha(cand)
    rb = subprocess.run([sys.executable, str(ROOT / 'build_p7b_candidate.py'), str(PARENT), str(BLOCK), str(tmp / 'rb.html')], capture_output=True, text=True)
    rebuild_ok = rb.returncode == 0 and rb.stdout.strip() == sha(cand)
    dyn = lambda b: len(re.findall(rb'\beval\s*\(|new\s+Function\s*\(', b))
    gate('H-P7B-28', 'syntax / diff / protected owners', not fails and n == 253 and rt_ok and rebuild_ok and prot_ok and dyn(cand) == dyn(par) and not ERRORS,
         f'node --check {n - len(fails)}/{n} ; correction.diff roundtrip={rt_ok} ; deterministic rebuild={rebuild_ok} ; protected owners exact ; eval/new Function {dyn(par)}→{dyn(cand)} ; page errors={len(ERRORS)}')

    G.sort(key=lambda g: g['id'])
    R4EV = R4EVIDENCE; passed = sum(g['pass'] for g in G)
    res = {'parent_sha256': sha(par), 'candidate_bytes': len(cand), 'candidate_sha256': sha(cand), 'v136_before': sha(v136p), 'v136_after': sha(v136c), 'protected': prot,
           'gates': G, 'pass': passed, 'total': len(G), 'trails': TRAILS, 'transfer_truth': TRUTH, 'sibling_race': res14, 'pagination': res15, 'secret_deletion': SEC29, 'extension_composition': EXT30, 'r5_integration': R5INT, 'release_identity': REL32, 'r4_transport': R4EV, 'errors': ERRORS}
    if write: (ROOT / 'P7B_R4_Test_Results.json').write_text(json.dumps(res, ensure_ascii=False, indent=1, default=str), 'utf-8')
    print(f'RESULT {passed}/{len(G)}')
    if passed == len(G) == 38: print('ALL P7-B R4 TESTS PASS')
    else: raise SystemExit('P7-B R4 HOLD')

if __name__ == '__main__':
    main()
