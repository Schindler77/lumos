"""Synthetic Google Drive v3 emulator (no real network).

Installed as a Playwright context route on https://www.googleapis.com/** (direct transport) and behind the
synthetic Universal Relay fixture (p7b_device.py, relay transport). Implements the subset Lumos v136 + P7-B use: files.list (q grammar subset, pagination with a small forced page size), metadata
create (folders), multipart upload create, media download, media PATCH (legacy v6), DELETE (recorded).
Every request is recorded with its device label so tests can measure exact transfer counts/bytes.
"""
import copy, email.parser, email.policy, json, re, time
from urllib.parse import urlparse, parse_qs

FOLDER_MIME = 'application/vnd.google-apps.folder'
P7_FOLDERS = {'lumos-p7-manifests': 'manifests', 'lumos-p7-objects': 'objects', 'lumos-p7-secrets': 'secrets'}


def _unq(s):
    return s.replace("\\'", "'").replace('\\\\', '\\')


def _split_top(expr, sep):
    out, depth, quote, cur, i = [], 0, False, '', 0
    while i < len(expr):
        ch = expr[i]
        if ch == '\\' and quote:
            cur += expr[i:i + 2]; i += 2; continue
        if ch == "'":
            quote = not quote
        elif not quote and ch == '(':
            depth += 1
        elif not quote and ch == ')':
            depth -= 1
        if not quote and depth == 0 and expr.startswith(sep, i):
            out.append(cur); cur = ''; i += len(sep); continue
        cur += ch; i += 1
    out.append(cur)
    return [x.strip() for x in out]


class DriveSim:
    def __init__(self, page_cap=10):
        self.files = {}
        self.seq = 0
        self.clock = 0
        self.page_cap = page_cap
        self.log = []
        self.fail_rules = []      # callables(req_info) -> status or None
        self.hooks = []           # callables(sim, req_info) before handling (may inject files)

    # ---------------- state helpers ----------------
    def clone(self):
        c = DriveSim(self.page_cap)
        c.files = copy.deepcopy(self.files); c.seq = self.seq + 500000; c.clock = self.clock + 500000
        return c

    def _new_id(self):
        self.seq += 1
        return f'f{self.seq:06d}'

    def _time(self):
        self.clock += 1
        return time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(1790000000 + self.clock)) + f'.{self.clock % 1000:03d}Z'

    def add_file(self, name, parents, content=b'', mime='application/json', props=None):
        fid = self._new_id()
        self.files[fid] = {'id': fid, 'name': name, 'mimeType': mime, 'parents': list(parents), 'content': bytes(content),
                           'createdTime': self._time(), 'appProperties': props or {}, 'trashed': False}
        return fid

    def folder_ids(self, kind):
        return [f['id'] for f in self.files.values() if f['mimeType'] == FOLDER_MIME and P7_FOLDERS.get(f['name']) == kind]

    def children(self, kind):
        ids = set(self.folder_ids(kind))
        return sorted([f for f in self.files.values() if set(f['parents']) & ids], key=lambda f: (f['createdTime'], f['id']))

    def by_name(self, name):
        return [f for f in self.files.values() if f['name'] == name]

    def import_new_files(self, other, since_seq):
        """Copy files created in `other` (a clone) after `since_seq` into this sim (simulated concurrent writer)."""
        for fid, f in sorted(other.files.items()):
            if fid not in self.files and int(fid[1:]) > since_seq:
                g = copy.deepcopy(f); g['createdTime'] = self._time(); self.files[fid] = g
        self.seq = max(self.seq, other.seq)

    # ---------------- query ----------------
    def _match(self, f, clause):
        clause = clause.strip()
        if clause.startswith('(') and clause.endswith(')'):
            return any(self._match(f, c) for c in _split_top(clause[1:-1], ' or '))
        m = re.fullmatch(r"name\s*=\s*'((?:\\.|[^'])*)'", clause)
        if m: return f['name'] == _unq(m.group(1))
        m = re.fullmatch(r"mimeType\s*=\s*'((?:\\.|[^'])*)'", clause)
        if m: return f['mimeType'] == _unq(m.group(1))
        m = re.fullmatch(r"'((?:\\.|[^'])*)'\s+in\s+parents", clause)
        if m:
            pid = _unq(m.group(1))
            return pid in f['parents'] or (pid == 'root' and 'root' in f['parents'])
        if clause == 'trashed=false': return not f['trashed']
        raise ValueError('unsupported q clause: ' + clause)

    def query(self, q):
        clauses = _split_top(q, ' and ')
        return sorted([f for f in self.files.values() if all(self._match(f, c) for c in clauses)], key=lambda f: (f['createdTime'], f['id']))

    # ---------------- HTTP ----------------
    def handle(self, device, method, url, headers, body, via='direct'):
        u = urlparse(url); qs = {k: v[0] for k, v in parse_qs(u.query).items()}; path = u.path
        info = {'device': device, 'method': method, 'path': path, 'qs': qs, 'bytes_in': len(body or b''), 'bytes_out': 0, 'kind': 'other', 'name': None, 'via': via}
        for h in list(self.hooks):
            h(self, info, body)
        for rule in self.fail_rules:
            st = rule(info, body)
            if st:
                info['kind'] = 'failed'; self.log.append(info)
                return st, {'error': {'code': st, 'message': 'synthetic failure'}}
        status, payload, raw = 404, {'error': {'code': 404}}, None
        m_media = re.fullmatch(r'/drive/v3/files/([^/]+)', path)
        if method == 'GET' and path == '/drive/v3/files':
            items = self.query(qs.get('q', ''))
            size = min(int(qs.get('pageSize', '100')), self.page_cap)
            start = int(qs.get('pageToken', '0') or 0)
            page = items[start:start + size]
            payload = {'files': [{'id': f['id'], 'name': f['name'], 'mimeType': f['mimeType'], 'size': str(len(f['content'])), 'createdTime': f['createdTime'],
                                  'modifiedTime': f['createdTime'], 'appProperties': f['appProperties']} for f in page]}
            if start + size < len(items): payload['nextPageToken'] = str(start + size)
            status = 200; info['kind'] = 'list'
        elif method == 'GET' and m_media and qs.get('alt') == 'media':
            f = self.files.get(m_media.group(1))
            if f:
                status, raw = 200, f['content']; info['kind'] = 'download'; info['name'] = f['name']; info['bytes_out'] = len(raw)
                info['area'] = self._area(f)
        elif method == 'POST' and path == '/drive/v3/files':
            meta = json.loads(body.decode('utf-8') or '{}')
            fid = self.add_file(meta.get('name'), meta.get('parents') or ['root'], b'', meta.get('mimeType', 'application/json'), meta.get('appProperties'))
            f = self.files[fid]; payload = {'id': fid, 'name': f['name'], 'mimeType': f['mimeType'], 'createdTime': f['createdTime'], 'modifiedTime': f['createdTime']}
            status = 200; info['kind'] = 'create-meta'; info['name'] = f['name']; info['meta'] = meta
        elif method == 'POST' and path == '/upload/drive/v3/files' and qs.get('uploadType') == 'multipart':
            meta, content = self._multipart(headers, body)
            fid = self.add_file(meta.get('name'), meta.get('parents') or ['root'], content, meta.get('mimeType', 'application/json'), meta.get('appProperties'))
            f = self.files[fid]; payload = {'id': fid, 'name': f['name'], 'size': str(len(content)), 'createdTime': f['createdTime'], 'modifiedTime': f['createdTime']}
            status = 200; info['kind'] = 'upload'; info['name'] = f['name']; info['content_bytes'] = len(content); info['area'] = self._area(f); info['meta'] = meta
        elif method == 'PATCH' and re.fullmatch(r'/upload/drive/v3/files/([^/]+)', path):
            fid = path.rsplit('/', 1)[1]; f = self.files.get(fid)
            if f:
                f['content'] = body; status = 200; payload = {'id': fid, 'name': f['name'], 'size': str(len(body)), 'modifiedTime': self._time()}
                info['kind'] = 'patch'; info['name'] = f['name']
        elif method == 'DELETE':
            status, payload = 204, None; info['kind'] = 'delete'
        self.log.append(info)
        if raw is not None: return status, raw
        return status, payload

    def _area(self, f):
        pid = set(f['parents'])
        for kind in ('manifests', 'objects', 'secrets'):
            if pid & set(self.folder_ids(kind)): return kind
        return 'legacy' if f['name'].startswith('lumos-') else 'other'

    @staticmethod
    def _multipart(headers, body):
        ctype = headers.get('content-type') or headers.get('Content-Type')
        msg = email.parser.BytesParser(policy=email.policy.HTTP).parsebytes(b'Content-Type: ' + ctype.encode() + b'\r\n\r\n' + body)
        parts = [p for p in msg.iter_parts()]
        meta = json.loads(parts[0].get_payload(decode=True).decode('utf-8'))
        return meta, parts[1].get_payload(decode=True)

    # ---------------- measurement ----------------
    def window(self, start):
        return self.log[start:]

    @staticmethod
    def summarize(entries, device=None):
        s = {'bodyUploads': 0, 'bodyUploadBytes': 0, 'bodyDownloads': 0, 'bodyDownloadBytes': 0, 'manifestWrites': 0, 'manifestReads': 0, 'secretWrites': 0,
             'legacyWrites': 0, 'deletes': 0, 'lists': 0, 'requests': 0, 'folderCreates': 0, 'relayWrites': 0, 'directWrites': 0}
        for e in entries:
            if device and e['device'] != device: continue
            s['requests'] += 1
            if e['method'] != 'GET':
                s['relayWrites' if e.get('via') == 'relay' else 'directWrites'] += 1
            if e['kind'] == 'create-meta': s['folderCreates'] += 1
            if e['kind'] == 'upload':
                if e.get('area') == 'objects': s['bodyUploads'] += 1; s['bodyUploadBytes'] += e['content_bytes']
                elif e.get('area') == 'manifests': s['manifestWrites'] += 1
                elif e.get('area') == 'secrets': s['secretWrites'] += 1
                else: s['legacyWrites'] += 1
            elif e['kind'] == 'download':
                if e.get('area') == 'objects': s['bodyDownloads'] += 1; s['bodyDownloadBytes'] += e['bytes_out']
                elif e.get('area') == 'manifests': s['manifestReads'] += 1
            elif e['kind'] == 'patch': s['legacyWrites'] += 1
            elif e['kind'] == 'delete': s['deletes'] += 1
            elif e['kind'] == 'list': s['lists'] += 1
        return s
