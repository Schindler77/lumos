# P7-B R4 — Secrets Contract (D11 + D15)

> **R4 note:** semantics identical to the Architect-accepted R2/R3 contract. R4 is rebuilt from the exact P7-A R5 OFFICIAL parent; the only behavioral change is the P7 **write transport** on standalone `file://` pages (see `P7B_R4_Transport_Contract.md`): every P7 create goes through the existing Lumos Universal Relay. Release identity is v402 R4.

## Isolation (unchanged)
Secrets never enter canonical objects, manifests, object/manifest filenames, reports, logs or the status bridge. A secret change or deletion never changes the canonical root (H-P7B-20, H-P7B-29D).

## Channel
`lumos-p7-secrets/s-<writer>-<seq10>.json`, append-only (earlier snapshots are never modified or deleted).
Snapshot `{format:'lumos-p7-secret-snapshot', schemaVersion:2, writer, createdAt, entries:{<pathKey>: event}}`.

## Event forms (reader accepts all three)
| Form | Shape | Meaning |
|---|---|---|
| R1 live | `{segs, value, t, w}` | read as `deleted:false` |
| R2 live | `{segs, value, deleted:false, t, w}` | LIVE(value) |
| R2 tombstone | `{segs, deleted:true, t, w}` | DELETED — carries **no value or value-derived material** |

Entries with neither a non-empty value nor `deleted:true` are ignored.

## Local path state (non-secret metadata only)
`config.p7V402B.secretClocks[pathKey] = {s: segs, h, t, w, d}` where `h` = first 16 hex of sha256(per-install random salt + value) for live paths, `null` for deleted; `d` = deleted flag.
- **unknown**: no clock → local absence is *not* a deletion (fresh device adopts a newer remote live value; H-P7B-29B emitted 0 tombstones).
- **known-live**: clock `d:false` → local value changed (hash differs) ⇒ new live event `t=now`; local value cleared/removed ⇒ new tombstone `t=now` (exactly once).
- **known-deleted**: clock `d:true` → repeated syncs do not re-stamp; a newly entered value ⇒ new live event.
Clocks written before R2 without a path (`s`) are treated as unknown and dropped (never a deletion).

## Merge and apply (per path)
Newer `t` wins; equal `t` → lexically greater writer wins. Local events participate with their clocks; remote events come from the latest snapshot of each writer.
- Winner live ⇒ value applied (if different); clock ← winner.
- Winner tombstone ⇒ local secret cleared (set to `''`); clock ← `{d:true}`; any older live snapshot can never resurrect it.
- A new own snapshot is written only when the merged set differs from this writer's latest snapshot ⇒ `secretWrites=0` after convergence (H-P7B-29A/29C).

## Paths / exclusions (unchanged)
Collected from SETTINGS with the existing `isSecretKey`; collection items addressed by item id. Excluded: device-local/runtime roots and `oauth|googledrive|driveauth|universalrelay|relaytoken` paths. Drive OAuth tokens (v136 config) and built-in relay material are never collected.

## Policy (unchanged)
Existing install → ON with disclosure acknowledgement before the first v7 commit; new install → OFF; disabling leaves local secrets untouched.

## Reporting
`report.secret = {enabled, disclosed, status, paths, live, deleted, applied, cleared, tombstonesCreated, written}` — counts and flags only. H-P7B-29D found the deleted value in none of: objects, manifests, filenames, tombstone, reports, console, status, local config.

## R4 additions — transport credential safety (D20, H-P7B-38)
- Secret snapshots are written through the same P7 write helper (relay on `file://`), only when secret sync is enabled and disclosed; with `disableSecretSync:true` no secret snapshot is written (H-P7B-36).
- The Drive OAuth access token is obtained per write from the existing v136 `requestToken(interactive)` owner and attached only as the transient upstream `Authorization` header inside the relay envelope. It is never in canonical bytes, objects, manifests, secret snapshots, filenames, P7 reports/trail/status, console diagnostics, local config, DB/SETTINGS, or the Provider Core monitor (H-P7B-38). Relay error text is passed through a redaction step (`p7SafeTextV402D`) before it can reach a report.
- The relay's own runtime marker `SETTINGS.universalRelayLastRuntimeV106` holds only the upstream scheme/host/path (no query, no headers); it is a P7-A R5 local-only root and never canonical.
