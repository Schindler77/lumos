# P7-B R4 — Transport Contract (Manual Sync v7)

> **R4 note:** R4 is built from the exact P7-A R5 OFFICIAL parent. Sync semantics (layout, head, fence, resolution, apply, secrets, extension composition) are the Architect-accepted R2/R3 semantics, unchanged. The one behavioral change is the **P7 write transport** (decisions D17–D22), specified first below. Release identity: v402 R4.

## R4 — P7 write transport (`p7DriveWriteV402D`)
Owner: `lumos-v136-drive-sync-script`. Scope: P7 writes only. Legacy v6 writes, the v245 extension owner and every read are unchanged.

| Page origin | P7 writes (root create if absent, 3 P7 folders, objects, manifests, secret snapshots) | P7 reads / lists / downloads |
|---|---|---|
| `file:` (standalone HTML, origin `null`) | **existing `window.LumosUniversalRelay106.fetch`**, from the first write; never a direct Google upload first; no direct fallback after a relay failure | direct `driveFetch` (unchanged) |
| `http:` / `https:` | R3 direct path (`driveFetch`; FormData multipart for bodies) | direct `driveFetch` |

### Readiness (fail before writing)
`p7TransportV402D()` → `{origin, write:'relay'|'direct', relayAvailable, ready}`. On `file:` without a usable relay, `p7SyncV402B` returns `TRANSPORT_UNAVAILABLE` before the mutation lock, before any Drive request and before any config change. The dry-run is read-only and reports the same transport object (not part of `planId`). The helper re-checks the relay on every write.

### Provider Core priming (found by the R4 harness)
`LumosUniversalRelay106.fetch` is the Provider Core (v134) monitored fetch, and its first call normalizes `SETTINGS.providerCoreV134` (adds `enabled/retryEnabled/maxRetries/baseDelayMs/maxWaitMs`). That key is a **canonical INCLUDE settings field** under P7-A R5. A profile loaded after boot leaves it un-normalized, so without countermeasures the first relay write would move the local canonical root mid-sync and the R3 apply guard would abort the run ("로컬 상태가 동기화 중 변경"). Every join would fail, and a fresh-tab live migration could too. R4 therefore calls the public, idempotent `LumosProviderCore134.settings()` once on the relay path: after the acceptance checks (so blocked runs stay byte-identical), and before the mutation lock and before local state is read. The normalized value is then part of the committed local state, exactly as if the app had made any monitored request first. The dry-run does not prime, so it stays read-only. Regression: H-P7B-33 (un-normalized `{routing:'auto'}` → MIGRATED, head root == local root) and every `pair()` join in H-P7B-03..31.

### Request shape
- Folder creates: `POST {API_ROOT}/files?fields=…`, `Content-Type: application/json`, string body `{name,mimeType:folder,parents,appProperties}`. The Rumos root uses the legacy metadata exactly (`parents:['root']`, `appProperties:{lumos:'drive-sync-v136'}`) and is created only if `findFolder` finds none; P7 folders keep `{lumos:'p7-v402b',kind}`. Legacy `ensureFolder/createFolder` are not modified; P7 uses `p7EnsureRootV402D` (same lookup, P7 write for the create, records `config.folderId` like `ensureFolder`).
- Text bodies (objects / manifests / secret snapshots): `POST {UPLOAD_ROOT}/files?uploadType=multipart&fields=id,name,size,createdTime` with an explicit **string** body:
  ```
  --<boundary>\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n<metadata JSON>\r\n
  --<boundary>\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n<content JSON>\r\n
  --<boundary>--
  ```
  header `Content-Type: multipart/related; boundary=<boundary>`; boundary = `lumos_p7_` + 36 random hex, re-drawn if it occurs in either part. The relay forwards it as `bodyText` (UTF-8). No `FormData`/`Blob` ever reaches the relay. Metadata `{name, mimeType:'application/json', parents:[folderId], appProperties}` is identical to R3. Content bytes are the exact canonical JSON (objects: SHA-256/size self-checked against the manifest entry before upload; the hash covers the content, never the multipart framing).
- Response: the relay mirrors the upstream status and body (Drive file metadata JSON, as in R3). The effective upstream status is `X-Lumos-Upstream-Status` when present, else the relay status.

### Token and errors
- Token: existing v136 `requestToken(interactive)` per write; attached only as the transient upstream `Authorization: Bearer …` header in the relay envelope. Never logged, persisted, reported, or written to Drive (H-P7B-38).
- Upstream 401: clear the in-memory token and retry once (refresh via the existing owner) — same as `driveFetch`.
- Relay throw / network error / non-2xx / upstream 5xx: throw a transport error (text redacted, ≤300 chars) → `p7SyncV402B` returns `FAILED` through the existing catch: no local apply, no base/migrated/active change (unless a manifest was already committed and applied earlier in the same run, exactly as in R3), no extension call, no direct fallback.
- `LumosUniversalRelay106.fetch` is the existing relay entry point as installed by the Provider Core (v134): it records the request (target path only, no headers or body) in the in-tab AI-request monitor and retries 429/5xx/network failures at most twice (5 s, 10 s). For P7 this bounded retry is safe because every P7 write is a create-only, deterministic name: a duplicate object file has identical content-addressed name and bytes (listing keeps the first), a duplicate manifest has the identical unique name and bytes (same-name copies are not siblings), duplicate P7 folders are all listed. The R3 idempotency rule (re-list deterministic names before uploading) is unchanged; H-P7B-37 exercises a forwarded-then-502 outcome.

### Evidence
H-P7B-33 (selection, relay-missing, http control), H-P7B-34 (fresh-Drive folder creation via relay; R3-attempt Drive reuse), H-P7B-35 (byte-exact multipart decode), H-P7B-36 (routing incl. secret on/off), H-P7B-37 (throw / 502 / forwarded-then-502 / transient 502), H-P7B-38 (credential/log safety). H-P7B-01..32 run on `file://`, so every P7 write in them uses the relay as well.

## R2/R3 transport semantics (unchanged)
R2 keeps the R1 transport unchanged; the only transport-adjacent changes are the secret tombstone channel (Secrets contract) and Manual Sync composition with the v245 extension owner (Extension Composition contract).

Owner: `lumos-v136-drive-sync-script` only. Canonical/fingerprint authority: `window.LumosP7CanonicalV401A` (P7-A R4 OFFICIAL, consumed as-is, no filtering added in v136).

## Drive layout (under the existing `Rumos` folder)
| Folder | Content | Naming |
|---|---|---|
| `lumos-p7-manifests` | append-only manifests | `<rev10>-<writer>-<nonce>.json` |
| `lumos-p7-objects` | canonical object bodies (exact P7-A canonical JSON bytes) | `o-<sha256(domain\0id)[:32]>-<sha256(body)>.json` |
| `lumos-p7-secrets` | secret snapshots (see Secrets contract) | `s-<writer>-<seq10>.json` |

- `writer` = `w` + sha256(deviceId)[:16]. `nonce` = base36(time) + per-device sequence. No raw object ids, titles or secrets in any filename.
- No mutable HEAD/pointer file. No file is ever deleted, trashed or overwritten by v7. Legacy v6 files (`lumos-settings.json`, `lumos-novels.json`, backups) are read-only for v7.
- Every Drive **read** goes through the existing `driveFetch` (existing OAuth token handling) to `API_ROOT`. Every P7 **write** goes through `p7DriveWriteV402D` (R4 section below). The v7 block contains no URL literals.

## Listing
All P7 listings are paginated (`pageSize=1000`, follow `nextPageToken` to the end). Duplicate P7 subfolders (concurrent first creation) are all read; writes go to the oldest.

## Authoritative head
Head = the highest manifest by total order `(revision, writer, nonce)` that is valid:
parseable, passes `validateManifestPreview` (shape + root + domain recomputation), filename rev/writer match the content, and every referenced object file exists. Invalid candidates are skipped, never repaired or deleted. Same-revision siblings are preserved.

## Manifest (P7-A R0 shape + non-authoritative extras)
`format, schemaVersion, canonicalSchema, createdAt, revision, parentRevision, writer, canonicalRootHash, domains, objects[{domain,id,hash,size}]` + `parentNameV402B` (lineage), `clocksV402B` (field clocks `{t,w}`), `generatorV402B`. Extras do not affect root/domain semantics. Objects are sorted by (domain, id).

## Sync algorithm (`p7SyncV402B`)
1. Preconditions: mutation lock free; first run requires the migration gate (Migration contract). Local state flushed (`saveData`).
2. Inspect: list manifests + object names (metadata only), resolve head.
3. Base: recorded base manifest if it lies on the head lineage (`parentNameV402B` walk, depth 64); otherwise the lowest common ancestor of base and head; otherwise none (all divergences preserved as forks).
4. Decide per object (P7-A fingerprints): SAME / FAST_FORWARD_LOCAL (take remote) / FAST_FORWARD_REMOTE (push local) / DIVERGED_FORK_REQUIRED.
5. Stage in memory only. Remote bodies are downloaded only for FF_LOCAL / DIVERGED objects, each verified (sha256 + byte size) before use; the in-memory body cache is re-verified on every hit and is never authority. Mismatch → `INVALID_REMOTE`, nothing written anywhere.
6. Resolution: novel/world → fork (remote keeps id; local copy `fork-<hash>` titled `… (기기 분기본)`, `forkOfV7`); settings collection items / risu plugins → item fork (lower hash keeps id, other `id__conflict_<hash12>`); scalar settings fields → field-clock LWW with writer tie-break; long/complex (authored) fields → LWW + deterministic conflict record in `SETTINGS.p7ConflictRecordsV402B` (both values verbatim); library/lifecycle/`$collectionOrder`/conflict records → union. Edit-vs-delete keeps the surviving edit. No sentence-level merge.
7. **Pre-verify local apply before any remote write**: the staged state is applied to clones of DB/SETTINGS and re-extracted with P7-A; the result must equal the prospective manifest (modulo pending asset markers). Failure → `FAILED` with zero remote writes.
8. Upload only object bodies the remote lacks (content-addressed, idempotent, reused after crash).
9. Fence: re-list manifests; any new manifest at/above the inspected head → `retryable`, re-inspect (max 4 attempts). No success is reported for a stale plan.
10. Commit one manifest `rev = head.rev + 1`.
11. Post-commit verification: re-resolve head; if this manifest is not the head (lost same-revision race) → `retryable`, re-inspect; local state untouched.
12. Swap the pre-verified clones into live DB/SETTINGS, `saveData`, refresh UI; record base. If app-side normalization after the swap changed canonical state (e.g. sidebar order gaining new chats), one `settling` commit runs in the same sync.
13. Secret channel (separate; never canonical; R2 tombstones).
14. Manual Sync only: on core success invoke `LumosExtensionSyncV245.upload` once (Extension Composition contract).

## Assets (D13)
Asset markers travel; bytes never do. A device that cannot materialize a marker keeps a local *pending-asset* equivalence (`config.p7V402B.pendingAssets`) so the remote marker is preserved and no ping-pong upload occurs. Apply never writes a marker into live data and never removes a local data URL.

## Status machine
`idle, inspecting, same, downloading, uploading, fork-required, validating, settling, retryable, success, failed`, exposed as `p7PhaseV402B` / `p7TrailV402B` on the v391 activity bridge; results `SAME, SYNCED, FORKED, MIGRATED, ACCEPTANCE_REQUIRED, INVALID_REMOTE, STALE_RETRY_EXHAUSTED, FAILED, BLOCKED`.

## Transfer truth
`report.planned` (object count/bytes actually transferred, cumulative over attempts) equals DriveSim-measured body transfer in 71/71 harness runs. Manifest bytes are reported separately.

## Public API (added to `window.lumosDriveSyncV136`)
`p7PreviewSyncV402B(opts)`, `p7SyncV402B(opts)` (core only), `p7ManualSyncV402B(opts)` (core + v245 owner), `p7StatusV402B()`, `p7SetEnabledV402B(on)`, `p7SetSecretSyncV402B(enabled,{acknowledgeDisclosure})`, `p7ResetLocalBaseV402B()`, `p7TransportV402D()` (R4), `_legacySyncV246(opts)`, `_p7TestV402B` (cache handles + R4 `multipart(meta,text)` builder for tests). `sync()` / the Manual Sync button route to `p7ManualSyncV402B` only when v7 is active (migration gate passed); otherwise the legacy v6 path runs unchanged. `startupSync()` still returns false.
