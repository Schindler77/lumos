# P7-B R4 — Extension Composition Contract (D16)

> **R4 note:** semantics identical to the Architect-accepted R2/R3 contract. R4 is rebuilt from the exact P7-A R5 OFFICIAL parent; the only behavioral change is the P7 **write transport** on standalone `file://` pages (see `P7B_R4_Transport_Contract.md`): every P7 create goes through the existing Lumos Universal Relay. Release identity is v402 R4.

`LumosExtensionSyncV245` (unchanged, byte-identical) remains the live Drive authority for Risu plugins/modules during P7-B. v136 does not reimplement or duplicate its persistence/merge, and no Risu plugin body is written to `lumos-p7-objects` (H-P7B-30F: 0).

## v7 Manual Sync = `p7ManualSyncV402B(opts)`
1. Run the P7 core (`p7SyncV402B`).
2. Core not ok (FAILED, INVALID_REMOTE, ACCEPTANCE_REQUIRED, STALE_RETRY_EXHAUSTED, BLOCKED) ⇒ owner **not** invoked; overall false, status `core-failed`.
3. Core ok (including `SAME`) ⇒ `window.LumosExtensionSyncV245.upload({quiet:true, integrated:true})` exactly once (the same call and arguments the legacy unified path uses).
4. Owner returns `true` ⇒ overall success, status `success`, result = core result.
5. Owner returns non-true, throws, or is missing ⇒ overall **false**, status `extension-failed`, result `EXTENSION_FAILED`, `extension.error` from the owner state. The core commit stands; it is neither rolled back nor repeated (next run: core SAME, 0 manifest/body writes — H-P7B-30D).

Return shape: `{ok, status, result, core:{ok,result,revision,error}, extension:{called, ok, error}, coreReport}`; also `p7StatusV402B().lastManualSync` and the v391 activity field `p7ManualV402B:{status, core, extension}`. `runManualSyncV385` settles the activity with `ok`, so an extension failure is never shown as full success.

## Routing
| State | Manual Sync path | v245 calls per Manual Sync |
|---|---|---|
| v7 not active (pre-migration) | legacy `syncUnifiedV246` (unchanged; it calls v245 itself when the extension domain changed) | parent 1 / candidate 1 in the same scenario (H-P7B-30E) |
| v7 active | `p7ManualSyncV402B` | core ok ⇒ 1, core failed ⇒ 0 |

The core API `p7SyncV402B` (used for dry-run acceptance and tests) does not call the owner; only Manual Sync composes.

## Evidence
H-P7B-30A–F with a counting owner stub (ok / fail / real). The real-owner run completed against the synthetic Drive and wrote only `lumos-extensions.json` (its own file, outside the P7 folders).

## R4 additions
Unchanged composition. A relay transport failure in the P7 core is a core failure: the v245 owner is called 0 times and Manual Sync reports `core-failed` (H-P7B-37, all three relay fault modes). The v245 owner keeps its own existing transport; R4 does not reroute extension writes.
