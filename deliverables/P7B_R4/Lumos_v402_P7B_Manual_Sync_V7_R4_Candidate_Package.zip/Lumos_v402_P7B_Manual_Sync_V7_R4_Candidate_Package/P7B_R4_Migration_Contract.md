# P7-B R4 — Migration Contract (v6 → v7)

> **R4 note:** semantics identical to the Architect-accepted R2/R3 contract. R4 is rebuilt from the exact P7-A R5 OFFICIAL parent; the only behavioral change is the P7 **write transport** on standalone `file://` pages (see `P7B_R4_Transport_Contract.md`): every P7 create goes through the existing Lumos Universal Relay. Release identity is v402 R4.

Unchanged from R1 except: after the migration gate, Manual Sync = v7 core + v245 extension owner (see Extension Composition contract). Before the gate, the legacy Manual Sync path is byte-for-byte the R4 behavior (v245 called by `syncUnifiedV246` itself; call count parent=1, candidate=1 in H-P7B-30E).

## Two-step gate (D10)
1. **Read-only dry-run** — `p7PreviewSyncV402B()`:
   - No Drive create/upload/patch/delete, no folder creation (uses `findFolder`, never `ensureFolder`), no `saveData`, no config persistence (the plan lives in memory only; the v389 settings meta touched by the v6 payload builder is restored).
   - Reads legacy v6 files through the existing validated readers (`readCloudFile` / `readNovelFile`).
   - Modes: `migrate` (no valid P7 manifest yet), `join` (P7 history exists, this device has no base), `sync`.
   - Plan: `planId`, local root, proposed root, remote head, decision counts, upload count/bytes, fork count, legacy files found, **full unclassified path list** (P7-A report, from the local and merged state), secret count + policy (values never included), and `requires {acceptance, acceptUnclassified, secretDisclosure}`.
2. **Explicit acceptance** — `p7SyncV402B({acceptPlanId, acceptUnclassified, acknowledgeSecretDisclosure | disableSecretSync})`:
   - Missing/mismatched plan id, unaccepted unclassified paths, or unacknowledged secret disclosure → `ACCEPTANCE_REQUIRED` before any write (0 Drive requests, local unchanged).

## Migrate mode
The proposed state = existing v6 merge semantics on clones (`mergeNovelData` + `mergeSettingsPayloadsV389`, external-authority roots / secrets / extension-owned models restored from local), extracted with P7-A. Commit uploads its objects and writes rev1; local state becomes the merged state through the same pre-verified apply. Legacy v6 files are never written or deleted (bytes verified unchanged in H-P7B-17/24).

## Join mode
Base for the first join = canonical of the legacy v6 files (the last common v6 state) when present, else none. Objects changed on both sides relative to that base are preserved as forks.

## After commit
`config.p7V402B = {enabled:true, migrated:true, base:{name,revision,root}}`; Manual Sync switches to v7. `p7ResetLocalBaseV402B()` returns this device to the pre-migration gate (Drive untouched). `p7SetEnabledV402B(false)` routes Manual Sync back to v6 (no v6 automatic fallback exists inside v7).

## Operator checklist for the first live migration
Run the dry-run on the real profile; review `unclassified` (R4 real profile expects `[]` for DB roots) and `secret`; then accept with the returned `planId`.

## R4 additions — live-gate compatibility (instruction §7)
- The dry-run stays read-only on every origin (`findFolder` + listings only; 0 writes, 0 relay requests).
- `p7PreviewSyncV402B()` reports `transport {origin, write, relayAvailable, ready}`; it is not part of `planId`.
- The commit refuses to start on a `file://` page without `LumosUniversalRelay106` → `TRANSPORT_UNAVAILABLE`, 0 Drive requests, `migrated/active/base` unchanged (H-P7B-33).
- A Drive left behind by the failed R3 live attempt needs **no manual cleanup**: existing `Rumos` root and P7 folders are listed and reused (0 folder creates), an object whose deterministic name already exists is reused (not re-uploaded), nothing is deleted, and no head is published before every referenced body exists and the fence passes (H-P7B-34B, H-P7B-37).
- A relay/network/upstream-5xx failure during the first migration attempt leaves `migrated=false, active=false, base=null`, no manifest head, no extension call; the next attempt converges (H-P7B-37).
